<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_orders extends CI_Model {
	
	public function get_user_id_by_session()
	{ 
		$usr_name = $this->session->userdata('username');
		$gry = $this->db->where('usr_name',$usr_name)
						->select('usr_id')
						->limit(1)
						->get('users');
				if($gry->num_rows() > 0 )
					{
							return $gry->row()->usr_id;
					}else{
						
							return 0;
						 }	
	}
	
	
	public function process()
	{ 	
	
		
		//here for create new invoice
		$invoice = array(
						'date'		=>	date('Y-m-d H:i:s'),
						'due_date'	=>	date('Y-m-d H:i:s',mktime(date('H'),date('i'),date('s'),date('m'),date('d') + 1,date('Y'))),
						'user_id'	=> $this->get_user_id_by_session(),
						'status'	=>	'unpaid'
						);
		$this->db->insert('invoices',$invoice);
		$invoice_id = $this->db->insert_id();
		//here for put ordered items in orders table
		foreach ($this->cart->contents() as $item)
		{
			$data = array(
						'invoice_id'		=> $invoice_id,
						'product_id'		=> $item['id'],
						'product_type'		=> $item['name'],
						'product_title'		=> $item['title'],
						'qty'				=> $item['qty'],
						'price'				=> $item['price']
						
						 );
			$this->db->insert('orders',$data);
		}
		
		return TRUE;
	}
	public function process_order($cust_name,$address,$cust_phone,$notes,$total,$email,$shippingfee,$paymentmethod,$courier,$citycode,$total_weight,$reseller_name,$reseller_phone,$reseller_address)
	{


		//here for create new invoice
		$invoice = array(
			'date'		=>	date('Y-m-d H:i:s'),
			'due_date'	=>	date('Y-m-d H:i:s',mktime(date('H'),date('i'),date('s'),date('m'),date('d') + 1,date('Y'))),
			'user_id'	=> $this->get_user_id_by_session(),
			'status'	=>	'waiting confirm',
			'customer_name'	=> $cust_name,
			'address_shipping'=>$address,
			'customer_phone'=>$cust_phone,
			'order_notes'=>$notes,
			'total_invoice'=>$total,
			'customer_mail'=>$email,
			'shipping_fee'=>$shippingfee,
			'payment_method'=>$paymentmethod,
			'courier_service'=>$courier,
			'city_code'=>$citycode,
			'total_weight'=>$total_weight,
			'reseller_name'=>$reseller_name,
			'reseller_address'=>$reseller_address,
			'reseller_phone'=>$reseller_phone,
			'status'=>0

		);
		$this->db->insert('invoices',$invoice);
		$invoice_id = $this->db->insert_id();
		//here for put ordered items in orders table
		foreach ($this->cart->contents() as $item)
		{
			$data = array(
				'invoice_id'		=> $invoice_id,
				'product_id'		=> $item['id'],
				'product_type'		=> $item['name'],
				'product_title'		=> $item['title'],
				'product_color'		=> $item['color'],
				'qty'				=> $item['qty'],
				'price'				=> $item['price']

			);
			$this->db->insert('orders',$data);
		}
		foreach ($this->cart->contents() as $item)
		{
		//$this->db->select('products');
        $query = $this->db->where('pro_id', $item['id'])
        		->select('pro_stock')
        		->get('products');
        $row = $query->row();
        $quantity_in_stock = $row->pro_stock;

        //I am assuming that $quantidade is the quantity of the order
        $new_quantity_in_stock = $quantity_in_stock -  $item['qty'] ;

			$data = array(
				'pro_stock'			=> $new_quantity_in_stock 
			);
			$this->db->where('pro_id',$item['id'])
					 ->update('products',$data);
		}

		return $invoice_id;
	}
	public function all_invoices()
	{ // get all orders from orders tble
		$get_orders = $this->db->get('invoices');
			if($get_orders->num_rows() > 0 ) {
					return $get_orders->result();
			} else {
					 return array();
			}
	}
	public function get_invoice_by_id($invoice_id)
	{
		$sql = "select s.usr_fullname as reseller,i.*,DATEDIFF(NOW(),i.due_date) as is_due
 from invoices i inner join users s on i.user_id= s.usr_id where i.id=$invoice_id order by i.date desc" ;
		$get_it = $this->db->query($sql);
		if($get_it->num_rows() > 0 )
		{
			return $get_it->result();
		}else{
			return FALSE; //if there are no matching records
		}
	}
	
	public function get_orders_by_invoice($invoice_id)
	{
		$sql = "select * from orders where invoice_id=$invoice_id" ;
		$get_it = $this->db->query($sql);
		if($get_it->num_rows() > 0 )
		{
			return $get_it->result();
		}else{
			return FALSE; //if there are no matching records
		}
	}
	
	
}//end class