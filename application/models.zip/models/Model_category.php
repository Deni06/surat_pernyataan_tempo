<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by IntelliJ IDEA.
 * User: andre
 * Date: 10/6/2015
 * Time: 5:12 AM
 */
class model_category extends CI_Model
{
    public function cat_products()
    {

        $sql = "select * from category where is_parent=1";
        $show = $this->db->query($sql);
        if($show->num_rows() > 0 ) {
            return $show->result();
        } else {
            return array();
        } //end if num_rows
    }
    public function subcat_products()
    {

        $sql = "select cat_name as subcat_name,cat_id as subcat_id,parent_id from category where is_parent=0";
        $show = $this->db->query($sql);
        if($show->num_rows() > 0 ) {
            return $show->result();
        } else {
            return array();
        } //end if num_rows
    }
    public function cat_products_nav($cat_id)
    {

        $sql = "select * from category where is_parent=1";
        $show = $this->db->query($sql);
        if($show->num_rows() > 0 ) {
            return $show->result();
        } else {
            return array();
        } //end if num_rows
    }
    public function cat_products_subnav($cat_id)
    {
        $sql = "select cat_name as subcat_name,cat_id as subcat_id,parent_id from category where is_parent=0";
        $show = $this->db->query($sql);
        if($show->num_rows() > 0 ) {
            return $show->result();
        } else {
            return array();
        } //end if num_rows
    }
    public function get_cat_name($cat_id)
    {
        $sql = "select cat_name from category where cat_id=$cat_id";
        $show = $this->db->query($sql);
        if($show->num_rows() > 0 ) {
            return $show->result();
        } else {
            return array();
        } //end if num_rows
    }
}