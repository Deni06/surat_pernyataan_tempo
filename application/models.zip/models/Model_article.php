<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_article extends CI_Model {
	
		public function all_article(){ 
			$sql = "select * from article order by created_on desc";
			$show=$this->db->query($sql);
			if($show->num_rows() > 0 ) {
					return $show->result();
			} else {
					 return array();
			} 		
		}
	public function top_article(){
		$sql = "select * from article order by created_on desc limit 5";
		$show=$this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return array();
		}
	}
		public function show_article_per_page($start,$limit){ 
			$sql = "select * from article order by created_on desc LIMIT $start,$limit";
			$show=$this->db->query($sql);
			if($show->num_rows() > 0 ) {
					return $show->result();
			} else {
					 return array();
			} 		
		}


		public function find($article_id)
		{
			$sql = "select * from article  where article_id=$article_id limit 1";
			$show = $this->db->query($sql);
			if($show->num_rows() > 0 ) {
				return $show->result();
			} else {
				return array();
			}
				
		}

		public function get_content_type($article_id){
			$sql = "select content_type from article  where article_id=$article_id limit 1";
			$show = $this->db->query($sql);
			if($show->num_rows() > 0 ) {
				if($show->row()->content_type==1){
				return true;
				}
				else{
				return false;	
				}
			} else {
				return false;
			}
		}

		public function get_image($article_id){
			$sql = "select article_media from article where article_id=$article_id limit 1";
			$show=$this->db->query($sql);
			return $show->row()->article_media;
		}

		public function top_news()
		{
			$sql = "select * from article order by created_on DESC limit 5";
			$show = $this->db->query($sql);
			if($show->num_rows() > 0 ) {
				return $show->result();
			} else {
				return array();
			} //end if num_rows
				
		}



		public function set_prev($article_id){
				$sql="select * from article where article_id<$article_id order by article_id desc limit 1";
				$show = $this->db->query($sql);	
				if($show->num_rows() > 0 ) {
				return $show->result();
				} else {
				return array();
				}
		}

		public function set_next($article_id){
			//$max="select max(article_id) from article";
			//if($article_id<$max){
				$sql="select * from article where article_id>$article_id order by article_id limit 1";
				$show = $this->db->query($sql);	
				if($show->num_rows() > 0 ) {
				return $show->result();
				} else {
				return array();
				}
			//}
		}

		public function find_edit($article_id)
		{
			$sql = "select * from article  where article_id=$article_id";
			$show = $this->db->query($sql);
			if($show->num_rows() > 0 ) {
				return $show->row();
			} else {
				return array();
			} //end if num_rows
				
		}



		public function create($data_article){
			$this->db->insert('article',$data_article);
		}

		public function edit($article_id,$data_article){
			$this->db->where('article_id',$article_id)
					 ->update('article',$data_article);
		}

		public function delete($article_id){
			$this->db->where('article_id',$article_id)
					 ->delete('article');
		}	
	
	
		
}  