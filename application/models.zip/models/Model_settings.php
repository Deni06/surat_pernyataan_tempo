<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_settings extends CI_Model {

	public function all_settings(){
		$sql = "select * from all_settings";
		$show=$this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return false;
		}
	}
		/////////////////////////////////
		public function sitename_settings()
		{
			$query = $this->db->query('SELECT  * FROM all_settings WHERE all_name_settings = "site_name"');
			return $query->result();
		}
	public function about_settings()
	{
		$query = $this->db->query('SELECT  * FROM all_settings WHERE all_name_settings = "about"');
		return $query->result();
	}
	public function contact_settings()
	{
		$query = $this->db->query('SELECT  * FROM all_settings WHERE all_name_settings = "contact"');
		return $query->result();
	}
	public function testi_settings()
	{
		$sql = "select * from all_settings WHERE all_name_settings = 'testi'";
		$show=$this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return false;
		}
	}


	public function m_edit_sitename_settings($edit_sitename_is)
		{
				$sitename = 'site_name';
				$this->db->where('all_name_settings',$sitename)
					->update('all_settings',$edit_sitename_is);
		}
		/////////////////////////////////
		public function footer_settings()
		{
			$query = $this->db->query('SELECT  * FROM all_settings WHERE all_name_settings = "footer"');
			return $query->result();
		}
		public function m_edit_footer_settings($edit_footer_is)
		{
				$footer = 'footer';
				$this->db->where('all_name_settings',$footer)
					->update('all_settings',$edit_footer_is);
		}

	public function create($data_setting){
		$this->db->insert('all_settings',$data_setting);
	}

	public function edit($all_id,$data_setting){
		$this->db->where('all_id',$all_id)
			->update('all_settings',$data_setting);
	}

	public function delete($all_id){
		$this->db->where('all_id',$all_id)
			->delete('all_settings');
	}
	public function find_edit($all_id)
	{
		$sql = "select * from all_settings where all_id=$all_id";
		$show = $this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->row();
		} else {
			return array();
		} //end if num_rows

	}





}