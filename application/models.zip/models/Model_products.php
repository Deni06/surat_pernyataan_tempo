<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_products extends CI_Model {
	
		public function all_products()		{ //$show -> guery to get all products from table products
			$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.pro_stock > 0";
			$show=$this->db->query($sql);
			if($show->num_rows() > 0 ) {
					return $show->result();
			} else {
					 return array();
			} //end if num_rows
					
		}//end function all_products
			public function home_products()		{ //$show -> guery to get all products from table products
				$sql = "select * from products";
				$query=$this->db->query($sql);
				if($query->row_array()>0){return $query->row_array();}
				else{return array();}

			}//end function all_products
				public function count_products($cat_id)
				{
					$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.pro_cat=$cat_id";
					$query=$this->db->query($sql);
					return $query->num_rows();
				}
					public function single_product($pro_id){
			$sql = "select p.*,c.cat_name,p.pro_title as pro_name,c2.cat_name as cat_parent ,c.parent_id from products p inner join category c on c.cat_id = p.pro_cat inner join category c2 on c2.cat_id=c.parent_id where p.pro_id=1 limit 1";
			
			$show=$this->db->query($sql);
			if($show->num_rows() > 0 ) {
					return $show->row();
			} else {
					 return array();
			} //end if num_rows		
		}
		public function load_category(){
        	$sql = "select cat_id,cat_name from category where  is_parent=1 ";
        	$show = $this->db->query($sql);
        	$category=array();
        	if($show->result()) {
            	foreach($show->result() as $c){
					$category[$c->cat_id]=$c->cat_name;
            	}
            	return $category;
        	} else {
            	return FALSE;
        	} 
    	}

    	public function load_subcategory($cat_id){
        	$sql = "select cat_id,cat_name from category where parent_id='$cat_id' ";
        	$show = $this->db->query($sql);
        	$category=array();
        	if($show->result()) {
            	foreach($show->result() as $c){
					$category[$c->cat_id]=$c->cat_name;
            	}
            	return $category;
        	} else {
            	return FALSE;
        	} 
    	}
	public function count_search_products($keyword)
	{
		$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.keyword like '%$keyword%'";
		$query=$this->db->query($sql);
		return $query->num_rows();
	}
	public function list_products($limit, $start)
	{
		$sql = "select p.*,c.cat_name,p.pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id LIMIT $start,$limit";
		$show = $this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return array();
		} //end if num_rows
	}
	public function get_featured_products()
	{
		$sql = "select p.*,c.cat_name,p.pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.is_featured=1 limit 4";
		$show = $this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return array();
		} //end if num_rows
	}

		public function dis_products()
		{
			$this->db->distinct();
			$query = $this->db->query('SELECT DISTINCT pro_name FROM products');
			return $query->result();
		}//without repeated values


		public function show_cat($cat_id,$limit,$start)
		{
			$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.pro_cat=$cat_id and p.pro_stock > 0 LIMIT $start,$limit";

			$show = $this->db->query($sql);
			if($show->num_rows() > 0 ) {
				return $show->result();
			} else {
				return array();
			} //end if num_rows
			
		}//end function this --------- this will find product and show all same product
	public function show_search($keyword,$sort,$limit,$start)
	{
		if($sort==1)
		{
			$order= "p.pro_id desc";
		}
		else if($sort==2)
		{
			$order= "p.pro_price asc";
		}
		else if($sort==3)
		{
			$order= "p.pro_price desc";
		}


		$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.keyword like '%$keyword%' order by $order  LIMIT $start,$limit";


		$show = $this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return array();
		} //end if num_rows

	}//end function this --------- this will find product and show all same product
	public function show_cat_price($cat_id,$price_range,$limit,$start)
	{
		if($price_range==1)
		{
			$price="250000 and 500000";
		}
		if($price_range==2)
		{
			$price="500001 and 700000";
		}
		if($price_range==3)
		{
			$price="700001 and 1000000";
		}
		$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.pro_cat=$cat_id AND p.pro_price BETWEEN $price LIMIT $start,$limit";

		$show = $this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return array();
		} //end if num_rows

	}
	public function show_search_price($keyword,$price_range,$limit,$start)
	{
		if($price_range==1)
		{
			$price="250000 and 500000";
		}
		if($price_range==2)
		{
			$price="500001 and 700000";
		}
		if($price_range==3)
		{
			$price="700001 and 1000000";
		}
		$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.keyword=$keyword AND p.pro_price BETWEEN $price LIMIT $start,$limit";

		$show = $this->db->query($sql);
		if($show->num_rows() > 0 ) {
			return $show->result();
		} else {
			return array();
		} //end if num_rows

	}
		public function find($pro_id)//للبحث عن رقم المنتج وتحقق من وجوده 
			//this is for find record id->product
		{
			echo $sql = "select p.*,c.cat_name as pro_name,c.cat_id from products p inner join category c on p.pro_cat=c.cat_id where p.pro_id=$pro_id LIMIT 1";

			$show = $this->db->query($sql);
			if($show->num_rows() > 0 ) {
				return $show->row();
			} else {
				return array();
			} //end if num_rows
				
		}//end function find

	public function get_cat_id_by_pro($pro_id)
	{
		$gry = $this->db->where('pro_id',$pro_id)
			->select('pro_cat')
			->limit(1)
			->get('products');
		if($gry->num_rows() > 0 )
		{
			return $gry->row()->pro_cat;
		}else{

			return 0;
		}
	}
	public function get_sku_by_pro($pro_id)
	{
		$gry = $this->db->where('pro_id',$pro_id)
			->select('pro_sku')
			->limit(1)
			->get('products');
		if($gry->num_rows() > 0 )
		{
			return $gry->row()->pro_sku;
		}else{

			return 0;
		}
	}

	public function getByProductId($pro_id)
	{
		$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.pro_id=$pro_id";
		$product = $this->db->query($sql);
		
			return $product->row_array();
	}//end function member

	public function getByKeyword($keyword)
	{
		$sql = "select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.keyword=$keyword";
		$product = $this->db->query($sql);
		if($product->num_rows() > 0 ) {
			return $product->result();
		} else {
			return array();
		} //end if num_rows

	}//end function member
	public function getByRelatedProduct($pro_id)
	{
		$gry = $this->db->where('pro_id',$pro_id)
			->select('pro_cat')
			->limit(1)
			->get('products');
		$cat=$this->get_cat_id_by_pro($pro_id);
		$sql="select p.*,c.cat_name,pro_title as pro_name from products p inner join category c on p.pro_cat=c.cat_id where p.pro_cat='$cat'  and p.pro_stock > 0 Limit 5";
		$product = $this->db->query($sql);
		if($product->num_rows() > 0 ) {
			return $product->result();
		} else {
			return array();
		} //end 
		

	}
public function getImageProduct($pro_id)
	{
		$gry = $this->db->where('pro_id',$pro_id)
			->select('pro_sku')
			->limit(1)
			->get('products');
		$sku=$this->get_sku_by_pro($pro_id);
		$sql="select * from product_image where pro_sku = '$sku'";
		$product = $this->db->query($sql);
		if($product->num_rows() > 0 ) {
			return $product->result();
		} else {
			return array();
		} //end 
		

	}
	//end function member



	public function create($data_products)//لانشاء منتج جديد
		{
			//guery insert into database 	
			$this->db->insert('products',$data_products);
				
		}//end function craete
		
		public function edit($pro_id,$data_products)//للتعديل على المنتج
		{
			//guery update FROM .. WHERE id->products
			$this->db->where('pro_id',$pro_id)
					->update('products',$data_products);
		}
		
		public function delete($pro_id)//لحذف منتج
		{
			//guery delete id->products
			$this->db->where('pro_id',$pro_id)
					->delete('products');
		}
		
	public function report($report_products)
	{
		
		$this->db->insert('reports',$report_products);
		
	}//end function craete
	
	public function reports()
	{ 
		$report = $this->db->get('reports');
		if($report->num_rows() > 0 ) {
			return $report->result();
		} else {
			return array();
		} //end if num_rows
		
	}//end function report
	
	
	public function del_report($rep_id_product)
	{
		$this->db->where('rep_id_product',$rep_id_product)
		->delete('reports');
	}
	
	
	
		
} //end class Model_products
///////////////////////////////  Model_products : this is use in controller admin/products + home 