<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_customer extends CI_Model {
		
	public function get_shopping_history($user)
	{// get all invoices identified by $user

		$sql = "select s.usr_fullname as reseller,i.*,TIMESTAMPDIFF(HOUR,NOW(),i.due_date)  as is_due
 from invoices i inner join users s on i.user_id= s.usr_id where i.user_id=$user order by i.id desc" ;
		$get_it = $this->db->query($sql);
		if($get_it->num_rows() > 0 )
		{
			return $get_it->result();
		}else{
			return FALSE; //if there are no matching records
		}
	}
	public function get_item($items)
	{// get all invoices identified by $user

		$sql = "select * from products where pro_sku like '%$items%'" ;
		$get_it = $this->db->query($sql);
		if($get_it->num_rows() > 0 )
		{
			return $get_it->result();
		}else{
			return FALSE; //if there are no matching records
		}
	}
	public function process_item($invoice_id,$pro_id,$qty,$price)
	{ 	
				$data = array(
						'invoice_id'		=> $invoice_id,
						'product_id'		=> $pro_id,
						'qty'				=> $qty,
						'price'				=> $price
						
						 );
			$this->db->insert('orders',$data);	
	}
	public function get_shopping_detail($invoice)
	{// get all invoices identified by $user

		$sql = "select i.*,u.usr_fullname as supplier_name,u.usr_phone as supplier_phone,u.usr_name as supplier_email,concat(u.usr_address,',',u.usr_address2,',',u.usr_city,' ',u.usr_zip) as supplier_address from invoices i inner join users u on u.usr_id = i.user_id where i.id = $invoice" ;
		$get_it = $this->db->query($sql);
		if($get_it->num_rows() > 0 )
		{
			return $get_it->result();
		}else{
			return FALSE; //if there are no matching records
		}
	}
	public function get_order_item($invoice)
	{// get all invoices identified by $user

		$sql = "SELECT o.*,concat(p.pro_sku,' - ',p.pro_color,' ',p.pro_title,' (',p.pro_size,')') as product_name,p.pro_sku as sku,p.weight,p.pro_image FROM orders o inner join products p on o.product_id = p.pro_id where o.invoice_id=$invoice" ;
		$get_it = $this->db->query($sql);
		if($get_it->num_rows() > 0 )
		{
			return $get_it->result();
		}else{
			return FALSE; //if there are no matching records
		}
	}
		public function mark_invoice_paid_confirmed($invoice_id,$amount,$account_name,$account_bank,$account_number,$payment_date)
		{//check the invoice
			$ret = TRUE ;
			$is_invoice = $this->db->where('id',$invoice_id)->limit(1)->get('invoices');
			if($is_invoice->num_rows() == 0  )
			{
					$ret = $ret && FALSE;
			}else{//check the amount
			$this->db->where('id',$invoice_id)->update('invoices',
				array(
					'status'=>2,
					'total_paid'=>$amount,
					'account_name'=>$account_name,
					'account_bank'=>$account_bank,
					'account_number'=>$account_number,
					'payment_date'=>$payment_date
			));
				 }
			return $ret;
		}
		public function mark_invoice_delivered($invoice_id,$awb_resi,$delivery_date)
		{//check the invoice
			$ret = TRUE ;
			$is_invoice = $this->db->where('id',$invoice_id)->limit(1)->get('invoices');
			if($is_invoice->num_rows() == 0  )
			{
					$ret = $ret && FALSE;
			}else{//check the amount
			$this->db->where('id',$invoice_id)->update('invoices',
				array(
					'status'=>3,
					'resi_awb'=>$awb_resi,
					'delivery_date'=>$delivery_date
			));
				 }
			return $ret;
		}
		public function mark_invoice_completed($invoice_id)
		{//check the invoice
			$ret = TRUE ;
			$is_invoice = $this->db->where('id',$invoice_id)->limit(1)->get('invoices');
			if($is_invoice->num_rows() == 0  )
			{
					$ret = $ret && FALSE;
			}else{//check the amount
			$this->db->where('id',$invoice_id)->update('invoices',
				array(
					'status'=>4
			));
				 }
			return $ret;
		}
		public function mark_invoice_cancel($invoice_id)
		{//check the invoice
			$ret = TRUE ;
			$is_invoice = $this->db->where('id',$invoice_id)->limit(1)->get('invoices');
			if($is_invoice->num_rows() == 0  )
			{
					$ret = $ret && FALSE;
			}else{//check the amount
			$this->db->where('id',$invoice_id)->update('invoices',
				array(
					'status'=>5
			));
				 }
			return $ret;
		}
		public function process_order($invoice_id,$cust_name,$address,$cust_phone,$notes,$total,$email,$shippingfee,$courier,$citycode,$total_weight)
		{//check the invoice
			$ret = TRUE ;
			/*$is_invoice = $this->db->where('id',$invoice_id)->limit(1)->get('invoices');
			if($is_invoice->num_rows() == 0  )
			{
					$ret = $ret && FALSE;
			}else{//check the amount*/
			$this->db->where('id',$invoice_id)->update('invoices',
				array(
			'customer_name'	=> $cust_name,
			'address_shipping'=>$address,
			'customer_phone'=>$cust_phone,
			'order_notes'=>$notes,
			'total_invoice'=>$total,
			'customer_mail'=>$email,
			'shipping_fee'=>$shippingfee,
			'courier_service'=>$courier,
			'city_code'=>$citycode,
			'total_weight'=>$total_weight,
			'status'=>1
		));
				 //}
			return $ret;
		}
		
	}///end class  ///
	
	
?>
		