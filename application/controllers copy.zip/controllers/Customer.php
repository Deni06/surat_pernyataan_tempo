<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {
		
	public function __construct ()
	{
		parent::__construct();
		$this->load->model('model_customer');
		$this->load->model('model_settings');
		$this->load->model('model_users');
		
	}

	public function index()
	{	
			
	}
	public function common_check($str)
	{
		if ($str == '')
		{
			$this->form_validation->set_message('common_check', ' <div class="alert alert-danger"> <b>%s ,mohon di isi</b></div>');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
	public function order_list()
	{
        $user=$this->session->userdata('userid');
        $data['history'] = $this->model_customer->get_shopping_history($user);
		$this->load->view('list',$data);
			
	}
	public function payment_confirmation()
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	

		$this->form_validation->set_rules('account_bank','Nama Bank','callback_common_check');
		$this->form_validation->set_rules('account_number','No rek','callback_common_check');
		$this->form_validation->set_rules('payment_date','Tanggal Pembayaran','callback_common_check');
		$this->form_validation->set_rules('jam_transfer','Jam Transfer','callback_common_check');
		if($this->form_validation->run()	==	FALSE)
		{

			$invoice_id=$this->input->post('invoice_id');
			$data['invoices']=$this->model_customer->get_shopping_detail($invoice_id);
			$data['orders']=$this->model_customer->get_order_item($invoice_id);
			$this->load->view('customer/shopping_detail',$data);
		}else{
			$invoice_id=$this->input->post('invoice_id');
			$amount=$this->input->post('total_paid');
			$accountbank=$this->input->post('account_bank');
			$accountno=$this->input->post('account_number');
			$accountname=$this->input->post('account_name');
			$paymentdate=$this->input->post('payment_date').' '.$this->input->post('jam_transfer');
			$is_valid = $this->model_customer->mark_invoice_paid_confirmed($invoice_id,$amount,$accountname,$accountbank,$accountno,$paymentdate);
			if ($is_valid)
			{
				$this->session->set_flashdata('message','Thank you ..... we will check on your payment confirmation');
				redirect('customer/shopping_history');
			}else{
				$this->session->set_flashdata('error','something Wrong with invoice.... ! please try again ');
				redirect('customer/shopping_history');
			}
			}
	}
	public function shopping_history()
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		if(!$this->session->userdata('userid'))
		{
			redirect('login');
		}
		else{
		$user=$this->session->userdata('userid');
		$data['history'] = $this->model_customer->get_shopping_history($user);
		$this->load->view('customer/shopping_history_list',$data);
		}
	}
	public function shopping_detail($invoiceid)
	{
	$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		if(!$this->session->userdata('userid'))
		{
			redirect('login');
		}
		else{
			$data['invoices']=$this->model_customer->get_shopping_detail($invoiceid);
			$data['orders']=$this->model_customer->get_order_item($invoiceid);
			$this->load->view('customer/shopping_detail',$data);
		}
	}
	public function shopping_address($invoiceid)
	{
	$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		if(!$this->session->userdata('userid'))
		{
			redirect('login');
		}
		else{
			if($this->input->get('kode_barang'))
			{
				$data['items'] = $this->model_customer->get_item($this->input->get('kode_barang'));
			}
			if($this->input->get('add_item'))
			{
				$str = explode("-", $this->input->get('add_item'));
				$pro_id = $str[0];
				$qty = $this->input->get('qty');
				$price = $str[1] * $qty;
				$is_processed = $this->model_customer->process_item($invoiceid,$pro_id,$qty,$price);
			}
			$data['invoices']=$this->model_customer->get_shopping_detail($invoiceid);
			$data['orders']=$this->model_customer->get_order_item($invoiceid);
			$this->load->view('customer/address_confirmation',$data);
		}
	}
	public function process($invoiceid)
	{
		
			$this->form_validation->set_rules('shipping_name','Nama','callback_common_check');
			//$this->form_validation->set_rules('shipping_address1','Alamat','callback_common_check');
			$this->form_validation->set_rules('input_city','Provinsi/Kota','callback_common_check');
			//$this->form_validation->set_rules('shipping_zip','Kode Pos','callback_common_check');
			//$this->form_validation->set_rules('shipping_phone','Telp/Hp','callback_common_check');
			//$this->form_validation->set_rules('shipping_email','Telp/Hp','callback_common_check');
			$this->form_validation->set_rules('ongkir','Paket Kurir','callback_common_check');

			if($this->form_validation->run()	==	FALSE)
			{
				$this->session->set_flashdata('error','Mohon di isi semua field dengan benar');
				redirect('customer/shopping_address/'.$invoiceid.'/invalid');

			}
			else{
			$cust_name=$this->input->post('shipping_name');
			$cust_address=$this->input->post('shipping_address1').",".$this->input->post('shipping_address2').",".$this->input->post('input_city').",".$this->input->post('shipping_zip');
			$cust_phone = $this->input->post('shipping_phone');
			$cust_notes=$this->input->post('shipping_notes');
			$total=$this->input->post('total');
			$email=$this->input->post('shipping_email');
			$citycode = $this->input->post('shipping_citycode');
			$total_weight=$this->input->post('berat');
			$shipping_fee=$this->input->post('ongkir');
			$courier=$this->input->post('courier');
			$is_processed = $this->model_customer->process_order($invoiceid,$cust_name,$cust_address,$cust_phone,$cust_notes,$total,$email,$shipping_fee,$courier,$citycode,$total_weight);

		if($is_processed)
		{
			redirect('customer/shopping_detail/'.$invoiceid);
		}else{
			$this->session->set_flashdata('error','Failed To Processed Your Order ! , please try again');
			redirect('customer/shopping_address/'.$invoiceid.'/error');
		}
	}
}

}//end class
