<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class product extends CI_Controller {

    public function __construct ()
    {
        parent::__construct();
        //load model -> model_products
        $this->load->helper('url');
        $this->load->database();
        $this->load->library('pagination');
        $this->load->model('model_products');
        $this->load->model('model_category');
        $this->load->model('model_settings');
    }

    public function index()
    {
        //pagination settings
        redirect(site_url('product/all/'));

    }
    public function all()
    {
        $data['get_about'] = $this->model_settings->about_settings();
        $data['get_contact'] = $this->model_settings->contact_settings();
        $config['base_url'] = site_url('product/all');
        $config['total_rows'] = $this->db->count_all('products');

        $config['per_page'] = "10";
        $config["uri_segment"] = 3;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '<i class="icon icon-arrow-prev"></i>';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '<i class="icon icon-arrow-next"></i>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data['category'] = $this->model_category->cat_products();
        $data['subcategory']=$this->model_category->subcat_products();
        $data['products'] = $this->model_products->list_products($config['per_page'],$data['page']);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('this_products',$data);
    }


    public function category()
    {
        $data['get_about'] = $this->model_settings->about_settings();
        $data['get_contact'] = $this->model_settings->contact_settings();
        $cat_id=$this->uri->segment(3);
        $price_range=$this->uri->segment(4);
        $config['base_url'] = site_url('product/category/'.$cat_id);
        $config['total_rows'] = $this->model_products->count_products($cat_id);
        $data['total']=$this->model_products->count_products($cat_id);
        $config['per_page'] = "10";

        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '<i class="icon icon-arrow-prev"></i>';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '<i class="icon icon-arrow-next"></i>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';


        $this->pagination->initialize($config);
        $data['cat_name'] = $this->model_category->get_cat_name($cat_id);
        $data['category'] = $this->model_category->cat_products();
        $data['subcategory']=$this->model_category->subcat_products();
       if(!$price_range) {

           $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
           $config["uri_segment"] = 3;
           $data['products'] = $this->model_products->show_cat($cat_id, $config['per_page'], 0); //for showme function in home/showme
       }
        else
        {
            $data['page'] = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
            $config["uri_segment"] = 5;
            $data['products'] = $this->model_products->show_cat_price($cat_id,$price_range, $config['per_page'], 0); //for showme function in home/showme
        }
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('this_products',$data);

    }
    public function search()
    {
        $data['get_about'] = $this->model_settings->about_settings();
        $data['get_contact'] = $this->model_settings->contact_settings();
        $keyword=$this->input->get('keyword');
        $config['base_url'] = site_url('product/search/'.$keyword);
        $config['total_rows'] = $this->model_products->count_search_products($keyword);
        $data['total']=$this->model_products->count_search_products($keyword);
        $config['per_page'] = "10";

        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '<i class="icon icon-arrow-prev"></i>';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '<i class="icon icon-arrow-next"></i>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';


        $this->pagination->initialize($config);
        $data['keyword'] = $this->input->post('keyword');
        $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config["uri_segment"] = 3;


        $sort=$this->input->get('sort');


        $data['products'] = $this->model_products->show_search($keyword,$sort, $config['per_page'], 0); //for showme function in home/showme

        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('search_result',$data);

    }
    public function add_to_cart($pro_id,$send)
    {
        $product = $this->model_products->find($pro_id);
        $data = array(
            'id'      => $product->pro_id,
            'qty'     => 1,
            'price'   => $product->pro_price,
            'name'    => $product->pro_name,
            'color'   => $product->pro_color,
            'title'	  => $product->pro_title,
            'weight'  => $product->weight
        );

        $this->cart->insert($data);
        if ($send == 'add')
        {
            redirect('home/showme/'.$product->pro_name);
        }else{
            redirect(base_url());
        }

    }

    public function cart()
    {
        $data['get_about'] = $this->model_settings->about_settings();
        $data['get_contact'] = $this->model_settings->contact_settings();
        $data['get_sitename'] = $this->model_settings->sitename_settings();
        $data['get_footer'] = $this->model_settings->footer_settings();
        $this->load->view('show_cart',$data);

    }//view inside cart

    public function clear_cart()
    {
        $this->cart->destroy();
        redirect(base_url());
    }

    public function report($pro_id)
    {
        $product = $this->model_products->find($pro_id);


        if($this->session->userdata('group')	!=	('2' ||'3'))
        {
            $group_usr = Gost;
            $name_usr = Gost;
        }else{
            $group_usr = $this->session->userdata('group');
            $name_usr = $this->session->userdata('username');
        }



        $report_products = array
        (
            'rep_id_product'			=> $product->pro_id,
            'rep_name'					=> $product->pro_name,
            'rep_title_product'			=> $product->pro_title,
            'rep_usr_name'				=> $name_usr,
            'rep_usr_group'				=> $group_usr
        );
        $this->model_products->report($report_products);
        redirect(base_url());

    }
    public function detail($pro_id)
    {
        $data['get_about'] = $this->model_settings->about_settings();
        $data['get_contact'] = $this->model_settings->contact_settings();
        //$pro_id=$this->uri->segment(3);
        $data['products'] = $this->model_products->getByProductId($pro_id);
         $data['gallery_pro']=$this->model_products->getImageProduct($pro_id);
        $data['related_pro']=$this->model_products->getByRelatedProduct($pro_id);
        $this->load->view('product_detail',$data);

    }
}
