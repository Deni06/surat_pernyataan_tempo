<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		if(!$this->session->userdata('username'))
		{
			redirect('login');
		}
		$this->load->model('model_settings');
		$this->load->model('model_orders');
		$this->load->model('model_users');
	}
	
	public function index()
	{

		$is_processed = $this->model_orders->process();
		if($is_processed)
		{
			$this->cart->destroy();
			redirect('order/success');
		}else{
				$this->session->set_flashdata('error','Failed To Processed Your Order ! , please try again');
				redirect('home/cart');
			
			 }
	}

	public function success($invoice_id)
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$data['invoices'] = $this->model_orders->get_invoice_by_id($invoice_id);
		$this->load->view('order_success',$data);
			
	}
	
	public function confirmation()
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		if(!$this->session->userdata('username'))
		{
			redirect('login');
		}
		$data['user']=$this->model_users->getmembers();
		$this->load->view('order_confirmation',$data);

	}
	public function checkout()
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		if(!$this->session->userdata('username'))
		{
			redirect('login');
		}
		$data['user']=$this->model_users->getmembers();
		$this->load->view('order_checkout',$data);

	}


	public function common_check($str)
	{
		if ($str == '')
		{
			$this->form_validation->set_message('common_check', ' <div class="alert alert-danger"> <b>%s harus di isi</b></div>');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
	public function process()
	{
		date_default_timezone_set('Asia/Jakarta');
		if($this->input->post('type_address')==1)
		{
			$this->form_validation->set_rules('ongkir','Paket','callback_common_check');
			$this->form_validation->set_rules('account_bank','Metode Pembayaran','callback_common_check');
			$cust_name=$this->input->post('usr_fullname');
			$cust_address=$this->input->post('usr_address');
			$cust_phone=$this->input->post('usr_phone');
			$cust_notes=$this->input->post('usr_notes');
			$total=$this->input->post('total');
			$email=$this->input->post('usr_email');
			$citycode = $this->input->post('usr_citycode');
			$total_weight=$this->input->post('berat');
			$shipping_fee=$this->input->post('ongkir');
			$courier=$this->input->post('courier');
			$payment_method=$this->input->post('account_bank');

		}else if($this->input->post('type_address')==2){
			$this->form_validation->set_rules('shipping_name','Nama','callback_common_check');
			$this->form_validation->set_rules('shipping_address1','Alamat','callback_common_check');
			$this->form_validation->set_rules('input_city','Provinsi/Kota','callback_common_check');
			$this->form_validation->set_rules('shipping_zip','Kode Pos','callback_common_check');
			$this->form_validation->set_rules('shipping_phone','Telp/Hp','callback_common_check');
			$this->form_validation->set_rules('shipping_email','Telp/Hp','callback_common_check');
			$this->form_validation->set_rules('ongkir','Paket Kurir','callback_common_check');
			$this->form_validation->set_rules('account_bank','Metode Pembayaran','callback_common_check');
			$cust_name=$this->input->post('shipping_name');
			$cust_address=$this->input->post('shipping_address1').",".$this->input->post('shipping_address2').",".$this->input->post('input_city').",".$this->input->post('shipping_zip');
			$cust_phone = $this->input->post('shipping_phone');
			$cust_notes=$this->input->post('shipping_notes');
			$total=$this->input->post('total');
			$email=$this->input->post('shipping_email');
			$citycode = $this->input->post('shipping_citycode');
			$total_weight=$this->input->post('input_berat');
			$shipping_fee=$this->input->post('input_ongkir');
			$courier=$this->input->post('input_paket');
			$payment_method=$this->input->post('account_bank');
			}
		if($this->form_validation->run()	==	FALSE)
		{
			$data['user']=$this->model_users->getmembers();
			$this->load->view('order_confirmation',$data);
		}
		else{
		$is_processed = $this->model_orders->process_order($cust_name,$cust_address,$cust_phone,$cust_notes,$total,$email,$shipping_fee,$payment_method,$courier,$citycode,$total_weight);

		if($is_processed)
		{
			$this->cart->destroy();
			redirect('order/success');
		}else{
			$this->session->set_flashdata('error','Failed To Processed Your Order ! , please try again');
			redirect('home/cart');
		}
	}}
public function process_checkout()
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		date_default_timezone_set('Asia/Jakarta');
			$this->form_validation->set_rules('shipping_name','Nama','callback_common_check');
			$this->form_validation->set_rules('shipping_address1','Alamat','callback_common_check');
			$this->form_validation->set_rules('shipping_phone','Phone','callback_common_check');
			$this->form_validation->set_rules('reseller_name','Nama Supplier','callback_common_check');
			$this->form_validation->set_rules('reseller_address','Alamat Supplier','callback_common_check');
			$this->form_validation->set_rules('reseller_phone','Hp Supplier','callback_common_check');
			//$this->form_validation->set_rules('shipping_email','Telp/Hp','callback_common_check');
			$cust_name=$this->input->post('shipping_name');
			$cust_address=$this->input->post('shipping_address1').",".$this->input->post('shipping_address2').",".$this->input->post('input_city').",".$this->input->post('shipping_zip');
			$cust_phone = $this->input->post('shipping_phone');
			$cust_notes=$this->input->post('shipping_notes');
			$total=$this->input->post('total');
			$email=$this->input->post('shipping_email');
			$citycode = $this->input->post('shipping_citycode');
			$total_weight=$this->input->post('input_berat');
			$shipping_fee=$this->input->post('input_ongkir');
			$courier=$this->input->post('input_paket');
			$payment_method=$this->input->post('account_bank');
			$reseller_name = $this->input->post('reseller_name');
			$reseller_phone = $this->input->post('reseller_phone');
			$reseller_address = $this->input->post('reseller_address');


			
		if($this->form_validation->run()	==	FALSE)
		{
			$data['user']=$this->model_users->getmembers();
			$this->load->view('order_checkout',$data);
		}
		else{
		$is_processed = $this->model_orders->process_order($cust_name,$cust_address,$cust_phone,$cust_notes,$total,$email,$shipping_fee,$payment_method,$courier,$citycode,$total_weight,$reseller_name,$reseller_phone,$reseller_address);

		if($is_processed)
		{
			$this->cart->destroy();

			redirect('order/success/'.$is_processed);
		}else{
			$this->session->set_flashdata('error','Failed To Processed Your Order ! , please try again');
			redirect('home/cart');
		}
	}
	}

	public function remove_cart($rowid,$send)
	{
		$data = array( 'rowid' => $rowid,
			'qty' =>0
		);
		$this->cart->update($data);
		if ($send == 'del')
		{
			redirect('order/confirmation/');
		}else{
			redirect(base_url());
		}
	}
}//end  class