<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Article extends CI_Controller {
		
	public function __construct ()
	{
		parent::__construct();
		if($this->session->userdata('group')!=	('1' ||'2') )
		{
			$this->session->set_flashdata('error','Sorry You Are Not Logged in !');
			redirect('login');	
		}
		
		//load model -> model_products
		$this->load->model('model_products');
		$this->load->model('model_users');
		$this->load->model('model_article');
		$this->load->model('model_settings');
		$this->load->model('model_category');
	}
	
	public function index()
	{		
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$data['articles']=$this->model_article->all_article();
		$this->load->view('backend/master_article',$data);
	}

	public function create()
	{		
		date_default_timezone_set("Asia/Jakarta");
		$this->form_validation->set_rules('article_title','Judul Artikel','required');
		$this->form_validation->set_rules('content_type','Tipe Konten','required');
		
		if($this->input->post('content_type')=="1"){
			if (empty($_FILES['userfile']['name'])){
			$this->form_validation->set_rules('image','Gambar','required');
			}
		}
		else if($this->input->post('content_type')=="2"){
			$this->form_validation->set_rules('video','Video','required');	
		}

		$this->form_validation->set_rules('article_content','Konten','required');

		if ($this->form_validation->run() == FALSE){
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$data['articles']=$this->model_article->all_article();
		$this->load->view('backend/form_create_article',$data);
		}
		else{
			if($this->input->post('content_type')=="1"){ //gambar is checked
			$config['upload_path']          = './assets/article/';
			$config['allowed_types']        = 'jpg|png';
			$config['file_name']			= $this->input->post('article_title');
			$config['max_size']             = 2048000;// = MB
			$config['max_width']            = 2000;
			$config['max_height']           = 2000;
			$this->load->library('upload', $config);

				if ( !$this->upload->do_upload()){
					$data['get_sitename'] = $this->model_settings->sitename_settings();
					$data['get_footer'] = $this->model_settings->footer_settings();	
					$data['articles']=$this->model_article->all_article();
					$data['error']=$this->upload->display_errors();
					$this->load->view('backend/form_create_article',$data);
				}else{
				$upload_image = $this->upload->data();
				$data_article = array
				(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_media'			=> $upload_image['file_name'],
					'article_content'		=> set_value('article_content'),
					'created_by'			=> $this->session->userdata('userfullname'),
					'created_on'			=> date("Y/m/d H:i:s", time())
				);

				$this->model_article->create($data_article);
				redirect('admin/article');
					}
				}
				else if($this->input->post('content_type')=="2"){ //video is checked
					$data_article = array
				(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_media'			=> set_value('video'),
					'article_content'		=> set_value('article_content'),
					'created_by'			=> $this->session->userdata('userfullname'),
					'created_on'			=> date("Y/m/d H:i:s", time())
				);

				$this->model_article->create($data_article);
				redirect('admin/article');
			}
		}
	}


	public function edit($article_id)
	{		
		date_default_timezone_set("Asia/Jakarta");
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();

		$this->form_validation->set_rules('article_title','Judul Artikel','required');
		$this->form_validation->set_rules('content_type','Tipe Konten','required');
		

		$this->form_validation->set_rules('article_content','Konten','required');

		if ($this->form_validation->run() == FALSE){
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$data['articles']=$this->model_article->find_edit($article_id);
		$this->load->view('backend/form_update_article',$data);
		}
		else{
			if($this->input->post('content_type')=="1"){ //gambar is checked
				if($_FILES['userfile']['name'] != '') //content gambar is not null
				{
			$config['upload_path']          = './assets/article/';
			$config['allowed_types']        = 'jpg|png';
			$config['file_name']			= $this->input->post('article_title');
			$config['max_size']             = 2048000;// = MB
			$config['max_width']            = 2000;
			$config['max_height']           = 2000;
			$this->load->library('upload', $config);

				if ( !$this->upload->do_upload()){
					$data['get_sitename'] = $this->model_settings->sitename_settings();
					$data['get_footer'] = $this->model_settings->footer_settings();	
					$data['articles']=$this->model_article->find_edit($article_id);
					$data['error']=$this->upload->display_errors();
					$this->load->view('backend/form_update_article',$data);
				}else{
				$upload_image = $this->upload->data();
				$data_article = array
				(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_media'			=> $upload_image['file_name'],
					'article_content'		=> set_value('article_content'),
					
				);

				$this->model_article->edit($article_id,$data_article);
				redirect('admin/article');
						}
				}else{ //content gambar is null --> gambar still same as before
				$data_article = array
				(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_content'		=> set_value('article_content'),
					
				);

				$this->model_article->edit($article_id,$data_article);
				redirect('admin/article');
					}
				}

				else if($this->input->post('content_type')=="2"){ //video is checked
					if($this->input->post('video')==null){  //video content is null
						$data_article = array
						(
							'article_title'			=> set_value('article_title'),
							'content_type'			=> set_value('content_type'),
							'article_media'			=> $data['article_media'],
							'article_content'		=> set_value('article_content'),
							
						);
					}
					else{
						$data_article = array
						(
							'article_title'			=> set_value('article_title'),
							'content_type'			=> set_value('content_type'),
							'article_media'			=> set_value('video'),
							'article_content'		=> set_value('article_content'),

						);
					}

				$this->model_article->edit($article_id,$data_article);
				redirect('admin/article');
			}
		}
	}

	public function delete($article_id)
	{
		
		$contenttype=$this->model_article->get_content_type($article_id);
		if($contenttype==true){
			$this->load->helper('file');
			$image=$this->model_article->get_image($article_id);
			unlink(("./assets/article/".$image));
		}
		$this->model_article->delete($article_id);
		redirect('admin/article');
	}

	
}



