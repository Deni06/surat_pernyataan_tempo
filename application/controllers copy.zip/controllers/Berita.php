<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berita extends CI_Controller {

    public function __construct ()
    {
        parent::__construct();
        $this->load->model('model_users');
        $this->load->model('model_settings');
        $this->load->model('model_article');
        $this->load->model('model_settings');
        $this->load->library('pagination');
    }

    public function index()
    {
        redirect('berita/view');
    }
    public function view()
    {
        $data['get_about'] = $this->model_settings->about_settings();
        $data['get_contact'] = $this->model_settings->contact_settings();
        $config['base_url'] = site_url('berita/view');
        $config['total_rows'] = $this->db->count_all('article');

        $config['per_page'] = "5";
        $config["uri_segment"] = 3;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '<i class="icon icon-arrow-prev"></i>';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '<i class="icon icon-arrow-next"></i>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        //$config['use_page_numbers'] = TRUE;

        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data['articles']=$this->model_article->show_article_per_page($data['page'],$config['per_page']);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->view('article_view',$data);
    }
    public function detail($article_id)
    {
        $data['get_about'] = $this->model_settings->about_settings();
        $data['get_contact'] = $this->model_settings->contact_settings();
        $data['articles']=$this->model_article->find($article_id);
        $data['news']=$this->model_article->top_news();
        $data['prevs']=$this->model_article->set_prev($article_id);
        $data['nexts']=$this->model_article->set_next($article_id);
        $this->load->view('article_detail',$data);
    }
}
?>