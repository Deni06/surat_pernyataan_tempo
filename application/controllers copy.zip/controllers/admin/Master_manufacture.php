<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_manufacture extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('group')!=  ('1' ||'2') )
        {
            $this->session->set_flashdata('error','Sorry You Are Not Logged in !');
            redirect('login');  
        }
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('model_manufacture');
        $config['upload_path']          = './assets/img/baner/';//base_url('assets/uploads/');
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 2048000;// = MB
        $config['overwrite']            = TRUE;
        $config['max_width']            = 2000;
        $config['max_height']           = 2000;
        $config['remove_spaces']        = FALSE;
        $this->load->library('upload', $config);
    }

    public function index()
    {
        $data['manufacture'] = $this->model_manufacture->load_all_manufacture();
        $this->load->view('backend/manufacture',$data);
 
    }

    public function ajax_add()
    {
        $this->_validate();

        $data = array(
            'manufacture_name' => $this->input->post('manufacture_name'),
            'manufacture_img' => $_FILES['userfile']['name']
        );

        $insert = $this->model_manufacture->save($data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_update()
    {
        $this->_validate_update();

        if(empty($_FILES['userfile']['name'])){
            $data = array(
            'manufacture_name' => $this->input->post('manufacture_name')
            );
        }
        elseif(!empty($_FILES['userfile']['name'])){
            $this->model_manufacture->delete_image($this->input->post('id'));
            $data = array(
            'manufacture_name' => $this->input->post('manufacture_name'),
            'manufacture_img' => $_FILES['userfile']['name']
            );
        }
        
        $this->model_manufacture->update(array('manufacture_id' => $this->input->post('id')), $data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_delete($id)
    {
        $this->model_manufacture->delete_by_id($id);
        echo json_encode(array("status" => TRUE));
    }
    private function _validate()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if($this->input->post('manufacture_name') == '')
        {
            $data['inputerror'][] = 'manufacture_name';
            $data['error_string'][] = 'Manufacture Name is required';
            $data['status'] = FALSE;
        }

        if(! $this->upload->do_upload('userfile')){
            $data['inputerror'][] = 'userfile';
            $data['error_string'][] = $this->upload->display_errors('','');
            $data['status'] = FALSE;
        }
        elseif($this->upload->do_upload('userfile')){
            $upload_image = $this->upload->data();
        }

        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

    private function _validate_update()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if(empty($_FILES['userfile']['name'])){
            if($this->input->post('manufacture_name') == '')
            {
                $data['inputerror'][] = 'manufacture_name';
                $data['error_string'][] = 'Manufacture Name is required';
                $data['status'] = FALSE;
            }
        }
        elseif(!empty($_FILES['userfile']['name'])){
            if($this->input->post('manufacture_name') == '')
            {
                $data['inputerror'][] = 'manufacture_name';
                $data['error_string'][] = 'Manufacture Name is required';
                $data['status'] = FALSE;
            }

            if(! $this->upload->do_upload('userfile')){
                $data['inputerror'][] = 'userfile';
                $data['error_string'][] = $this->upload->display_errors('','');
                $data['status'] = FALSE;
            }
            elseif($this->upload->do_upload('userfile')){
                $upload_image = $this->upload->data();
            }
        }
        
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }



}