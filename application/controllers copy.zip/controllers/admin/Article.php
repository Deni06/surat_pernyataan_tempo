<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Article extends CI_Controller {
		
	public function __construct ()
	{
		parent::__construct();
		if($this->session->userdata('group')!=	('1' ||'2') )
		{
			$this->session->set_flashdata('error','Sorry You Are Not Logged in !');
			redirect('login');	
		}
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('model_article');

	}
	
	public function index()
	{		
	
		$data['articles']=$this->model_article->all_article();
		$this->load->view('backend/master_article',$data);
	}

	public function add_article()
	{	
		$data['radiovalue1']=null;
		$data['radiovalue2']=null;
		$data['error']=null;
		$this->load->view('backend/form_create_article',$data);

	}

	public function create()
	{		
		
		$this->form_validation->set_rules('article_title','Title','required');
		$this->form_validation->set_rules('content_type','Content Type','required');
		$radio_val=null;

		if($this->input->post('content_type')=="1"){
			if (empty($_FILES['userfile']['name'])){
				$this->form_validation->set_rules('userfile','Image','required');
				$radio_val=$this->input->post('content_type');
			}
			elseif(!empty($_FILES['userfile']['name'])){
				$radio_val=$this->input->post('content_type');
			}
		}
		elseif($this->input->post('content_type')=="2"){
			$this->form_validation->set_rules('video','Video','required|valid_url');	
			$radio_val=$this->input->post('content_type');
		}

		$this->form_validation->set_rules('article_content','Content','required');

		if ($this->form_validation->run() == FALSE){
			if($radio_val==null){
				$data['radiovalue1']=null;
				$data['radiovalue2']=null;
			}
			elseif($radio_val=='1'){
				$data['radiovalue1']='1';
				$data['radiovalue2']=null;
			}
			elseif($radio_val=='2'){
				$data['radiovalue1']=null;
				$data['radiovalue2']='2';
			}
				$data['error']=null;
				$this->load->view('backend/form_create_article',$data);
		}
		else{
			if($this->input->post('content_type')=="1"){ 
				$config['upload_path']          = './assets/article/';
				$config['allowed_types']        = 'jpg|png';
				$config['max_size']             = 2048000;// = MB
				$config['overwrite']			= TRUE;
				$config['max_width']            = 2000;
				$config['max_height']           = 2000;
				$config['remove_spaces']		= FALSE;
				
				$this->load->library('upload', $config);

				if ( !$this->upload->do_upload('userfile')){
					$data['radiovalue1']='1';
					$data['radiovalue2']=null;
					$data['error2']=null;
					$data['error']=$this->upload->display_errors('<p style="color:#FF0000;font-style:italic"> *','</p>');
					$this->load->view('backend/form_create_article',$data);
				}else{
				$upload_image = $this->upload->data();
				$data_article = array
				(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_media'			=> $upload_image['file_name'],
					'article_content'		=> set_value('article_content'),
					'created_by'			=> $this->session->userdata('userfullname'),
					'created_on'			=> date("Y/m/d H:i:s", time())
				);

				$this->model_article->create($data_article);
				redirect('admin/article');
					}
				}
				else if($this->input->post('content_type')=="2"){ //video is checked
					$data_article = array
				(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_media'			=> set_value('video'),
					'article_content'		=> set_value('article_content'),
					'created_by'			=> $this->session->userdata('userfullname'),
					'created_on'			=> date("Y/m/d H:i:s", time())
				);

				$this->model_article->create($data_article);
				redirect('admin/article');
			}
		}
	}


	public function edit($article_id)
	{		
		$this->form_validation->set_rules('article_title','Title','required');
		$this->form_validation->set_rules('content_type','Content Type','required');
		$radio_val=null;

		if($this->input->post('content_type')=="1"){
				$radio_val=$this->input->post('content_type');
		}
		elseif($this->input->post('content_type')=="2"){
			$this->form_validation->set_rules('video','Video','required|valid_url');	
			$radio_val=$this->input->post('content_type');
		}

		$this->form_validation->set_rules('article_content','Content','required');

		if ($this->form_validation->run() == FALSE){
		if($radio_val==null){
				$data['radiovalue1']=null;
				$data['radiovalue2']=null;
			}
			elseif($radio_val=='1'){
				$data['radiovalue1']='1';
				$data['radiovalue2']=null;
			}
			elseif($radio_val=='2'){
				$data['radiovalue1']=null;
				$data['radiovalue2']='2';
			}
				$data['error']=null;
				$data['articles']=$this->model_article->find_edit($article_id);
				$this->load->view('backend/form_update_article',$data);
		}
		else{
			if($this->input->post('content_type')=="1"){ //gambar is checked
				if($_FILES['userfile']['name'] != '') //content gambar is not null
				{
				$config['upload_path']          = './assets/article/';
				$config['allowed_types']        = 'jpg|png';
				$config['max_size']             = 2048000;// = MB
				$config['overwrite']			= TRUE;
				$config['max_width']            = 2000;
				$config['max_height']           = 2000;
				$config['remove_spaces']		= FALSE;
			
				$this->load->library('upload', $config);
				do{
				if ( !$this->upload->do_upload('userfile')){
					$data['radiovalue1']='1';
					$data['radiovalue2']=null;
					$data['error2']=null;
					$data['error']=$this->upload->display_errors('<p style="color:#FF0000;font-style:italic"> *','</p>');
					$data['articles']=$this->model_article->find_edit($article_id);
					$this->load->view('backend/form_update_article',$data);
					break;
				}elseif($this->upload->do_upload('userfile')){
					
					$upload_image = $this->upload->data();
					$data_article = array
					(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_media'			=> $upload_image['file_name'],
					'article_content'		=> set_value('article_content'),
					
					);
					$this->model_article->delete_image($article_id);
					$this->model_article->edit($article_id,$data_article);
					redirect('admin/article');
					break;
					}
				}while(0);
			}
			elseif($_FILES['userfile']['name'] == ''){ //content gambar is null --> gambar still same as before
				$data_article = array
				(
					'article_title'			=> set_value('article_title'),
					'content_type'			=> set_value('content_type'),
					'article_content'		=> set_value('article_content'),
					
				);
				$this->model_article->edit($article_id,$data_article);
				redirect('admin/article');
					}
				}

				elseif($this->input->post('content_type')=="2"){ //video is checked
					
					if($this->input->post('video')==null){  //video content is null
						$data_article = array
						(
							'article_title'			=> set_value('article_title'),
							'content_type'			=> set_value('content_type'),
							'article_media'			=> $data['article_media'],
							'article_content'		=> set_value('article_content'),
							
						);
					}
					else{
						$data_article = array
						(
							'article_title'			=> set_value('article_title'),
							'content_type'			=> set_value('content_type'),
							'article_media'			=> set_value('video'),
							'article_content'		=> set_value('article_content'),

						);
					}
					$this->model_article->delete_image($article_id);
				$this->model_article->edit($article_id,$data_article);
				redirect('admin/article');
			}
		}
	}

	public function delete($article_id)
	{
		
		$this->model_article->delete($article_id);
		redirect('admin/article');
	}

	
}



