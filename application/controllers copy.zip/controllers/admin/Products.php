<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {
		
	public function __construct ()
	{
		parent::__construct();
		if($this->session->userdata('group')!=	('1' ||'2') )
		{
			$this->session->set_flashdata('error','Sorry You Are Not Logged in !');
			redirect('login');	
		}
		
		//load model -> model_products
		$this->load->model('model_products');
		$this->load->model('model_users');
		$this->load->model('model_settings');
		$this->load->model('model_category');
	}
	
	public function index()
	{	
		$data['products'] = $this->model_products->all_products();		
		$this->load->view('backend/master_product',$data);
	}

	public function index1()
	{	
		$data['products'] = $this->model_products->all_products();	
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$this->load->view('backend/view_product',$data);
	}

	public function create()
	{
		$data['category'] = $this->model_category->subcat_products();
		$this->load->view('backend/add_product',$data);

	}///end class create ///

	public function create_product()
	{
		//$this->form_validation->set_rules('weight','Berat','required');
		$this->form_validation->set_rules('pro_title','Kode Barang','required');
		//$this->form_validation->set_rules('pro_description','Product Description','required');
		//$this->form_validation->set_rules('pro_price','Harga','required|integer');
		//$this->form_validation->set_rules('diskon','Diskon','required|integer');
		//$this->form_validation->set_rules('pro_color','Warna','required');
		//$this->form_validation->set_rules('userfile','image error','required');
		$feature=$this->input->post('feature');

		if ($this->form_validation->run() == FALSE)
		{
			$data['category'] = $this->model_category->subcat_products();
			$this->load->view('backend/form_create_product',$data);

		}else{
			//load uploading file
			$config['upload_path']          = './assets/uploads/';
			$config['allowed_types']        = 'jpg|png';
			$config['file_name']			= $this->input->post('pro_color').'-'.$this->input->post('pro_title');
			$config['max_size']             = 2048000;// = MB
			$config['max_width']            = 2000;
			$config['max_height']           = 2000;
			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload())
			{
			$data['category'] = $this->model_category->subcat_products();
				$this->load->view('backend/form_create_product',$data);


			}else{
				// if form_validation = true  -> insert into db
				$upload_image = $this->upload->data();
				$data_products = array
				(
					'pro_color'			=> set_value('pro_color'),
					'pro_title'			=> set_value('pro_title'),
					'pro_sku'			=> set_value('pro_sku'),
					'pro_size'			=> set_value('pro_size'),
					'pro_description'	=> set_value('pro_description'),
					'pro_price'			=> set_value('pro_price'),
					'diskon'			=> set_value('diskon'),
					'weight'			=> set_value('weight'),
					'keyword'			=> set_value('keyword'),
					'pro_cat'			=> set_value('pro_cat'),
					'is_featured'		=> $feature,
					'pro_image'			=> $upload_image['file_name']

				);//end array data_products

				$this->model_products->create($data_products);
				redirect('admin/products');
			} //end if uploading

		}//end if form_validation
	}
	public function edit($pro_id)
	{
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();
		$this->form_validation->set_rules('weight','Berat','required');
		$this->form_validation->set_rules('pro_title','Kode Barang','required');
		$this->form_validation->set_rules('pro_description','Product Description','required');
		$this->form_validation->set_rules('pro_price','Harga','required|integer');
		$this->form_validation->set_rules('diskon','Diskon','required|integer');
		$this->form_validation->set_rules('pro_color','Warna','required');
		
		if ($this->form_validation->run() == FALSE)
			{
				$data['category'] = $this->model_category->subcat_products();
				$data['product'] = $this->model_products->find($pro_id);
				$this->load->view('backend/form_update_product',$data);
			} else {
				if($_FILES['userfile']['name'] != '')
				{
					//load uploading file 
						$config['upload_path']          = './assets/uploads/';
						$config['allowed_types']        = 'jpg|png';
						$config['max_size']             = 2000;// = MB
						$config['max_width']            = 2000;
						$config['max_height']           = 2000;
						$this->load->library('upload', $config);
						
					if ( ! $this->upload->do_upload())
					{	$data['category'] = $this->model_category->subcat_products();
						$data['product'] = $this->model_products->find($pro_id);
						$this->load->view('backend/form_update_product',$data);
						
					}else{
							$upload_image = $this->upload->data();
							$data_products = array(
								'pro_color'			=> set_value('pro_color'),
								'pro_title'			=> set_value('pro_title'),
								'pro_description'	=> set_value('pro_description'),
								'pro_price'			=> set_value('pro_price'),
								'diskon'			=> set_value('diskon'),
								'weight'			=> set_value('weight'),
								'keyword'			=> set_value('keyword'),
								'pro_cat'			=> set_value('pro_cat'),
								'is_featured'		=> set_value('feature'),
								'pro_image'			=> $upload_image['file_name']
							);//end array data_products
							$this->model_products->edit($pro_id,$data_products);
							redirect('admin/products');
					}//end if uploading
				}else{
						$data_products = array(
							'pro_color'			=> set_value('pro_color'),
							'pro_title'			=> set_value('pro_title'),
							'pro_description'	=> set_value('pro_description'),
							'pro_price'			=> set_value('pro_price'),
							'diskon'			=> set_value('diskon'),
							'weight'			=> set_value('weight'),
							'keyword'			=> set_value('keyword'),
							'pro_cat'			=> set_value('pro_cat'),
							'is_featured'		=> set_value('feature'),
						
						);//end array data_products
						$this->model_products->edit($pro_id,$data_products);
						redirect('admin/products');
						
				}//end if FILES
				
			}//end if form_validation
			
	}//end function update
	
	public function delete($pro_id)
	{
		$this->model_products->delete($pro_id);
		redirect('admin/products');
	}
	
	public function reports()
	{
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$data['reports'] = $this->model_products->reports();	
		$this->load->view('backend/reports',$data);
	}
	
	public function del_report($rep_id_product)
	{
		$this->model_products->del_report($rep_id_product);
		redirect('admin/products/reports');	
	}
	
	public function members()
	{
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$data['members'] = $this->model_users->members();	
		$this->load->view('backend/members',$data);
	}
	
	public function active_usr($usr_id)
	{
		$active = '1';
		$data_user = array
		(
			'stuts'			=> $active
		);
		$this->model_users->active($usr_id,$data_user);
		redirect('admin/products/members');
	}
	
	public function disable_usr($usr_id)
	{
		$active = '0';
		$data_user = array
		(
		'stuts'			=> $active
		);
		$this->model_users->active($usr_id,$data_user);
		redirect('admin/products/members');
	}
	

	

}
