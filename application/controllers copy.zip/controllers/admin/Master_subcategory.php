<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_subcategory extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('group')!=  ('1' ||'2') )
        {
            $this->session->set_flashdata('error','Sorry You Are Not Logged in !');
            redirect('login');  
        }
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('model_subcategory');
    }

    public function index()
    {
        $data['subcategory'] = $this->model_subcategory->load_all_subcategory();
        $data['manufacture'] = $this->model_subcategory->load_manufacture();
        $this->load->view('backend/subcategory',$data);
 
    }

    public function ajax_add()
    {
        $this->_validate();

         $data = array(
            'cat_name' => $this->input->post('subcat'),
            'is_parent'=>'0',
            'parent_id'=>$this->input->post('cat'),
            'manufacture_id' => $this->input->post('manufacture')
        );

        $insert = $this->model_subcategory->save($data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_update()
    {
        $this->_validate_update();


        $data = array(
            'cat_name' => $this->input->post('subcat'),
            'is_parent'=>'0',
            'parent_id'=>$this->input->post('cat'),
            'manufacture_id' => $this->input->post('manufacture')
        );
        
        $this->model_subcategory->update(array('cat_id' => $this->input->post('id')), $data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_delete($id)
    {
        $this->model_subcategory->delete_by_id($id);
        echo json_encode(array("status" => TRUE));
    }
    private function _validate()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if($this->input->post('subcat') == '')
        {
            $data['inputerror'][] = 'subcat';
            $data['error_string'][] = 'SubCategory Name is required';
            $data['status'] = FALSE;
        }

        if($this->input->post('cat') == '')
        {
            $data['inputerror'][] = 'cat';
            $data['error_string'][] = 'Category is required';
            $data['status'] = FALSE;
        }

        if($this->input->post('manufacture') == '')
        {
            $data['inputerror'][] = 'manufacture';
            $data['error_string'][] = 'Manufacture is required';
            $data['status'] = FALSE;
        }

        
 

        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

    private function _validate_update()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if($this->input->post('subcat') == '')
        {
            $data['inputerror'][] = 'subcat';
            $data['error_string'][] = 'SubCategory Name is required';
            $data['status'] = FALSE;
        }

        if($this->input->post('cat') == '')
        {
            $data['inputerror'][] = 'cat';
            $data['error_string'][] = 'Category is required';
            $data['status'] = FALSE;
        }

        if($this->input->post('manufacture') == '')
        {
            $data['inputerror'][] = 'manufacture';
            $data['error_string'][] = 'Manufacture is required';
            $data['status'] = FALSE;
        }
        
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

    public function get_category($man_id){
        header('Content-Type: application/x-json; charset=utf-8');
        echo(json_encode($this->model_subcategory->load_category($man_id)));
        
    }



}