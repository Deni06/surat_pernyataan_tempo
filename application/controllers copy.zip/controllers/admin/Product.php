<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
		
	public function __construct ()
	{
		parent::__construct();
		if($this->session->userdata('group')!=	('1' ||'2') )
		{
			$this->session->set_flashdata('error','Sorry You Are Not Logged in !');
			redirect('login');	
		}
		
		//load model -> model_products
		$this->load->model('model_products');
		$this->load->model('model_users');
		
	}
	
	public function index()
	{	
		$data['products'] = $this->model_products->all_products();		
		$this->load->view('backend/master_product',$data);
	}

	public function add_product()
	{	$data['isfeatured']=0;
		//$data['manufacture'] = $this->model_products->get_manufacture();
		$data['error']='';
		$data['error2']='';
		$this->load->view('backend/add_product',$data);

	}

	public function save()
	{
		$this->form_validation->set_rules('itemname','Item','required');
		$this->form_validation->set_rules('sku','sku','required');
		$this->form_validation->set_rules('size','size','required');
		$this->form_validation->set_rules('color','color','required');
		$this->form_validation->set_rules('category','Category','required');
		$this->form_validation->set_rules('subcategory','Subcategory','required');
		$this->form_validation->set_rules('description','Description','required');
		$isfeatured=$this->input->post('isfeatured');

		if ($this->form_validation->run() == FALSE){
			$data['isfeatured']=$isfeatured;
			$data['manufacture'] = $this->model_products->get_manufacture();
			$data['error']='';
			$data['error2']='';
			$this->load->view('backend/add_product',$data);
		}
		else{
			//load uploading file
			$config['upload_path']          = './assets/uploads/';//base_url('assets/uploads/');
			$config['allowed_types']        = 'jpg|png|gif';
			$config['max_size']             = 2048000;// = MB
			$config['overwrite']			= TRUE;
			$config['max_width']            = 2000;
			$config['max_height']           = 2000;
			$config['remove_spaces']		= FALSE;
			

			$config2['upload_path']          = './assets/download/';//base_url('assets/uploads/');
			$config2['allowed_types']        = 'pdf';
			$config2['max_size']             = 2048000;// = MB
			$config2['overwrite']			= TRUE;
			$config2['max_width']            = 2000;
			$config2['max_height']           = 2000;
			$config2['remove_spaces']		= FALSE;
			$this->load->library('upload');
			do{
				if(empty($_FILES['userfile1']['name'])){
						$this->upload->initialize($config);
					if ( $this->upload->do_upload('userfile1') ){
						$this->upload->data('userfile1');
						$data_products = array
						(
						'pro_sku'	=> set_value('sku'),
						'pro_color'	=> set_value('color'),
						'pro_size'	=> set_value('size'),
						'pro_cat'			=> set_value('subcategory'),
						'pro_title'			=> set_value('itemname'),
						'pro_description'	=> set_value('description'),
						'keyword'			=> set_value('keyword'),
						'is_featured'		=> $isfeatured,
						'pro_description'		=> set_value('shortdesc'),
						'pro_image'			=> $_FILES['userfile1']['name']
						);
						$this->model_products->create($data_products);		
						redirect('admin/product');
						break;
					}
				}
				
			}while(false);
		}
	}
	public function view_product($pro_id){
		$this->form_validation->set_rules('itemname','Item','required');
		$this->form_validation->set_rules('manufacture','Manufacture','required');
		$this->form_validation->set_rules('category','Category','required');
		$this->form_validation->set_rules('subcategory','Subcategory','required');
		$this->form_validation->set_rules('description','Description','required');
		$this->form_validation->set_rules('feature','Spesification','required');
		$isfeatured=$this->input->post('isfeatured');

		if ($this->form_validation->run() == FALSE){
			$data['isfeatured']=$isfeatured;
			//$data['manufacture'] = $this->model_products->get_manufacture();
			$data['product']=$this->model_products->single_product($pro_id);
			$data['error']='';
			$data['error2']='';
			$this->load->view('backend/view_product',$data);
		}
		else{
			//load uploading file
			$config['upload_path']          = './assets/uploads/';//base_url('assets/uploads/');
			$config['allowed_types']        = 'jpg|png|gif';
			$config['max_size']             = 2048000;// = MB
			$config['overwrite']			= TRUE;
			$config['max_width']            = 2000;
			$config['max_height']           = 2000;
			$config['remove_spaces']		= FALSE;
			

			$config2['upload_path']          = './assets/download/';//base_url('assets/uploads/');
			$config2['allowed_types']        = 'pdf';
			$config2['max_size']             = 2048000;// = MB
			$config2['overwrite']			= TRUE;
			$config2['max_width']            = 2000;
			$config2['max_height']           = 2000;
			$config2['remove_spaces']		= FALSE;
			$this->load->library('upload');
			do{
				if(empty($_FILES['userfile1']['name']) && empty($_FILES['userfile2']['name'])){
						$data_products = array
						(
						'pro_cat'			=> set_value('subcategory'),
						'pro_title'			=> set_value('itemname'),
						'pro_description'	=> set_value('description'),
						'pro_feature'		=> set_value('feature'),
						'keyword'			=> set_value('keyword'),
						'manufacture_id'	=> set_value('manufacture'),
						'is_featured'		=> $isfeatured,
						'short_desc'		=> set_value('shortdesc')
						);
						$this->model_products->edit($pro_id,$data_products);		
						redirect('admin/product');
						break;
				}
				elseif(!empty($_FILES['userfile1']['name']) && !empty($_FILES['userfile2']['name'])){
					if ( $this->upload->initialize($config) && ! $this->upload->do_upload('userfile1') ){
						$data['isfeatured']=$isfeatured;
						$data['manufacture'] = $this->model_products->get_manufacture();
						$data['product']=$this->model_products->single_product($pro_id);
						$data['error']=$this->upload->display_errors('<p style="color:#FF0000;font-style:italic"> *','</p>');
						$data['error2']='';
						$this->load->view('backend/view_product',$data);
						break;
					}
					elseif ($this->upload->initialize($config2) && !$this->upload->do_upload('userfile2') ){
						$data['isfeatured']=$isfeatured;
						$data['manufacture'] = $this->model_products->get_manufacture();
						$data['product']=$this->model_products->single_product($pro_id);
						$data['error']='';
						$data['error2']=$this->upload->display_errors('<p style="color:#FF0000;font-style:italic"> *','</p>');
						$image=$_FILES['userfile1']['name'];
						if($image!=$this->model_products->get_image($pro_id))
							$this->model_products->delete_image($image);
						$this->load->view('backend/view_product',$data);
						break;
					}
					else{
						$this->model_products->delete_image2($pro_id);
						$this->model_products->delete_file($pro_id);

						$this->upload->initialize($config);
						$this->upload->do_upload('userfile1');
						$this->upload->data('userfile1');

						$this->upload->initialize($config2);
						$this->upload->do_upload('userfile2');		
						$this->upload->data('userfile2');
						$data_products = array
						(
						'pro_cat'			=> set_value('subcategory'),
						'pro_title'			=> set_value('itemname'),
						'pro_description'	=> set_value('description'),
						'pro_feature'		=> set_value('feature'),
						'keyword'			=> set_value('keyword'),
						'manufacture_id'	=> set_value('manufacture'),
						'is_featured'		=> $isfeatured,
						'short_desc'		=> set_value('shortdesc'),
						'pro_image'			=> $_FILES['userfile1']['name'],
						'file_download'		=> $_FILES['userfile2']['name']
						);
						
						$this->model_products->edit($pro_id,$data_products);		
						redirect('admin/product');
						break;
					}
				}
				elseif(empty($_FILES['userfile1']['name'])){
					$this->upload->initialize($config2);
					if ( !$this->upload->do_upload('userfile2')){
						$data['isfeatured']=$isfeatured;
						$data['manufacture'] = $this->model_products->get_manufacture();
						$data['product']=$this->model_products->single_product($pro_id);
						$data['error']='';
						$data['error2']=$this->upload->display_errors('<p style="color:#FF0000;font-style:italic"> *','</p>');
						$this->load->view('backend/view_product',$data);
						break;
					}
					else{
						$this->model_products->delete_file($pro_id);
						$this->upload->do_upload('userfile2');
						$this->upload->data('userfile2');
						$data_products = array
						(
						'pro_cat'			=> set_value('subcategory'),
						'pro_title'			=> set_value('itemname'),
						'pro_description'	=> set_value('description'),
						'pro_feature'		=> set_value('feature'),
						'keyword'			=> set_value('keyword'),
						'manufacture_id'	=> set_value('manufacture'),
						'is_featured'		=> $isfeatured,
						'short_desc'		=> set_value('shortdesc'),
						'file_download'		=> $_FILES['userfile2']['name']
						);
						
						$this->model_products->edit($pro_id,$data_products);		
						redirect('admin/product');
						break;
					}
				}
				elseif(empty($_FILES['userfile2']['name'])){
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload('userfile1')){
						$data['isfeatured']=$isfeatured;
						$data['manufacture'] = $this->model_products->get_manufacture();
						$data['product']=$this->model_products->single_product($pro_id);
						$data['error']=$this->upload->display_errors('<p style="color:#FF0000;font-style:italic"> *','</p>');
						$data['error2']='';
						$this->load->view('backend/view_product',$data);
						break;
					}
					else{
						$this->model_products->delete_image2($pro_id);
						$this->upload->do_upload('userfile1');
						$this->upload->data('userfile1');
						$data_products = array
						(
						'pro_cat'			=> set_value('subcategory'),
						'pro_title'			=> set_value('itemname'),
						'pro_description'	=> set_value('description'),
						'pro_feature'		=> set_value('feature'),
						'keyword'			=> set_value('keyword'),
						'manufacture_id'	=> set_value('manufacture'),
						'is_featured'		=> $isfeatured,
						'short_desc'		=> set_value('shortdesc'),
						'pro_image'			=> $_FILES['userfile1']['name']
						);
						
						$this->model_products->edit($pro_id,$data_products);		
						redirect('admin/product');
						break;
					}
				}
				
			}while(false);
		}
	}
	
	public function delete($pro_id)
	{
		$this->model_products->delete($pro_id);
		redirect('admin/product');
	}

	public function get_category(){
        header('Content-Type: application/x-json; charset=utf-8');
        echo(json_encode($this->model_products->load_category()));
        
    }

    public function get_subcategory($cat_id){
        header('Content-Type: application/x-json; charset=utf-8');
        echo(json_encode($this->model_products->load_subcategory($cat_id)));
        
    }
}
