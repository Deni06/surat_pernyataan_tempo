<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_category extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('group')!=  ('1' ||'2') )
        {
            $this->session->set_flashdata('error','Sorry You Are Not Logged in !');
            redirect('login');  
        }
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('model_category');
    }

    public function index()
    {
        $data['category'] = $this->model_category->load_all_category();
        $data['manufacture'] = $this->model_category->load_manufacture();
        $this->load->view('backend/category',$data);
 
    }

    public function ajax_add()
    {
        $this->_validate();

        $last_id=$this->model_category->get_last_id();


        $data = array(
            'cat_name' => $this->input->post('cat_name'),
            'is_parent'=>'1',
            'parent_id'=>'0',
            'manufacture_id' => $this->input->post('manufacture')
        );

        $insert = $this->model_category->save($data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_update()
    {
        $this->_validate_update();

            $parent_id=$this->input->post('id');

        $data = array(
            'cat_name' => $this->input->post('cat_name'),
            'is_parent'=>'1',
            'parent_id'=>'0',
            'manufacture_id' => $this->input->post('manufacture')
        );
        
        $this->model_category->update(array('cat_id' => $this->input->post('id')), $data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_delete($id)
    {
        $this->model_category->delete_by_id($id);
        echo json_encode(array("status" => TRUE));
    }
    private function _validate()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if($this->input->post('cat_name') == '')
        {
            $data['inputerror'][] = 'cat_name';
            $data['error_string'][] = 'Category Name is required';
            $data['status'] = FALSE;
        }


        if($this->input->post('manufacture') == '')
        {
            $data['inputerror'][] = 'manufacture';
            $data['error_string'][] = 'Manufacture is required';
            $data['status'] = FALSE;
        }

        
 

        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

    private function _validate_update()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        if($this->input->post('cat_name') == '')
        {
            $data['inputerror'][] = 'cat_name';
            $data['error_string'][] = 'Category Name is required';
            $data['status'] = FALSE;
        }


        if($this->input->post('manufacture') == '')
        {
            $data['inputerror'][] = 'manufacture';
            $data['error_string'][] = 'Manufacture is required';
            $data['status'] = FALSE;
        }
        
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }



}