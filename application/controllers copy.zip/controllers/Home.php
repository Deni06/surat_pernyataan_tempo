<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
		
	public function __construct ()
	{
		parent::__construct();
		//load model -> model_products 
		$this->load->model('model_products');
		$this->load->model('model_category');
		$this->load->model('model_settings');
		$this->load->model('model_article');
	}

	public function index()
	{	
		//$data['get_sitename'] = $this->model_settings->sitename_settings();
		//$data['get_footer'] = $this->model_settings->footer_settings();
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$data['get_testi'] = $this->model_settings->testi_settings();
		$data['products'] = $this->model_products->all_products();	//this all_products from model
		$data['category'] = $this->model_category->cat_products();
		$data['featured'] = $this->model_products->get_featured_products();
		$data['berita']=$this->model_article->top_article();
		$this->load->view('home',$data); //this $data from model inside class model_products
		
		
		
	}
	public function category($cat_id)
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		//$data['get_sitename'] = $this->model_settings->sitename_settings();
		//$data['get_footer'] = $this->model_settings->footer_settings();
		$data['category'] = $this->model_category->cat_products();
		$data['products'] = $this->model_products->showcat($cat_id); //for showme function in home/showme
		$this->load->view('this_products',$data);
	}
	public function showme($pro_name)
	{		
			//$data['get_sitename'] = $this->model_settings->sitename_settings();
			//$data['get_footer'] = $this->model_settings->footer_settings();
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
			$data['starts'] = $this->model_products->dis_products();
			$data['comes'] = $this->model_products->showme($pro_name); //for showme function in home/showme
			$this->load->view('this_products',$data);
	}
	
	public function add_to_cart($pro_id,$send)
	{
		$product = $this->model_products->find($pro_id);
		$price = "";
		if($this->session->userdata('type')==1)
		{
			$price = $product->pro_price;
		}
		else
		{
			$price = $product->regular_price;
		}
		$data = array(
						'id'      => $product->pro_id,
						'qty'     => 1,
						'price'   => $price,
						'name'    => $product->pro_sku,
						'color'   => $product->pro_color,
						'title'	  => $product->pro_title,
						'img'	  => $product->pro_image,
						'weight'  => $product->weight
						);
		
		$this->cart->insert($data);	
		if ($send == 'add')
		{
				redirect('home/cart/');
		}else{
				redirect(base_url());
			 }
		
	}
	public function remove_cart($rowid,$send)
	{
		$data = array( 'rowid' => $rowid,
		'qty' =>0
		);
		$this->cart->update($data);
		if ($send == 'del')
		{
			redirect('home/cart/');
		}else{
			redirect(base_url());
		}
	}
	public function update_qty()
	{	
		if($this->input->post('qty') <= 3)
		{
		$data = array( 'rowid' => $this->input->post('rowid'),
			'qty' =>$this->input->post('qty')
		);
		$this->cart->update($data);
		redirect('home/cart/');
		}
		else{
		$this->session->set_flashdata('Informasi','Jumlah Qty Melebihi Batas');
		redirect('home/cart/');
		}
	}


	
	public function cart()
	{
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$data['get_sitename'] = $this->model_settings->sitename_settings();
		$data['get_footer'] = $this->model_settings->footer_settings();	
		$this->load->view('show_cart',$data);	
		
	}//view inside cart
	
	public function clear_cart()
	{
		$this->cart->destroy();
		redirect(base_url());
	}
	
	public function report($pro_id)
	{
		$product = $this->model_products->find($pro_id);

		
		if($this->session->userdata('group')	!=	('2' ||'3'))
		{
			$group_usr = Gost;
			$name_usr = Gost;	
		}else{
				$group_usr = $this->session->userdata('group');
				$name_usr = $this->session->userdata('username');
			}
		
		
		
		$report_products = array
		(
			'rep_id_product'			=> $product->pro_id,
			'rep_name'					=> $product->pro_name,
			'rep_color'					=> $product->pro_color,
			'rep_title_product'			=> $product->pro_title,
			'rep_usr_name'				=> $name_usr,
			'rep_usr_group'				=> $group_usr
		);
		$this->model_products->report($report_products);
		redirect(base_url());
		
	}
	
}
