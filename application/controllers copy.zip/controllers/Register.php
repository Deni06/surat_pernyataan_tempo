<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	
	public function __construct ()
	{
		parent::__construct();
		$this->load->model('model_users');
		$this->load->model('model_settings');
		$this->load->helper('ongkir_helper');
	}
		
	public function index()
	{
		//$this->load->library('rajaongkir');
		$data['get_about'] = $this->model_settings->about_settings();
		$data['get_contact'] = $this->model_settings->contact_settings();
		$this->form_validation->set_rules('rusername','Email','trim|required|valid_email');
		$this->form_validation->set_rules('rname','Nama Lengkap','trim|required');
		$this->form_validation->set_rules('raddress1','Alamat','trim|required');
		$this->form_validation->set_rules('rphone','HP/TELP','trim|required');
		$this->form_validation->set_rules('input_city','Kota','trim|required');
		$this->form_validation->set_rules('rzipcode','Kode Pos','trim|required');
		$this->form_validation->set_rules('rpassword','Password','required|alpha_numeric|matches[repassword]|min_length[6]|max_length[24]|md5');
		$this->form_validation->set_rules('repassword','Password','required|alpha_numeric|md5');
		
		if($this->form_validation->run()	==	FALSE)
		{	
			//$provinces = $this->rajaongkir->province();
			$data['get_sitename'] = $this->model_settings->sitename_settings();
			$data['get_footer'] = $this->model_settings->footer_settings();
			$this->load->view('register/form_register',$data);

		}else{
				$data_register_new = array
				 (
					'usr_name'			=> set_value('rusername'),
					'usr_password'		=> set_value('rpassword'),
					'stuts'				=> '1',
					'usr_group'				=>'3',
					'usr_address'		=>set_value('raddress1'),
					'usr_address2'		=>set_value('raddress2'),
					'usr_fullname'		=>set_value('rname'),
					'usr_city'			=>set_value('151'),
					'usr_citycode'		=>set_value('shipping_citycode'),
					'usr_phone'			=>set_value('rphone'),
					'usr_zip'			=>set_value('rzipcode')

				 );
				 if($this->model_users->is_usr() == FALSE)
				 {
					 $this->model_users->register_new($data_register_new);
						 $this->form_validation->set_rules('rusername');
						 $this->form_validation->set_rules('rpassword');
					 	$this->form_validation->set_rules('rame');
					 	$this->form_validation->set_rules('raddress1');
					 	$this->form_validation->set_rules('rphone');
					 	$this->form_validation->set_rules('151');
						 $this->form_validation->set_rules('rzipcode');
						 if($this->form_validation->run()	==	FALSE)
						 {
								$this->load->view('login/form_login'); 	
						 }else{
								$valid_user	= $this->model_users->check();
								 if($valid_user	==	FALSE)
								 {
									 $this->session->set_flashdata('error','Email sudah pernah terdaftar !' );
									 redirect('login');
								 }else{
										 /*$this->session->set_userdata('username',$valid_user->usr_name);
										 $this->session->set_userdata('group',$valid_user->usr_group);
										 switch($valid_user->usr_group)
										 {
											 case 3 ://for member
											 redirect(base_url());
											 break;
											 
											 default: break;
										 }*/
										 redirect('login');
								 }
						 }
					 $destination = $this->input->post('rusername');

					 $subject = 'Akun GejayanStore Anda Siap Digunakan';
					 $topic = 'Pendaftaran Telah Kami Konfirmasi';
					 $body = '<p>Selamat anda telah menjadi customer dari belujins. Untuk login silahkan gunakan email yang didaftarkan sebagai username dan password berikut untuk login, klik masuk ke link <a href="http://gejayanstore.com/home/login">http://gejayanstore.com/home/login</a>
				menggunakan akun dibawah ini :</p>
				<p>

				<strong> username : </strong> '.$this->input->post('rusername').'<br/>
				</p>
				<p>

				<strong> Password : </strong> '.$this->input->post('rname').'<br/>
				</p>
				<p>untuk langkah berikutnya belanja dengan melakuan login ke belujins.com </p>
				';
					 $this->sendemail($destination,$subject,$topic,$body);
					 redirect(base_url());
				 }else{
						$this->session->set_flashdata('error','email sudah pernah terdaftar !' );
						redirect('register');
				 }
		}
	}
	public function sendemail($destination,$subject,$topic,$body)
	{
		$url = 'https://api.sendgrid.com/';
		$user = 'andrehuang708';
		$pass = 'Cindria@2015';
		$params = array(
			'api_user'  => $user,
			'api_key'   => $pass,
			'to'        => $destination,
			'subject'   => $subject,
			'from'      => 'noreply@belujins.com',
		);
		$params['html'] =
			'
		  <!DOCTYPE html "-//w3c//dtd xhtml 1.0 transitional //en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd"><html lang="en" xmlns="http://www.w3.org/1999/xhtml"><head>
			<!--[if gte mso 9]><xml>
			<o:OfficeDocumentSettings>
			<o:AllowPNG/>
			<o:PixelsPerInch>96</o:PixelsPerInch>
			</o:OfficeDocumentSettings>
			</xml><![endif]-->
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
			<meta name="viewport" content="width=device-width">
			<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE">

			<title>Template Base</title>

			</head>
			<body style="color:#fff;width: 100% !important;min-width: 100%;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100% !important;margin: 0;padding: 0;background-color: #FFFFFF">
			<style id="media-query">
			/*  Media Queries */
			@media only screen and (max-width: 500px) {
			.prova {
			width: 500px; }
			table[class="body"] img {
			width: 100% !important;
			height: auto !important; }
			table[class="body"] center {
			min-width: 0 !important; }
			table[class="body"] .container {
			width: 95% !important; }
			table[class="body"] .row {
			width: 100% !important;
			display: block !important; }
			table[class="body"] .wrapper {
			display: block !important;
			padding-right: 0 !important; }
			table[class="body"] .columns, table[class="body"] .column {
			table-layout: fixed !important;
			float: none !important;
			width: 100% !important;
			padding-right: 0px !important;
			padding-left: 0px !important;
			display: block !important; }
			table[class="body"] .wrapper.first .columns, table[class="body"] .wrapper.first .column {
			display: table !important; }
			table[class="body"] table.columns td, table[class="body"] table.column td {
			width: 100% !important; }
			table[class="body"] table.columns td.expander {
			width: 1px !important; }
			table[class="body"] .right-text-pad, table[class="body"] .text-pad-right {
			padding-left: 10px !important; }
			table[class="body"] .left-text-pad, table[class="body"] .text-pad-left {
			padding-right: 10px !important; }
			table[class="body"] .hide-for-small, table[class="body"] .show-for-desktop {
			display: none !important; }
			table[class="body"] .show-for-small, table[class="body"] .hide-for-desktop {
			display: inherit !important; }
			table[class="icon-table"] {
			width: 100% !important; }
			table[class="icon-table"] table {
			display: block !important;
			width: 100% !important; }
			table[class="icon-table"] table td {
			padding-bottom: 10px !important; }
			.mixed-two-up .col {
			width: 100% !important; } }


			@media screen and (max-width: 500px) {
			div[class="col"] {
			width: 100% !important;
			}
			}

			@media screen and (min-width: 501px) {
			table[class="block-grid"] {
			width: 500px !important;
			}
			}
			</style>
			<table class="body" style="border-spacing: 0;border-collapse: collapse;vertical-align: top;height: 100%;width: 100%;table-layout: fixed" cellpadding="0" cellspacing="0" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td class="center" style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;text-align: center;background-color: #FFFFFF" align="center" valign="top">

			<!--[if (gte mso 9)|(IE)]>
			<table width="500" class="ieCell" align="center" cellpadding="0" cellspacing="0" border="0">
			<tr>
			<td>
			<![endif]-->
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;background-color:#E8E8E8" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" width="100%">
			<table class="container" style="border-spacing: 0;border-collapse: collapse;vertical-align: top;max-width: 500px;margin: 0 auto;text-align: inherit" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" width="100%">
			<table class="block-grid" style="border-spacing: 0;border-collapse: collapse;vertical-align: top;width: 100%;max-width: 500px;color: #000000;background-color: transparent" cellpadding="0" cellspacing="0" width="100%" bgcolor="transparent">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;text-align: center;font-size: 0">
			<!--[if (gte mso 9)|(IE)]>
			<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
			<tr>
			<td valign="top">
			<![endif]-->
			<div class="col num12" style="display: inline-block;vertical-align: top;width: 100%">
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;background-color: transparent;padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;border-top: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-left: 0px solid transparent">
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" align="center" width="100%" border="0" cellspacing="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;padding-top: 10px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px" align="center">
			<div>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;border-top: 10px solid transparent;width: 100%" align="center" border="0" cellspacing="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" align="center">
			&nbsp;
			</td>
			</tr>
			</tbody></table>
			</div>
			</td>
			</tr>
			</tbody></table><table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" cellpadding="0" cellspacing="0" width="100%">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;padding-top: 30px;padding-right: 0px;padding-bottom: 30px;padding-left: 0px">
			<div style="color:#ffffff;line-height:120%;font-family:Arial, "Helvetica Neue", Helvetica, sans-serif;">
			<div style="font-size: 14px; line-height: 16px; text-align: center;color: #ffffff;font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;line-height: 17px" data-mce-style="font-size: 14px; line-height: 16px; text-align: center;"><strong><span style="font-size: 28px; line-height: 33px;" data-mce-style="font-size: 28px; line-height: 33px;">Gejayan Store<br></span></strong></div>
			</div>
			</td>
			</tr>
			</tbody></table>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" align="center" width="100%" border="0" cellspacing="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;padding-top: 10px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px" align="center">
			<div>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;border-top: 10px solid transparent;width: 100%" align="center" border="0" cellspacing="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" align="center">
			&nbsp;
			</td>
			</tr>
			</tbody></table>
			</div>
			</td>
			</tr>
			</tbody></table> </td>
			</tr>
			</tbody></table>
			</div>
			<!--[if (gte mso 9)|(IE)]>
			</td><td>
			<![endif]-->
			<!--[if (gte mso 9)|(IE)]>
			</td>
			</tr>
			</table>
			<![endif]-->
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			<!--[if (gte mso 9)|(IE)]>
			</td>
			</tr>
			</table>
			<![endif]-->
			<!--[if (gte mso 9)|(IE)]>
			<table width="500" class="ieCell" align="center" cellpadding="0" cellspacing="0" border="0">
			<tr>
			<td>
			<![endif]-->
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;background-color: #FFF" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" width="100%">
			<table class="container" style="border-spacing: 0;border-collapse: collapse;vertical-align: top;max-width: 500px;margin: 0 auto;text-align: inherit" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" width="100%">
			<table class="block-grid" style="border-spacing: 0;border-collapse: collapse;vertical-align: top;width: 100%;max-width: 500px;color: #333;background-color: transparent" cellpadding="0" cellspacing="0" width="100%" bgcolor="transparent">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;text-align: center;font-size: 0">
			<!--[if (gte mso 9)|(IE)]>
			<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
			<tr>
			<td valign="top">
			<![endif]-->
			<div class="col num12" style="display: inline-block;vertical-align: top;width: 100%">
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;background-color: transparent;padding-top: 30px;padding-right: 0px;padding-bottom: 30px;padding-left: 0px;border-top: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-left: 0px solid transparent">
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" cellpadding="0" cellspacing="0" width="100%">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;padding-top: 25px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px">
			<div style="color:#ffffff;line-height:120%;font-family:Arial, "Helvetica Neue", Helvetica, sans-serif;">
			<div style="font-size: 18px; line-height: 21px; text-align: center;color: #ffffff;font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;line-height: 22px" data-mce-style="font-size: 18px; line-height: 21px; text-align: center;"><span style="font-size:24px; line-height:29px;" mce-data-marked="1"><strong>'.$topic.'</strong></span></div>
			</div>
			</td>
			</tr>
			</tbody></table>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" cellpadding="0" cellspacing="0" width="100%">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;padding-top: 0px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px">
			<div style="color:#B8B8C0;line-height:150%;font-family:Arial, "Helvetica Neue", Helvetica, sans-serif;">
			<div style="font-size: 14px; line-height: 21px; text-align: center;color: #B8B8C0;font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;line-height: 21px" data-mce-style="font-size: 14px; line-height: 16px; text-align: center;"><span style="font-size:14px; line-height:21px;">'.$body.'</span></div>
			</div>
			</td>
			</tr>
			</tbody></table>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody><tr style="vertical-align: top">
			<td class="center" style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;text-align: center;padding-top: 15px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px" align="center">

			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody><tr style="vertical-align: top">
			<td class="button-container" style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" align="center">
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" border="0" cellspacing="0" cellpadding="0" align="center">

			<tbody><tr style="vertical-align: top">
			<td class="button" style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: middle;text-align: center;-webkit-border-radius: 25px;-moz-border-radius: 25px;border-radius: 25px;height: 48px" bgcolor="#4CCFC1" width="178" valign="middle">

			<a style="display: inline-block;text-decoration: none;-webkit-text-size-adjust: none;text-align: center;line-height: 100%;padding-top: 5px;                         padding-right: 20px;                        padding-bottom: 5px;                        padding-left: 20px;                        text-align:;                        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;-webkit-border-radius: 25px;-moz-border-radius: 25px;border-radius: 25px;border-top: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-left: 0px solid transparent;color: #ffffff" href="" target="_blank">

			<!--[if mso]>&nbsp;<![endif]-->
			<div style="text-align: center !important;line-height: 100% !important;font-family: inherit;font-size: 12px;color: #ffffff" data-mce-style="font-family: inherit; font-size: 16px; line-height: 32px;"><a href="http://gejayanstore.com" style="color:#fff;text-decoration:none;line-height: 100% !important;font-size: 14px">ke GejayanStore</a></div>
			<!--[if mso]>&nbsp;<![endif]-->
			</a>

			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>

			</td>
			</tr>
			</tbody></table><table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" align="center" width="100%" border="0" cellspacing="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;padding-top: 10px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px" align="center">
			<div>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;border-top: 0px solid transparent;width: 100%" align="center" border="0" cellspacing="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" align="center">
			&nbsp;
			</td>
			</tr>
			</tbody></table>
			</div>
			</td>
			</tr>
			</tbody></table> </td>
			</tr>
			</tbody></table>
			</div>
			<!--[if (gte mso 9)|(IE)]>
			</td><td>
			<![endif]-->
			<!--[if (gte mso 9)|(IE)]>
			</td>
			</tr>
			</table>
			<![endif]-->
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			<!--[if (gte mso 9)|(IE)]>
			</td>
			</tr>
			</table>
			<![endif]-->
			<!--[if (gte mso 9)|(IE)]>
			<table width="500" class="ieCell" align="center" cellpadding="0" cellspacing="0" border="0">
			<tr>
			<td>
			<![endif]-->
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;background-color: #ffffff" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" width="100%">
			<table class="container" style="border-spacing: 0;border-collapse: collapse;vertical-align: top;max-width: 500px;margin: 0 auto;text-align: inherit" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top" width="100%">
			<table class="block-grid" style="border-spacing: 0;border-collapse: collapse;vertical-align: top;width: 100%;max-width: 500px;color: #333;background-color: transparent" cellpadding="0" cellspacing="0" width="100%" bgcolor="transparent">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;text-align: center;font-size: 0">
			<!--[if (gte mso 9)|(IE)]>
			<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
			<tr>
			<td valign="top">
			<![endif]-->
			<div class="col num12" style="display: inline-block;vertical-align: top;width: 100%">
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" cellpadding="0" cellspacing="0" align="center" width="100%" border="0">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;background-color: transparent;padding-top: 30px;padding-right: 0px;padding-bottom: 30px;padding-left: 0px;border-top: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-left: 0px solid transparent">
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" border="0" cellspacing="0" cellpadding="0" width="100%">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;text-align: center;padding-top: 10px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px" align="center">
			<table class="icon-table" style="border-spacing: 0;border-collapse: collapse;vertical-align: top" border="0" cellspacing="0" cellpadding="0" width="114" align="center">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top">


			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;padding: 0 5px 0 0" align="left" border="0" cellspacing="0" cellpadding="0" width="38">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top">
			<a href="https://www.facebook.com/" title="Facebook" target="_blank">
			<img style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;width: 100%;clear: both;display: block;border: none;height: auto;line-height: 100%;max-width: 32px !important" src="http://i.imgur.com/DHxcb2m.png" alt="Facebook" title="Facebook" width="100%">
			</a>
			</td>
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top"></td>
			</tr>
			</tbody></table>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;padding: 0 5px 0 0" align="left" border="0" cellspacing="0" cellpadding="0" width="38">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top">
			<a href="http://twitter.com/" title="Twitter" target="_blank">
			<img style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;width: 100%;clear: both;display: block;border: none;height: auto;line-height: 100%;max-width: 32px !important" src="http://i.imgur.com/uYn565H.png" alt="Twitter" title="Twitter" width="100%">
			</a>
			</td>
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top"></td>
			</tr>
			</tbody></table>
			<table style="border-spacing: 0;border-collapse: collapse;vertical-align: top;padding: 0 5px 0 0" align="left" border="0" cellspacing="0" cellpadding="0" width="38">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top">
			<a href="http://plus.google.com/" title="Google+" target="_blank">
			<img style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;width: 100%;clear: both;display: block;border: none;height: auto;line-height: 100%;max-width: 32px !important" src="http://i.imgur.com/yb90ePk.png" alt="Google+" title="Google+" width="100%">
			</a>
			</td>
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top"></td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table><table style="border-spacing: 0;border-collapse: collapse;vertical-align: top" cellpadding="0" cellspacing="0" width="100%">
			<tbody><tr style="vertical-align: top">
			<td style="word-break: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;vertical-align: top;padding-top: 15px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px">
			<div style="color:#959595;line-height:150%;font-family:Arial, "Helvetica Neue", Helvetica, sans-serif;">
			<div style="font-size: 14px; line-height: 21px; text-align: center;color: #959595;font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;line-height: 21px" data-mce-style="font-size: 14px; line-height: 16px; text-align: center;">www.gejayanstore.com</div>
			</div>
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			</div>
			<!--[if (gte mso 9)|(IE)]>
			</td><td>
			<![endif]-->
			<!--[if (gte mso 9)|(IE)]>
			</td>
			</tr>
			</table>
			<![endif]-->
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			</td>
			</tr>
			</tbody></table>
			<!--[if (gte mso 9)|(IE)]>
			</td>
			</tr>
			</table>
			<![endif]-->
			</td>
			</tr>
			</tbody></table>
			</body></html>
		  ';
		$params['text'] = 'masuk';
		$request =  $url.'api/mail.send.json';
		// Generate curl request
		$session = curl_init($request);
		// Tell curl to use HTTP POST
		curl_setopt ($session, CURLOPT_POST, true);
		// Tell curl that this is the body of the POST
		curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
		// Tell curl not to return headers, but do return the response
		curl_setopt($session, CURLOPT_HEADER, false);
		// Tell PHP not to use SSLv3 (instead opting for TLS)
		curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
		curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
		// obtain response
		$response = curl_exec($session);
		curl_close($session);
		// print everything out
		// $reponse = json_decode($response);
		echo $response;
	}
}