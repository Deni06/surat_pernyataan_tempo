<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Beranda - Lovely Supplier</title>
    <meta name="description" content="Lovely Supplier Grosir Baju Wanita Termurah">
    <meta name="viewport" content="user-scalable=no">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">-->

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
    </script>





</head>

<body>


<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>

    <div id="main">

        <section>




        </section>
            <div class="main-slider-wrapper">
                <div class="main-slider owl-carousel owl-carousel-inset">
                    <?php
                    foreach($berita as $br):
                    ?>
                    <div class="main-slider-item">
                        <div class="main-slider-image">
                            <?php if($br->content_type==1):?>
                                <?php
                                $header="";
                                $action="Belanja Sekarang";
                                ?>
                            <img src="<?=base_url('/assets/article/').'/'.$br->article_media?>" alt="">
                            <?php else :?>
                                <img src="<?=base_url('/assets/article/video_wp1.jpg')?>">
                                <?php
                                $header="Video Baru";
                                $action="Lihat Video";
                                ?>

                            <?php endif;?>
                        </div>

                        <div class="main-slider-text">
                            <div class="fp-table">
                                <div class="fp-table-cell center">
                                    <div class="container">
                                        <h3><?=$header?></h3>
                                        <h2><?=$br->article_title?></h2>
                                        <div class="button">
                                            <a href="<?=base_url('product/all/')?>" class="btn btn-lg btn-primary margin-right-15"><?=$action?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endforeach ?>

                </div>
            </div>

            <script>
                $(function() {  aweMainSlider(); });
            </script>

        </section>
        <!-- /section -->


        <section>
            <div class="container">

                <div class="padding-vertical-50 border-bottom">
                    <div class="section-header center">
                        <h2>Produk Unggulan</h2>
                    </div>
                    <!-- /.section-header -->

                    <div class="products scroll">
                        <div class="row">
                            <?php foreach ($featured as $feature ) : ?>
                            <div class="col-md-3 col-sm-6 col-xs-6">
                                <div class="product product-grid">
                                    <div class="product-media">
                                        <div class="product-thumbnail">
                                            <a href="<?=site_url('product/detail/'.$feature->pro_id)?>" title="<?=$feature->pro_name?> - <?=ucwords($feature->pro_color)?>">
                                                <img src="<?php echo base_url('/assets/uploads/'.$feature->pro_image);?>" alt="<?=$feature->pro_color?>" class="current">
                                            </a>
                                        </div>
                                        <!-- /.product-thumbnail -->


                                        <div class="product-hover">
                                            <div class="product-actions">
                                                <a href="<?=site_url('home/add_to_cart/'.$feature->pro_id).'/add'?>" class="awe-button product-add-cart" data-toggle="tooltip" title="Add to cart">
                                                    <i class="icon icon-shopping-bag"></i>
                                                </a>

                                                <a href="<?=site_url('product/detail/'.$feature->pro_id)?>" class="awe-button product-quick-view" data-toggle="tooltip" title="Details">
                                                    <i class="icon icon-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <!-- /.product-hover -->



                                            <span class="product-label hot">
                                    <span>hot</span>
                                            </span>

                                    </div>
                                    <!-- /.product-media -->

                                    <div class="product-body">
                                        <h2 class="product-name">
                                            <a href="<?=base_url('product/detail/'.$feature->pro_id)?>" title="<?=$feature->pro_name?> - <?=$feature->pro_color?>">
                                                <?=$feature->pro_sku?> - <?=ucwords($feature->pro_color)?> <?=$feature->pro_title?> (<?=$feature->pro_size?>)</a>
                                        </h2>
                                    <div class="product-category">
                                            <span><?=$feature->cat_name?></span>
                                        </div>
                            
                                        <div class="product-price">
                                            <span class="amount">Rp. <?=number_format($feature->pro_price)?> </span><del class="amount">Rp. <?=number_format($feature->regular_price)?></del>

                                        </div>
                                        <!-- /.product-price -->
                                    </div>
                                </div>
                                <!-- /.product -->

                            </div>
                            <?php endforeach ?>
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.products -->

                    <div class="center">
                        <a href="<?=site_url('product/all')?>" class="btn btn-lg btn-dark btn-outline">
                            <span>View More Products</span>
                        </a>
                    </div>
                    <!-- /.margin-top-50 -->
                </div>
                <!-- /.padding-vertical-50 -->

            </div>
            <!-- /.container -->
        </section>
        <!-- /section -->


        <section>
            <div class="container">
                <div class="padding-vertical-50">

                    <div class="arrivals">
                        <div class="section-header center">
                            <h2>Koleksi Terbaru</h2>
                        </div>
                        <!-- /.section-header -->

                        <div class="products home-products owl-carousel" data-items="4">
                            <?php foreach ($products as $product ) : ?>
                                <div class="product product-grid">
                                    <div class="product-media">
                                        <div class="product-thumbnail">
                                            <a href="<?=base_url('product/detail/'.$product->pro_id)?>" title="">
                                                <img src="<?php echo base_url('/assets/uploads/'.$product->pro_image);?>" alt="" class="current">
                                            </a>
                                        </div>
                                        <!-- /.product-thumbnail -->


                                        <div class="product-hover">
                                            <div class="product-actions">
                                                <a href="<?=site_url('home/add_to_cart/'.$product->pro_id).'/add'?>" class="awe-button product-add-cart" data-toggle="tooltip" title="Add to cart">
                                                    <i class="icon icon-shopping-bag"></i>
                                                </a>

                                                <a href="<?=base_url('product/detail/'.$product->pro_id)?>" class="awe-button product-quick-view" data-toggle="tooltip" title="Details">
                                                    <i class="icon icon-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <!-- /.product-hover -->
                            <span class="product-label new">
                                    <span>New</span>
                                </span>


                                    </div>
                                    <!-- /.product-media -->

                                    <div class="product-body">
                                        <h2 class="product-name">
                                            <a href="<?=base_url('product/detail/'.$product->pro_id)?>" title="">
                                                
                                                <?=$product->pro_sku?> - <?=ucwords($product->pro_color)?> <?=$product->pro_title?> (<?=$product->pro_size?>)
                                            </a>
                                        </h2>
                                        <!-- /.product-product -->

                                        <div class="product-category">
                                            <span><?=$product->cat_name?></span>
                                        </div>
                                        <!-- /.product-category -->

                                        <div class="product-price">

                                            <span class="amount">Rp. <?=number_format($product->pro_price)?></span> <del class="amount">Rp. <?=number_format($product->regular_price)?></del>

                                        </div>
                                        <!-- /.product-price -->
                                    </div>
                                    <!-- /.product-body -->
                                </div>
                            <?php endforeach; ?>



                        </div>
                        <!-- /.products -->
                    </div>
                    <!-- /.arrivals -->

                </div>
            </div>
            <!-- /.container -->
        </section>
        <!-- /section -->

        <section class="background background-color-dark background-image-section-customers-say hidden">
            <div class="container">
                <div class="padding-top-60">
                    <div class="section-header center">
                        <h2>Customer Say</h2>
                    </div>
                    <!-- /.section-header -->

                    <div class="section-customers">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="customers-carousel owl-carousel" id="customers-carousel" data-toggle="carousel" data-dots="true" data-nav="0">
                                    <?php foreach($get_testi as $testi):?>
                                    <div class="center">
                                        <p><?=$testi->all_value_settings?></p>
                                    </div>
                                    <?php endforeach;?>
                                </div>
                                <!-- /.customers-say-carousel -->
                            </div>
                        </div>
                    </div>
                    <!-- /.section-content -->
                </div>
            </div>
            <!-- /.container -->

            <div class="section-brands hidden">
                <div class="container">
                    <div class="brands-carousel owl-carousel" id="brands-carousel">


                        <div class="center">
                            <img src="<?php echo base_url('/assets/uploads/brand1.png');?>" alt="" class="img-responsive" style="width: 60%">
                        </div>
                        <!-- /.center -->

                        <div class="center">
                            <img src="<?php echo base_url('/assets/uploads/brand2.png');?>" alt="" class="img-responsive" style="width: 60%">
                        </div>
                        <!-- /.center -->

                        <div class="center">
                            <img src="<?php echo base_url('/assets/uploads/brand3.png');?>" alt="" class="img-responsive" style="width: 60%">
                        </div>
                        <!-- /.center -->

                        <div class="center">
                            <img src="<?php echo base_url('/assets/uploads/brand4.png');?>" alt="" class="img-responsive" style="width: 60%">
                        </div>
                        <!-- /.center -->
                        <div class="center">
                            <img src="<?php echo base_url('/assets/uploads/brand5.png');?>" alt="" class="img-responsive" style="width: 60%">
                        </div>

                    </div>
                    <!-- /.brands-carousel -->
                </div>
                <!-- /.container -->
            </div>
            <!-- /.section-brands -->

        </section>
        <!-- /section -->

    </div>


<?php $this->load->view('layout/footer');?>
    <!-- /footer -->

</div>
<!-- /#wrapper -->



<!-- /.login-popup -->

<script>
    $(function() {
        $('a[href="#login-popup"]').magnificPopup({
            type:'inline',
            midClick: false,
            closeOnBgClick: false
        });
    });
</script>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>
