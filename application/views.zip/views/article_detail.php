<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Belujins || News Detail</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
    </script>





</head>

<body>


<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>

    <div id="main">


        <div id="breadcrumb">
            <div class="container">
                <ol class="breadcrumb">
                    <li><a href="<?=base_url('berita/view')?>">Home</a>
                    </li>
                    <li class="active"><span>Artikel Detail</span>
                    </li>
                </ol>

            </div>
        </div>


        <div class="blog-wrapper blog-detail">
            <div class="container">
                <div class="row">

                    <div class="col-md-9 col-md-push-3">
                        <article class="post">
                                <?php foreach($articles as $article):?>
                            <div class="entry-media">
                                <div class='entry-feature-image'>
                                <?php  if($article->content_type==1):?>
                                <img src="<?=base_url('assets/article/'.$article->article_media)?>">
                                <?php elseif($article->content_type==2):?>
                                <div style='padding-top:9%'></div>
                                 <?php endif; ?> 
                                </div>
                            </div>
                            <!-- ./entry-media -->

                            <div class="entry-container ">
                                <header class="entry-header ">
                                    <div class="entry-datetime hidden">
                                        <span class="entry-day">28</span>
                                        <span class="entry-month">/June</span>
                                    
                                </div>
                                    <h1 class="entry-title"><?=$article->article_title?></h1>

                                    <div class="entry-meta">
                                        <span>Posted by</span>
                                        <strong class="entry-author"><?=$article->created_by?></strong>
                                        <span class="entry-month"> on <?php $date=date_create($article->created_on); echo date_format($date,'d-M-Y : H:m:s')?></span>
                                        <span class="hidden">-</span>
                                        <span class="entry-category hidden"><a href="#" title="">Clothing</a>  </span>
                                        <span class="hidden">-</span>
                                        <span class="entry-comment-count hidden"><a href="#" title="">3 Comments</a></span>

                                        <p class="entry-tags hidden">
                                            <span>/ Tags:</span>
                                            <a href="#">Accessories</a>,
                                            <a href="#">Clothing</a>,
                                            <a href="#">Summer 2015</a>,
                                            <a href="#">Trending</a>
                                        </p>
                                    </div>

                                </header>
                                <!-- /.entry-header -->

                                <div class="entry-content">
                                    <?php
                                    if($article->content_type==2): ?>
                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class='embed-responsive-item'  src='<?=$article->article_media?>'></iframe>
                                    </div>
                                    <?php endif?>
                                    <p><?=htmlspecialchars_decode($article->article_content)?></p>

                                    <!-- Blockquote 
                                    <blockquote>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                                    </blockquote>-->

                                    <!-- Image width caption -->
                                    <figure class="wp-caption aligncenter hidden">
                                        <iframe width="720" height="480"
                                                src="http://www.youtube.com/embed/XGSy3_Czz8k?autoplay=0">
                                        </iframe>
                                        <figcaption class="wp-caption-text">Here's a sample caption with an image centered.</figcaption>
                                    </figure>

                                </div>
                                <!-- /.entry-content -->


                                <!-- /.entry-footer -->
                            
                            </div>

                            <!-- /.entry-container -->
                        <?php endforeach;?>
                        </article>
                        <!-- /.post -->

                        <div class="entry-container">
                            <div class="entry-navigation">
                                <div class="row cols-border">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="entry-navigation-next-post">
                                             <?php 
                                             foreach($prevs as $prev):?>
                                              <div class="entry-navigation-button ">
                                                <a href="<?=base_url('berita/detail/'.$prev->article_id)?>" class="entry-navigation-prev">
                                                    <i class="fa fa-chevron-left"></i>
                                                </a>
                                            </div>
                                            <div class="entry-navigation-header">
                                                <span>PREVIOUS POST </span>
                                            </div>
                                            <h2 class="entry-navigation-title">
                                                <a href="<?=base_url('berita/detail/'.$prev->article_id)?>" title=""><?=$prev->article_title?></a>
                                            </h2>

                                            <div class="entry-navigation-meta">
                                                <span>Posted by</span>
                                                <strong class="entry-author"><?=$prev->created_by?> </strong>
                                            </div>
                                        <?php endforeach;?>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-sm-6">
                                        <div class="entry-navigation-prev-post">

                                             <?php foreach($nexts as $next):?>
                                             <div class="entry-navigation-button ">
                                                <a href="<?=base_url('berita/detail/'.$next->article_id)?>" class="entry-navigation-next">
                                                    <i class="fa fa-chevron-right"></i>
                                                </a>
                                            </div>
                                            <div class="entry-navigation-header">
                                                <span>NEXT POST</span>
                                            </div>
                                           
                                            <h2 class="entry-navigation-title">
                                                <a href="<?=base_url('berita/detail/'.$next->article_id)?>" title=""><?=$next->article_title?></a>
                                            </h2>

                                            <div class="entry-navigation-meta">
                                                <span>Posted by</span>
                                                <strong class="entry-author"><?=$next->created_by?></strong>
                                                
                                            </div>
                                        <?php endforeach;?>
                                        </div>
                                    </div>
                                </div>

                                <div class="entry-navigation-button hidden">
                                    <a href="#" class="entry-navigation-prev">
                                        <i class="fa fa-chevron-left"></i>
                                    </a>

                                    <a href="#" class="entry-navigation-next">
                                        <i class="fa fa-chevron-right"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- /.entry-navigation -->


                        </div>
                        <!-- /.entry-container -->
                    </div>

                    <div class="col-md-3 col-md-pull-9">
                        <div class="widget widget_categories hidden">
                            <h3 class="widget-title">Categories</h3>

                            <ul>
                                <li class="current"><a href="#" title="">All</a>
                                </li>
                                <li><a href="#" title="">Jeans</a>
                                </li>
                                <li><a href="#" title="">Pakaian</a>
                                </li>
                                <li><a href="#" title="">Tips Merawat Jeans</a>
                                </li>
                                <li><a href="#" title="">Clothing</a>
                                </li>
                                <li><a href="#" title="">Accessories</a>
                                </li>
                                <li><a href="#" title="">Discount</a>
                                </li>
                                <li><a href="#" title="">Hot Trend</a>
                                </li>
                            </ul>
                        </div>

                        <div id="widget-area" class="widget-area">

                            <div class="widget widget_recent_entries">
                                <h3 class="widget-title">Artikel terbaru</h3>

                                <ul>
                                    <?php foreach ($news as $n):?>
                                    <li><a href="<?=base_url('berita/detail/'.$n->article_id)?>" title=""><?=$n->article_title?></a>
                                    </li>
                                    <?php endforeach;?>
                                </ul>
                            </div>
                            <!-- /.widget -->


                            <div class="widget hidden">
                                <h3 class="widget-title">Ads</h3>

                                <div class="widget-content">
                                    <a href="#">
                                        <img src="<?=base_url('assets/img/samples/ads/1.jpg')?>" alt="">
                                    </a>
                                </div>
                            </div>
                            <!-- /.widget -->

                        </div>

                    </div>

                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.blog-wrapper -->

    </div>






    <?php $this->load->view('layout/footer');?>
    <!-- /footer -->

</div>
<!-- /#wrapper -->



<!-- /.login-popup -->

<script>
    $(function() {
        $('a[href="#login-popup"]').magnificPopup({
            type:'inline',
            midClick: false,
            closeOnBgClick: false
        });
    });
</script>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>
