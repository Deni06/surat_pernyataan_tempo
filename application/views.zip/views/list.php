<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
</head>
<body>

<div class="container">
  <br>        
  <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Order.No</th>
                <th>Nama Seller</th>
                <th>Tgl.Order</th>
                <th>Jatuh Tempo</th>
                <th>Total Transaksi</th>
                <th>No Resi</th>
                <th>Status</th>
                <th>#</th>
            </tr>
        </thead>
        <tbody>
            <?php
      
         foreach($history as $row):
        
            ?>
            <tr style="font-size:1.0em">
                <td class="col-sm-1"><?php
                    $date=date_create($row->date);
                    echo date_format($date,"Ymd").$row->id?></td>
                    <td><?=$row->reseller?></td>
                <td> <?php
                                        $date=date_create($row->date);
                                         echo date_format($date,"d M Y H:i:s")?></td>
                <td> <?php
                                        $date=date_create($row->due_date);
                                         echo date_format($date,"d M Y H:i:s")?></td>
                <td>Rp. <?= number_format($row->total_invoice) ?></td>
                <td class="col-sm-2"><?php
                                              if($row->resi_awb=="")
                                              {
                                                  echo "-";
                                              }
                                              else{
                                                  echo $row->resi_awb;
                                              }
                                              ?></td>
                   <td><?php if($row->status == 'unpaid'):?>
                                                    <?= anchor('customer/payment_confirmation/'.$row->id,'Confirm Payment',array('class'=>'btn btn-primary btn-xs')) ?>
                                                <?php else:?>
                                                    <?php
                                                    if($row->is_due >= 0)
                                                    {


                                                     if($row->status==0)
                                                     {
                                                         $status="Menunggu Alamat";
                                                     }
                                                    else  if($row->status==1)
                                                    {
                                                        $status="Menunggu Pembayaran";
                                                    }
                                                    else  if($row->status==2)
                                                    {
                                                        $status="Pembayaran Di Terima";
                                                    }
                                                    else  if($row->status==3)
                                                    {
                                                        $status="Barang Telah Dikirim";
                                                    }
                                                    else  if($row->status==4)
                                                    {
                                                        $status="Transaksi Sukses";
                                                    }
                                                    else  if($row->status==5)
                                                    {
                                                        $status="Transaksi Dibatalkan";
                                                    }
                                                  }
                                                  else{
                                                    $status="Expired";
                                                  }
                                                    ?>
                                                    <label class="btn btn-success btn-xs active"><?=$status ?></label>
                                                <?php endif;?></td>                           
                <td class="col-sm-1"><?php
                                                if($row->is_due >= 0)
                                                    {
                                                if($row->status == 0):
                                                ?>
                                                 <a target="_parent" href="<?=site_url('customer/shopping_address/'.$row->id)?>" class="btn btn-success btn-xs">Lengkapi</a>
                                                 <?php
                                                  else:  
                                                 ?>
                                                <a target="_parent" href="<?=site_url('customer/shopping_detail/'.$row->id)?>" class="btn btn-success btn-xs">View</a>
                                                <?php
                                                endif;
                                              }
                                                ?></td>
            </tr>
           <?php
       endforeach;
           ?>
        </tbody>
    </table>
</div>
<script type="text/javascript">
 $(document).ready(function() {
    $('#example').DataTable( {
        "order": [[ 2, "desc" ]]
    } );
} );
</script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
</body>
</html>
