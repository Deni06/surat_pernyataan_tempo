<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?=$products['pro_sku']."-".$products['pro_name']?></title>
    <meta name="description" content="<?=$products['pro_sku'].'-'.$products['pro_name']?>">
    <meta name="viewport" content="user-scalable=no">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
    </script>





</head>

<body>
<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>
    <div id="main">
        <div class="main-header background background-image-heading-product">
            <div class="container">
                <h1>Product</h1>
            </div>
        </div>
        <div id="breadcrumb">
            <div class="container">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a>
                    </li>
                    <li class="active"><span>Product</span>
                    </li>
                </ol>

            </div>
        </div>
        <div class="container">
            
            <div class="row">
                <div class="col-md-6">
                    <div class="product-slider-wrapper thumbs-bottom">

                        <div class="swiper-container product-slider-main">
                            <div class="swiper-wrapper">

                                <div class="swiper-slide">
                                   
                                            <img src="<?php echo base_url('/assets/uploads/'.$products['pro_image']);?>" alt="">
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- /.product-slider-wrapper -->
                </div>

                <div class="col-md-6">
                    <div class="product-details-wrapper">
                        <h2 class="product-name">
                            <a href="#" title="<?=$products['pro_name']?>"><?=$products['pro_name']?> - <?=$products['pro_color']?></a>
                        </h2>
                        <!-- /.product-name -->

                        <div class="product-status">
                            <small>Category: <?=$products['cat_name']?></small>
                        </div>
                        <!-- /.product-status -->

                        <div class="product-stars hidden">
                                <span class="rating">
                        <span class="star"></span>
                                <span class="star"></span>
                                <span class="star"></span>
                                <span class=""></span>
                                <span class=""></span>
                                </span>
                        </div>
                        <!-- /.product-stars -->

                        <div class="product-description hidden">
                            <p></p>
                        </div>
                        <!-- /.product-description -->

                        <div class="product-features">
                            <h3>Keterangan :</h3>

                           <p><?=$products['pro_description']?></p>
                        </div>
                        <!-- /.product-features -->

                        <div class="product-actions-wrapper">
                            <form action="" method="POST">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="p_qty">Qty</label>
                                            <input type="number" class="form-control" name="qty" value="1">
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                    <label for="p_qty">Harga</label><br>
                                     <span class="product-price">
                                <span class="amount">Rp. <?=number_format($products['pro_price'])?></span> 
                                <del class="amount">Rp. <?=number_format($products['regular_price'])?></del>
                                    
                                    </span>
                                        </div>
                                </div>
                            </form>
                            <!-- /.form -->

                            <div class="product-list-actions">

                                <!-- /.product-price -->

                                <a href="<?=site_url('home/add_to_cart/'.$products['pro_id']).'/add'?>" alt="Add to Cart"><button class="btn btn-lg btn-primary">Add to cart</button></a>
                            </div>
                            <!-- /.product-list-actions -->
                        </div>
                        <!-- /.product-actions-wrapper -->


                    </div>
                    <!-- /.product-details-wrapper -->
                </div>
            </div>
               <div class="relared-products">
                <div class="relared-products-header margin-bottom-50">
                    <h3 class="upper">Image Products</h3>
                </div>

                <div >

                    <?php foreach($gallery_pro as $gallery):?>
                   <div class="product product-grid">
                        <div class="product-media" align="center">
                           <div class="col-md-12">
                                
                                    <img src="<?php echo base_url('assets/uploads/'.$gallery->image) ?>" class="current">
                               
                            </div>
                        </div>
                        </div>
                   
                    <?php endforeach;?>
                </div>
            </div>
            <!-- /.product-details-left -->
            <div class="relared-products">
                <div class="relared-products-header margin-bottom-50">
                    <h3 class="upper">Related Products</h3>
                </div>

                <div class="products owl-carousel" data-items="4">

                    <?php foreach($related_pro as $related):?>
                    <div class="product product-grid">
                        <div class="product-media">
                            <div class="product-thumbnail">
                                <a href="<?=site_url('product/detail/'.$related->pro_id)?>" title="<?=$related->pro_name?>" alt="<?=$related->pro_name?>">
                                    <img src="<?php echo base_url('assets/uploads/'.$related->pro_image) ?>" alt="<?=$related->pro_name?>" class="current">
                                </a>
                            </div>
                            <!-- /.product-thumbnail -->


                            <div class="product-hover">
                                <div class="product-actions">
                                    <a href="<?=site_url('home/add_to_cart/'.$related->pro_id).'/add'?>" class="awe-button product-add-cart" data-toggle="tooltip" title="Add to cart">
                                        <i class="icon icon-shopping-bag"></i>
                                    </a>
                                    <a href="<?=base_url('product/detail/'.$related->pro_id)?>" class="awe-button product-quick-view" data-toggle="tooltip" title="Quickview">
                                        <i class="icon icon-eye"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- /.product-hover -->

                        </div>
                        <!-- /.product-media -->

                        <div class="product-body">
                            <h2 class="product-name">
                                <a href="<?=base_url('product/detail/'.$related->pro_id)?>" title="<?=$related->pro_name?> - <?=$related->pro_color?>"><?=$related->pro_name?> - <?=ucwords($related->pro_color)?></a>
                            </h2>
                            <!-- /.product-product -->

                            <div class="product-category">
                                <span>SKU : <?=$related->pro_title?></span>
                            </div>
                            <!-- /.product-category -->

                            <div class="product-price">

                                <span class="amount">Rp. <?=number_format($related->pro_price)?></span> <del class="amount">Rp. <?=number_format($related->regular_price)?></del>

                            </div>
                            <!-- /.product-price -->
                        </div>
                        <!-- /.product-body -->
                    </div>
                    <?php endforeach;?>
                </div>
            </div>
            <!-- /.relared-products -->
        </div>

    </div>
    <?php $this->load->view('layout/footer');?>

</div>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>