<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Belujins Web</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
    </script>





</head>

<body>


<div id="wrapper" class="main-wrapper ">
    <!-- Navigation Top_Menu -->
   <?php $this->load->view('layout/navigation');?>
    <div id="main">

        <div class="main-header background background-image-heading-products">
            <div class="container">
                <h1>Products Grid</h1>
            </div>
        </div>


        <div id="breadcrumb">
            <div class="container">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a>
                    </li>
                    <li class="active"><span>Products Grid</span>
                    </li>
                </ol>

            </div>
        </div>


        <div class="container">
            <div class="row">
                <div class="col-md-9 col-md-push-3">

                    <div class="product-header-actions">
                        <form action="" method="POST" class="form-inline">
                            <div class="row">
                                <div class="col-md-4 col-sm-6">
                                    <div class="view-icons">
                                        <a href="#" class="view-icon active"><span class="icon icon-th"></span></a>
                                        <a href="#" class="view-icon "><span class="icon icon-th-list"></span></a>
                                    </div>

                                    <div class="view-count">
                                        <span class="text-muted">Item 1 to 9 of 30 Items</span>
                                    </div>
                                </div>

                                <div class="col-md-8 col-sm-6 col-xs-12">
                                    <div class="form-show-sort">
                                        <div class="form-group pull-left">
                                            <label for="p_show">Show</label>
                                            <select name="p_show" id="p_show" class="form-control input-sm">
                                                <option value="">10</option>
                                                <option value="">25</option>
                                                <option value="">50</option>
                                            </select>
                                            <strong>per page</strong>
                                        </div>
                                        <!-- /.form-group -->

                                        <div class="form-group pull-right text-right">
                                            <label for="p_sort_by">Sort By</label>
                                            <select name="p_sort_by" id="p_sort_by" class="form-control input-sm">
                                                <option value="">Lastest</option>
                                                <option value="">Recommend</option>
                                            </select>
                                        </div>
                                        <!-- /.form-group -->
                                    </div>
                                </div>
                            </div>
                            <!-- /.row -->
                        </form>
                    </div>
                    <!-- /.product-header-actions -->


                    <div class="products products-grid-wrapper">
                        <div class="row">
                            <?php foreach ($catproducts as $pro ) : ?>
                            <div class="col-md-4 col-sm-4 col-xs-12">

                                <div class="product product-grid">
                                    <div class="product-media">
                                        <div class="product-thumbnail">
                                            <a href="product-fullwidth.html" title="">
                                                <img src="<?php echo base_url('/assets/img/samples/products/grid/1.jpg')?>" alt="" class="current">

                                            </a>
                                        </div>
                                        <!-- /.product-thumbnail -->


                                        <div class="product-hover">
                                            <div class="product-actions">
                                                <a href="#" class="awe-button product-add-cart" data-toggle="tooltip" title="Add to cart">
                                                    <i class="icon icon-shopping-bag"></i>
                                                </a>

                                                <a href="#" class="awe-button product-quick-whistlist" data-toggle="tooltip" title="Add to whistlist">
                                                    <i class="icon icon-star"></i>
                                                </a>

                                                <a href="product-quick-view.html" class="awe-button product-quick-view" data-toggle="tooltip" title="Quickview">
                                                    <i class="icon icon-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <!-- /.product-hover -->



                                            <span class="product-label new">
                                    <span>New</span>
                                            </span>

                                    </div>
                                    <!-- /.product-media -->

                                    <div class="product-body">
                                        <h2 class="product-name">
                                            <a href="#" title="<?=$pro->pro_title?>"><?=$pro->pro_title?></a>
                                        </h2>
                                        <!-- /.product-product -->

                                        <div class="product-category">
                                            <span><?=$pro->pro_name?></span>
                                        </div>
                                        <!-- /.product-category -->

                                        <div class="product-price">

                                            <span class="amount">Rp. <?=$pro->pro_price?></span> <del class="amount">Rp. <?=number_format($pro->regular_price)?></del>

                                        </div>
                                        <!-- /.product-price -->
                                    </div>
                                    <!-- /.product-body -->
                                </div>
                                <!-- /.product -->

                            </div>
                            <?php endforeach;?>

                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.products -->
                            <?php echo $total;?>
                            <?php echo $pagination; ?>

                </div>
                <!-- /.col-* -->

                <?php $this->load->view('layout/sidebar');?>
                <!-- /.col-* -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->

        <script>
            $(function() { aweProductSidebar(); });
        </script>


    </div>
    <?php $this->load->view('layout/footer');?>
</div>






    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>

    <script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


    <script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

    <script src="<?php echo base_url('/assets/js/main.js')?>"></script>

    <script src="<?php echo base_url('/assets/js/docs.js')?>"></script>


</body>
</html>
