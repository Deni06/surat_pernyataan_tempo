<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Review Order | Lovelysupplier</title>
    <meta name="description" content="">
   <meta name="viewport" content="width=1024">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>
    <script src="<?php echo base_url('/assets/js/script.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
        function getTotalHarga()
        {
            var barang = parseFloat($('#barang').html());
            var vbarang = "Rp. " + barang.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
            $('#vbarang').html(vbarang);
            var ongkir = parseFloat($('#ongkir').html());
            var total = barang+ongkir;
            var vtotal = "Rp. " + total.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
            document.getElementById('total').value = total;

            return $('#vtotal').html(vtotal);

        }

        function loadBiayaKirim()
        {
            $('#result').html('loading...');
            var jasa = 'jne';
            var asal = '456';
            var tujuan  = $('#usr_citycode').val();
            var weight =$('#berat').html();
            var berat = parseInt(weight);
            document.getElementById('input_berat').value = weight;

            $.ajax({
                url:'<?=base_url()?>/process.php?act=alvincost',
                data:{origin:asal,destination:tujuan,weight:berat,courier:jasa},
                type:'GET',
                success:function(response){
                    $('#result').html(response);
                    getTotalHarga();
                },
                error:function(){
                    alert('something wrong');
                }
            });
        }
        function hitungBiayaKirim()
        {
            $('#jenis_paket').removeClass('hidden');
            $('#result').html('loading...');
            var jasa = 'jne';
            var asal = '456';
            var city = $('#descity').val().split(';');
            var tujuan  =city[0];
            document.getElementById('input_city').value=city[1];
            document.getElementById('shipping_citycode').value=city[0];
            console.log(city[1]);
            var weight =$('#berat').html();
            var berat = parseInt(weight);
            console.log(weight);
            $.ajax({
                url:'<?=base_url()?>/process.php?act=alvincost',
                data:{origin:asal,destination:tujuan,weight:berat,courier:jasa},
                type:'GET',
                success:function(response){
                    $('#result').html(response);
                    getTotalHarga();
                },
                error:function(){
                    alert('something wrong');
                }
            });
        }
        function totalOngkir()
        {
            var ongkir = $('input[name="pilihpaket"]:checked').val().split(';');
            // alert(ongkir);
            $('#ongkir').html(ongkir[0]);
            getTotalHarga();
            document.getElementById('input_ongkir').value = ongkir[0];
            document.getElementById('input_paket').value = 'JNE '+ongkir[1];
        }
        $(document).ready(function(){

            getTotalHarga();
            //hitungBiayaKirim();
            if($('#type_address1').is(':checked'))
            {
                $('#differ_shipping').hide();
                loadBiayaKirim();
                //alert("1");
            }
            $('input[name="type_address"]:radio').change(function () {
                if($('#type_address1').is(':checked'))
                {
                    $('#jenis_paket').removeClass('hidden');
                    $('#differ_shipping').hide();
                    loadBiayaKirim();
                    //alert("1");
                }
                else  if($('#type_address2').is(':checked'))
                {
                    $('#jenis_paket').addClass('hidden');
                    $('#differ_shipping').show();
                }

            });

            $('#descity').change(function(){
                hitungBiayaKirim()
            });
        });
    </script>
</head>

<body>
<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>
    <div id="main">

            <div class="container text-center">
                <h1>Checkout</h1>
            </div>



        <?= form_open('order/process_checkout'); ?>
            <div class="checkout-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <h2>Supplier</h2>

                            <?php foreach($user as $users):?>
                           <!--      <div class="radio">
                                    <label><input type="radio" value="1" name="type_address" id="type_address1" <?php echo set_radio('type_address', '1', TRUE); ?>/><span>Gunakan Alamat yang terdaftar</span></label>
                                </div>
                                <div class="row" style="margin-left: 20px">
                                <div class="col-md-6 col-xs-12 bg-gray" >
                                    <div class="form-group" >
                                        <label for="first_name">Nama Lengkap : <?=$users->usr_fullname?>
                                        </label>
                                        <input type="hidden" value="<?=$users->usr_fullname?>" name="usr_fullname">
                                        <label for="address">Alamat : <br><?=$users->usr_address?>, <?=$users->usr_address2?>,<?=$users->usr_city?>, <?=$users->usr_zip?>
                                        </label>
                                        <input type="hidden" value="<?=$users->usr_address?>, <?=$users->usr_address2?>,<?=$users->usr_city?>, <?=$users->usr_zip?>" name="usr_address">
                                        <input type="hidden" value="<?=$users->usr_citycode?>" name="usr_citycode" id="usr_citycode">
                                        <label for="first_name">Telp/Hp : <?=$users->usr_phone?>
                                        </label>
                                        <input type="hidden" value="<?=$users->usr_phone?>" name="usr_phone">
                                        <label for="email_address">Email : <?=$users->usr_name?>
                                        </label>
                                        <input type="hidden" value="<?=$users->usr_name?>" name="usr_email">
                                    </div>
                                    <div class="form-group">
                                        <label for="order-notes">Catatan</label>
                                        <textarea name="usr_notes" id="order-notes" class="form-control dark" rows="3" placeholder="ex : dikirim jam 5"></textarea>
                                    </div>
                                </div>

                            </div> -->
                               <!--  <div class="radio">
                                    <label><input type="radio" value="2" name="type_address" id="type_address2" <?php echo set_radio('type_address', '2'); ?>/><span>Gunakan Alamat yang Berbeda</span></label>
                                </div> -->

                                <input type="hidden" value="2" name="type_address" id="type_address2"/>
                               
                                <div id="differ_shipping">
                                    <div class="form-group">
                                    <label for="supplier_name">Nama Supplier
                                    </label>
                                    <input type="text" class="form-control dark" id="Nama Lengkap" placeholder="Nama Lengkap" name="reseller_name" value="<?=$users->usr_fullname?>">
                                    
                                </div>
                                <div class="form-group">
                                    <label for="hp_supplier">Hp. Supplier 
                                    </label>
                                    <input type="text" class="form-control dark" id="Hp Supplier" placeholder="Hp Supplier" name="reseller_phone" value="<?=$users->usr_phone?>">
                                   
                                </div>
                                <div class="form-group">
                                    <label for="alamat_supplier">Alamat Supplier
                                    </label>
                                    <textarea name="reseller_address" id="order-notes" class="form-control dark" rows="4" placeholder="" ><?=$users->usr_address.' '.$users->usr_address2.' '.$users->usr_city?></textarea>
                                </div>
                                <h2>Alamat Pengiriman</h2>

                                <div class="form-group">
                                    <label for="first_name">Nama Lengkap <sup>*</sup>
                                    </label>
                                    <input type="text" class="form-control dark" id="Nama Lengkap" placeholder="Nama Lengkap" name="shipping_name">
                                    <?php echo form_error('shipping_name'); ?>
                                </div>
                            <div class="form-group">

                                <label for="address">Alamat *</label>
                                <input type="text" class="form-control dark" id="address" placeholder="Alamat" name="shipping_address1">
                                <?php echo form_error('shipping_address1'); ?>
                            </div>
                                <div class="form-group">
                                    <input type="text" class="form-control dark" id="address" placeholder="Kabupaten,Kecamatan" name="shipping_address2">

                                </div>
                            <!-- /.form-group -->

                            <!-- <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="street-address">Provinsi <sup>*</sup>
                                        </label>
                                      

                                        <select id="desprovince" class="form-control dark">
                                            <option>Provinsi</option>
                                        </select>
                                        <label for="street-address" id="citylabel">Kota <sup>*</sup>
                                        </label>
                                        <select name="descity" id="descity" class="form-control dark" name="shipping_city">
                                            <option>Kota</option>
                                        </select>
                                        <?php echo form_error('input_city'); ?>
                                        <input type="hidden" name="input_city" id="input_city">
                                        <input type="hidden" name="shipping_citycode" id="shipping_citycode">

                                    </div>
                                    
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="town_country">Kode Pos <sup>*</sup>
                                        </label>
                                        <input type="text" class="form-control dark" id="town_country" placeholder="Kode Pos" value=" " name="shipping_zip">
                                        <?php echo form_error('shipping_zip'); ?>
                                    </div>
                                  
                                </div>
                            </div> -->

                            <div class="row">
                        

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="phone">Handphone/Telepon <sup>*</sup>
                                        </label>
                                        <input type="number" class="form-control dark" id="shipping_phone" placeholder="Phone" value="" name="shipping_phone">
                                        <?php echo form_error('shipping_phone'); ?>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="order-notes">Keterangan</label>
                                <textarea name="shipping_notes" id="order-notes" class="form-control dark" rows="3" placeholder="contoh: di kirim jam 3"></textarea>
                            </div>
                                    </div>
                            <!-- /.form-group -->
                            <?php endforeach;?>
                            <!-- /.checkbox -->
                        </div>
                        <div class="col-md-6">
                            <div class="payment-right">
                                <h2>Detail Pembelian</h2>

                                <div class="payment-detail-wrapper">
                                    <ul class="cart-list">
                                        <?php
                                        $i=0;
                                        $cartweight=0;
                                        $cartqty=0;
                                        foreach ($this->cart->contents() as $items):
                                        $i++;

                                            $cartweight += $items['weight']*$items['qty'];

                                        ?>
                                        <li>
                                            <div class="cart-item">
                                                <div class="product-image">
                                                    <a href="#" title="">
                                                        <img src="<?php echo base_url('/assets/uploads/'.$items['img'])?>" class="img-thumbnail" style="width: 100px">
                                                    </a>
                                                </div>

                                                <div class="product-body">
                                                    <div class="product-name">
                                                        <h3>
                                                            <?= $items['name'] ?> - <?= $items['title'] ?>
                                                        </h3>
                                                    </div>

                                                    <div class="product-price">
                                                        <span>Rp.<?php echo $this->cart->format_number( $items['subtotal'] );?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.cart-item -->

                                            <a href="remove_cart/<?=$items['rowid']?>/del" title="" class="remove-cart">
                                                <span class="icon icon-remove"></span>
                                            </a>
                                        </li>
                                        <?php endforeach;?>
                                    </ul>
                                    <!-- /.cart-list -->
                                </div>
                                <!-- /.payment-detail-wrapper -->

                                <div class="cart-total">
                                    <table>
                                        <tbody>
                                        <tr class="order-total">
                                            <th>Sub Total</th>
                                            <span id="barang" class="hidden"><?=$this->cart->total()?></span>
                                            <td><strong><span class="amount" id="vbarang"></span></strong>
                                            <input type="hidden" value="<?=$this->cart->total()?>" name="total">
                                            </td>
                                        </tr>
                                        <tr class="order-total hidden">
                                            <th>Berat:</th>
                                            <?php
                                            $totalweight=$cartweight;
                                            ?>
                                            <td><strong> <span id="berat"><?=$totalweight?></span></strong></td>
                                        </tr>
                                        <?php echo form_error('ongkir'); ?>
                                        <tr class="order-total" id="jenis_paket">
                                            
                                            <td><span id="result"></span> </td>
                                            <span id="ongkir" class="hidden">0</span>
                                            <input type="hidden" name="berat" id="input_berat">
                                            <input type="hidden" name="courier" id="input_paket">
                                            <input type="hidden" name="ongkir" id="input_ongkir">
                                        </tr>
                                        <tr class="order-total">

                                            <th>Grand Total</th>
                                            <td><strong><span id="vtotal"></span></strong>
                                            <input type="hidden" name="total" id="total" value="0">
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>


                                <div class="wc-proceed-to-checkout">
                                    <button class="btn btn-lg btn-primary">Check out</button>
                                </div>
                                <!-- /.wc-proceed-to-checkout -->

                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container -->
            </div>
            <!-- /.checkout-wrapper -->
        <?= form_close(); ?>

    </div>
    <?php $this->load->view('layout/footer');?>





</div>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>