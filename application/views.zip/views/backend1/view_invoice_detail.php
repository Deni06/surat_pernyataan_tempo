<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Shop Online</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('/assets/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('/assets/css/modern-business.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('/assets/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- load for table and search in table -->
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery-1.10.2.min.js');?>"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery.dataTables.min.js');?>"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/dataTables.bootstrap.js');?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/dataTables.bootstrap.css');?>">
</head>

	
	<body>
		
		<!-- Navigation -->
		<?php $this->load->view('layout/dash_navigation');?>
		<!-- Header- dash_menu -->
		<?php $this->load->view('layout/dash_menu');?>
		<!-- Page Content -->
		<div class="container">
			<!-- /.row -->
			<div class="row">
				<!-- body items -->

				<div class="col-md-12">
					<?php foreach($invoices as $invoice):?>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4><i class="fa fa-fw fa-compass"></i> Detail Transaksi NO Order #<?= $invoice->id ?></h4>
						</div>
						<div class="panel-body">
							<div class="container text-center">
								<h1>INVOICE</h1>
							</div>
							<div class="checkout-wrapper">
								<div class="container">
									<div class="row">
										<div class="col-md-12">
											<h2>Alamat Pengiriman</h2>



											<div class="row">
												<div class="col-md-6 col-xs-12 bg-gray" >
													<div class="form-group" >
                                        <span for="first_name">Nama Lengkap : <?=$invoice->customer_name?>
                                        </span>
													</div>
													<div class="form-group">
                                         <span for="address">Alamat : <?=$invoice->address_shipping?>
                                        </span>
													</div>

													<div class="form-group">
                                        <span for="first_name">Telp/Hp : <?=$invoice->customer_phone?>
                                        </span>
													</div>
													<div class="form-group">
                                        <span for="email_address">Email : <?=$invoice->customer_mail?>
                                        </span>
													</div>
													<div class="form-group">
														<span for="order-notes">Catatan</span>
                                        <span for="order-notes"><?=$invoice->order_notes?>
													</div>
												</div>

											</div>
											<!-- /.form-group -->

											<!-- /.checkbox -->
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">

											<h2>Detail Pembelian</h2>

											<div class="col-md-12 hidden-xs hidden-sm">

												<div class="col-md-1">
													<h4>No</h4>
												</div>
												<div class="col-md-2">
													<h4>Kode Barang</h4>
												</div>
												<div class="col-md-2">
													<h4>Nama Barang</h4>
												</div>

												<div class="col-md-2">
													<h4>Qty</h4>
												</div>
												<div class="col-md-2">
													<h4>Harga</h4>
												</div>
												<div class="col-md-2">
													<h4>Total Harga</h4>
												</div>
												<div class="col-sm-12 hidden-lg hidden-md">
													<hr>
													<div class="col-sm-12">
														<h3>Barang Belanja</h3>
													</div>
												</div>


											</div>
											<?php
											$i=0;
											$cartweight=0;
											$cartqty=0;
											$subtotal=0;
											foreach ($orders as $items):
												$i++;
												$subtotal += $items->price;

												?>
												<div class="col-md-12">

													<div class="col-md-1">
														<?= $i ?>
													</div>
													<div class="col-md-2">
														<?= $items->product_title ?>
													</div>
													<div class="col-md-2">
														<?= $items->product_type ?> - <?= $items->product_color ?>
													</div>
													<div class="col-md-2"><?= $items->qty ?>
													</div>
													<div class="col-md-2">
														Rp. <?= number_format($items->price) ?>
													</div>
													<div class="col-md-2">
														Rp. <?= number_format($items->price*$items->qty) ?>
													</div>
												</div>
											<?php endforeach;?>



											<!-- /.payment-detail-wrapper -->



										</div>
									</div>
									<br><br>

									<div class="cart-total">

										<table>
											<tbody>
											<tr class="order-total">
												<th>Sub Total</th>
												<td> &nbsp;&nbsp;<strong><span class="amount">Rp. <?=number_format($subtotal)?></span></strong>

												</td>
											</tr>
											<tr class="order-total" id="jenis_paket">
												<th>Kurir Pengiriman</th>
												<td>&nbsp;&nbsp;<span><?=$invoice->courier_service?> &nbsp;(Berat : <?=$invoice->total_weight?> ) - Rp. <?=number_format($invoice->shipping_fee)?></span> </td>
											</tr>
											<tr class="order-total">

												<th>Grand Total</th>
												<td>
													&nbsp;&nbsp;<span><strong>Rp. <?=number_format($invoice->total_invoice)?></strong></span>
												</td>
											</tr>
											<tr class="order-total">
												<th>Status</th>
												<td>&nbsp;
                                    <span><strong><?php
											if($invoice->status==0)
											{
												echo "Menungu Pembayaran";
											}
											else if($invoice->status==1)
											{
												echo "Pembayaran Diterima";
											}
											if($invoice->status==2)
											{
												echo "Barang Telah Dikirim";
											}
											if($invoice->status==3)
											{
												echo "Transaksi Sukses";
											}
											if($invoice->status==4)
											{
												echo "Transaksi Dibatalkan";
											}
											?></strong></span>
												</td>
											</tr>
											</tbody>
										</table>
									</div>
									<br><br>
									<div class="row">
										<?php if($invoice->status==0):?>
										<div class="col-md-3">
											<a class="btn-primary" href="<?base_url('admin/invoices')?>"><button class="btn-primary btn-lg">Kembali ke Daftar Order</button></a>
											</div>
											<div class="col-md-3">
												<a href="<?base_url('admin/invoices')?>"><button class="btn-danger btn-lg">Batalkan Transaksi</button></a>
											</div>


										<?php else: ?>
											<div class="col-md-6">

													<h2>Konfirmasi Pembayaran</h2>

												<div class="form-group">
													<h4>Metode Pembayaran  : <?=$invoice->payment_method?></h4>
												</div>
												<div class="form-group">
													<label for="first_name">Total Pembayaran : <?=$invoice->total_paid?>
													</label>
												</div>
												<div class="form-group">
													<label for="address">Dari Bank : <?=$invoice->account_bank?></label>
												</div>
												<div class="form-group">

													<label for="address">No Rekening : <?=$invoice->account_number?></label>
													</label>
												</div>
												<div class="form-group">
													<label for="address">Atas Nama :  <?=$invoice->account_name?></label>
												</div>

												<div class="form-group">

													<label for="address">Tanggal Transfer : <?=$invoice->payment_date?> </label>
												</div>
												<a class="btn-primary" href="<?base_url('admin/invoices')?>"><button class="btn-primary">Kembali ke Daftar Order</button></a>
											</div>
											<div class="col-md-5">

													<h2>Resi Pengiriman</h2>


												<div class="form-group">
													<label for="address">Nomor Resi</label>
													<input type="text" name="resi" class="form-control">
												</div>

												<div class="col-md-5">
													<a href="<?base_url('admin/invoices')?>"><button class="btn-info">Update Transaksi</button></a>
												</div>
												<div class="col-md-5">
													<a href="<?base_url('admin/invoices')?>"><button class="btn-danger">Batalkan Transaksi</button></a>
												</div>

											</div>

										<?php endif?>

									</div>
								</div>

								<!-- /.container -->
							</div>

						</div>
							</div>
					<?php endforeach;?>
				</div>
				
			</div>
			<!-- /.row -->
			
			<!-- Features Section -->
			
			<!-- /.row -->
			<hr>
			
			<!-- Footer -->
			<?php $this->load->view('layout/dash_footer')?>
			
		</div>
		<!-- /.container -->
		
		<!-- jQuery -->
		<script type="text/javascript" src="<?php  base_url('/assets/js/jquery.js');?>"></script>
		
		<!-- Bootstrap Core JavaScript -->
		<script type="text/javascript" src="<?php echo  base_url('/assets/js/bootstrap.min.js');?>"></script>
		
		<!-- Script to Activate the Carousel -->
		
		
	</body>
	
</html>
