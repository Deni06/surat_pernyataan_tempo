<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Shop Online</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('/assets/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('/assets/css/modern-business.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('/assets/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- load for table and search in table -->
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery-1.10.2.min.js');?>"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery.dataTables.min.js');?>"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/dataTables.bootstrap.js');?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/dataTables.bootstrap.css');?>">
</head>

	
	<body>
		
		<!-- Navigation -->
		<!-- Navigation -->
		<?php $this->load->view('layout/dash_navigation')?>
		<!-- Header- dash_menu -->
		<?php $this->load->view('layout/dash_menu')?>
		<!-- Page Content -->		<!-- Page Content -->
		<div class="container">
			<div class="row">
				<!-- body items -->

				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4>
								<i class="fa fa-fw fa-compass"></i> Products <?=  anchor('admin/products/create','Add New Product',['class'=>'btn btn-primary btn-xs']) ?>
							</h4>
						</div><!-- /..panel-heading -->
						<div class="panel-body">
							<div><?= validation_errors()?></div>
							<?=  form_open_multipart('admin/products/create_product',['class'=>'form-group']) ?>
							<div class="row">
								<div class="col-md-6">
							<div class="form-group">
									<label for="name">Kategori Produk</label>
									<select name="pro_cat" class="form-control">
										<?php foreach($category as $cat):?>
										<option value="<?=$cat->subcat_id?>"><?=$cat->subcat_name?></option>
										<?php endforeach;?>
									</select>
							</div>
								</div>
								<div class="col-md-6">
							<div class="form-group">
								<label for="name">Kode Produk</label>
									<input type="text" class="form-control" name="pro_title" placeholder="masukan kode barang" value="<?= set_value('pro_title') ?>" required>
								</div>
									</div>
							</div>
							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
										<label for="name">Warna Produk</label>
										<input type="text" class="form-control" name="pro_color" placeholder="masukan warna produk" value="<?= set_value('pro_color') ?>" required>
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label for="name">Berat</label>
										<div class="input-group">
											<input type="text" class="form-control" name="weight" placeholder="masukan berat barang dalam" value="<?= set_value('pro_title') ?>" required>
											<div class="input-group-addon">gram</div>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">

										<label for="name">Harga</label>
										<div class="input-group">
											<div class="input-group-addon">Rp.</div>
											<input type="text" class="form-control" name="pro_price" placeholder="masukan harga barang" value="<?= set_value('pro_price') ?>" required>
										</div>
									</div>
								</div>

								<div class="col-md-2">
									<div class="form-group">
										<label for="name">Diskon</label>
										<div class="input-group">
											<input type="number" class="form-control" name="diskon" placeholder="" value="<?= set_value('pro_title') ?>" required>
											<div class="input-group-addon">%</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row">

								<div class="col-md-3">
									<div class="checkbox">
										<label><input type="checkbox" name="feature" value="1"> Masukan dalam feature?</label>
										<br>
									</div>
								</div>
							</div>

							<div class="input-group-addon">Description</div>
							<div class="col-sm-12">
								<div class="input-group col-sm-12">
									<textarea rows="4" class="form-control" name="pro_description" placeholder="masukan dekripsi produk"><?= set_value('pro_description') ?></textarea>
								</div>
							</div>
							<div class="col-sm-12"><hr></div>
							<div class="col-sm-6">
								<div class="form-group">
									<label>Keyword Produk</label>

									<input type="text" class="form-control" name="keyword" placeholder="masukan keyword di akhiri dengan koma (,)" value="<?= set_value('pro_price') ?>">

								</div>
							</div>


							<div class="col-sm-3">
								<div class="input-group">
									<label>Upload Produk</label>
									<input type="file" name="userfile">
								</div>
							</div>

							<div class="col-sm-1">
								<div class="input-group">

									<button type="submit" class="btn btn-primary">Create</button>
								</div>
							</div>
							<div class="col-sm-1">
								<div class="input-group">

									<?=  anchor('admin/products','Cancel',['class'=>'btn btn-danger']) ?>
								</div>
							</div>


							<?= form_close() ?>
						</div><!-- /..panel-body -->
					</div><!-- /..panel panel-default -->
				</div>

			</div>
			<!-- /.row -->
			<?php $this->load->view('layout/dash_footer')?>
		</div>
		<!-- /.. container -->

		<!-- jQuery -->
		<script src="js/jquery.js"></script>
		
		<!-- Bootstrap Core JavaScript -->
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>
