<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Belujins Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('/assets/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('/assets/css/modern-business.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('/assets/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">
    <script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery-1.10.2.min.js');?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery.dataTables.min.js');?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/dataTables.bootstrap.js');?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/dataTables.bootstrap.css');?>">
</head>


<body>

<!-- Navigation -->
<?php $this->load->view('layout/dash_navigation')?>
<!-- Header- dash_menu -->
<?php $this->load->view('layout/dash_menu')?>
<!-- Page Content -->
<div class="container">
    <!-- /.row -->
    <div class="row">
        <!-- body items -->
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4><i class="fa fa-fw fa-book"></i> Settings <?=  anchor('admin/settings/create','Add Settings',['class'=>'btn btn-primary btn-xs']) ?></h4>

                </div>
                <div class="panel-body">
                    <table class="table table-striped table-hover" id="tablearticle">
                        <thead>
                        <tr>
                            <th>Setting ID</th>
                            <th>Setting Name</th>
                            <th>Value Setting</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <!-- load products from table -->
                        <?php
                        $i=0;
                        foreach ($settings as $setting ) :
                            $i++; ?>
                            <tr>
                                <td><?=  $setting->all_id ?></td>
                                <td><?=  $setting->all_name_settings  ?></td>
                                <td><?=  $setting->all_value_settings?></td>
                                <td>
                                    <?=  anchor('admin/settings/edit/'.$setting->all_id,'View',['class'=>'btn btn-success btn-xs']) ?>
                                    <?php  if($this->session->userdata('group') ==  '1' ): ?>
                                        <?=  anchor('admin/settings/delete/'.$setting->all_id,'Delete',['class'=>'btn btn-danger btn-xs',
                                            'onclick'=>'return confirm(\'Are You Sure ? \')'
                                        ]) ?>
                                    <?php else:?>
                                        <?=  anchor('admin/settings/delete/','Delete',['class'=>'btn btn-danger btn-xs','data-toggle'=>'button',
                                            'onclick'=>'return confirm(\'Sorry You Cant Delete it you should be admin  ? \')'
                                        ]) ?>
                                    <?php endif;?>

                                </td>
                            </tr>
                        <?php endforeach; ?>


                        </tbody>
                    </table>
                    <script>
                        $(document).ready(function(){
                            $('#tablearticle').DataTable();

                        });
                    </script>
                </div>
            </div>

        </div>
        <!-- /.row -->

        <!-- Features Section -->

        <!-- /.row -->
        <hr>

        <!-- Footer -->
        <?php $this->load->view('layout/dash_footer')?>

    </div>

    <!-- /.container -->

    <!-- jQuery -->
    <script src="<?php  base_url('/assets/js/jquery.js');?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php  base_url('/assets/js/bootstrap.min.js');?>"></script>

    <!-- Script to Activate the Carousel -->


</body>

</html>