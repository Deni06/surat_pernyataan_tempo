<?php 
	$article_id = $articles->article_id;
if($this->input->post('is_submitted'))
{
	$article_id=set_value('article_id');
	$article_title=set_value('article_title');
	$content_type=set_value('content_type');
	$article_media=set_value('article_media');
	$article_content=set_value('article_content');
}else{
	$article_id=$articles->article_id;
	$article_title=$articles->article_title;
	$content_type=$articles->content_type;
	$article_media=$articles->article_media;
	$article_content=$articles->article_content;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Shop Online</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('/assets/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url('/assets/css/modern-business.css');?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url('/assets/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- load for table and search in table -->
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery-1.10.2.min.js');?>"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/jquery.dataTables.min.js');?>"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/js/dataTables.bootstrap.js');?>"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url('/assets/ckeditor/ckeditor.js');?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/dataTables.bootstrap.css');?>">
</head>

	
	<body>
		
		<!-- Navigation -->
		<!-- Navigation -->
		<?php $this->load->view('layout/dash_navigation')?>
		<!-- Header- dash_menu -->
		<?php $this->load->view('layout/dash_menu')?>
		<!-- Page Content -->		<!-- Page Content -->
		<div class="container">
			<div class="row">
				<!-- body items -->
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4>
								<i class="fa fa-fw fa-book"></i> Article - Edit article
							</h4>
						</div><!-- /..panel-heading -->
						<div class="panel-body">
							<div class="text-danger"><strong><?= validation_errors()?></strong></div>
							<?=  form_open_multipart('admin/article/edit/'.$article_id,['class'=>'form-group']) ?>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="name">Judul Artikel</label>
										<input type="text" class="form-control" name="article_title" placeholder="masukan judul artikel" value="<?= $article_title ?>">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="name">Tipe Konten</label>
										<div class="radio">
											<label class="radio-inline">
											<input type="radio" value="1" name="content_type"  id="1" onclick="doEnabled(this)"  <?php if($content_type=='1') echo 'checked';  ?> >Gambar											
											</label>
											<input type="hidden" name="is_submitted" value="img">
											<input type="file" name="userfile"  id="image" <?php if($content_type=='1') echo 'value='.$article_media; else echo 'disabled';?>  >
										</div>
										<div class="radio">
											<label class="radio-inline">
											<input type="radio" value="<?=$content_type?>" name="content_type"  id="2" onclick="doEnabled(this)"  <?php if($content_type=='2') echo 'checked';?>>Video
											</label>
											<input type="text" name="video" class="form-control"  placeholder="masukan url video"  id="video" <?php if($content_type=='2') echo 'value='.$article_media; else echo 'disabled';?> >
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="input-group-addon">Konten</div>
										<div class="input-group col-sm-12">
											<textarea rows="6" class="form-control" name="article_content" placeholder="masukan isi artikel" ><?=$article_content?></textarea>
											<script>
											CKEDITOR.replace( 'article_content' );
											</script>
										</div>
								</div>
							</div>
							<div class="col-sm-12"><hr></div>

							<div class="col-sm-1">
								<div class="input-group">

									<button type="submit" class="btn btn-primary">Update</button>
								</div>
							</div>
							<div class="col-sm-1">
								<div class="input-group">

									<?=  anchor('admin/article','Cancel',['class'=>'btn btn-danger']) ?>
								</div>
							</div>


							<?= form_close() ?>
						</div><!-- /..panel-body -->
					</div><!-- /..panel panel-default -->
				</div>
				

			</div>
			<!-- /.row -->
			<?php $this->load->view('layout/dash_footer')?>
		</div>
		<!-- /.. container -->

		<!-- jQuery -->
		<script src="js/jquery.js"></script>
		
		<!-- Bootstrap Core JavaScript -->
		<script src="js/bootstrap.min.js"></script>
		<script>
		function doEnabled(radio){
			switch(radio.value){
				case "1":
				 document.getElementById("image").disabled = false;
				 
				 document.getElementById("video").disabled = true;
				 document.getElementById("video").value = null;
				 break;
				 case "2":
				 document.getElementById("image").disabled = true;
				 document.getElementById("image").value = null;
				 document.getElementById("video").disabled = false;
				 
				 break;
			}
		}
		</script>
	</body>
</html>
