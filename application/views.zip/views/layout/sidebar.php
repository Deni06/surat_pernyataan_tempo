<div class="col-md-3 col-md-pull-9">
    <div id="shop-widgets-filters" class="shop-widgets-filters">

        <div id="widget-area" class="widget-area">

            <div class="widget woocommerce widget_product_categories">
                <h3 class="widget-title">Categories</h3>

                <ul>
                    <li class="parent"><a href="<?=site_url('product/all')?>" title="">All Clothing</a>
                    </li>
                    <?php foreach ($category as $cat ) : ?>
                        <li class="parent"><a><?=$cat->cat_name?></a>
                            <ul>
                                <?php foreach ($subcategory as $subcat ) : ?>
                                    <?php
                                    if($subcat->parent_id == $cat->cat_id )
                                    {?>
                                        <li><a href="<?=site_url('product/category/'.$subcat->subcat_id)?>" title="<?=$subcat->subcat_name?>"><?=$subcat->subcat_name?></a></li>
                                        <?php
                                    }
                                endforeach;
                                ?>
                            </ul>

                        </li>
                    <?php endforeach;?>
                </ul>
            </div>
            <!-- /.widget -->



            <div class="widget woocommerce widget_product_prices hidden">
                <h3 class="widget-title">Prices</h3>

                <ul>
                    <li><a href="#" title="">None</a>
                    </li>
                    <li><a href="#" title="">$35  -  $100</a>
                    </li>
                    <li class="active"><a href="#" title="">$100 - $200</a>
                    </li>
                    <li><a href="#" title="">$200 - $300</a>
                    </li>
                    <li><a href="#" title="">$300  -  $400</a>
                    </li>
                    <li><a href="#" title="">$400  -  $500</a>
                    </li>
                    <li><a href="#" title="">$500  -  $600</a>
                    </li>
                </ul>
            </div>
            <!-- /.widget -->


        </div>

    </div>

    <div id="open-filters">
        <i class="fa fa-filter"></i>
        <span>Filter</span>
    </div>
</div>