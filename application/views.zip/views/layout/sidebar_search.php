<div class="col-md-3 col-md-pull-9">
    <div id="shop-widgets-filters" class="shop-widgets-filters">

        <div id="widget-area" class="widget-area">

            <div class="widget woocommerce widget_product_categories">
                <h3 class="widget-title">Sort By</h3>

                <ul>
                    <li class="parent"><a href="<?=base_url('product/search')?>?keyword=<?=$this->input->get('keyword')?>&sort=1" title="">Terbaru</a>
                    <li class="parent"><a href="<?=base_url('product/search')?>?keyword=<?=$this->input->get('keyword')?>&sort=2" title="">Harga Terendah</a>
                    <li class="parent"><a href="<?=base_url('product/search')?>?keyword=<?=$this->input->get('keyword')?>&sort=3" title="">Harga Tertinggi</a>
                </ul>
            </div>

            <!-- /.widget -->


        </div>

    </div>

</div>