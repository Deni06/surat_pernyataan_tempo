<footer class="footer">
    <div class="footer-wrapper">
        <div class="footer-widgets">


            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-12 col-sm-6">

                                <div class="widget">
                                    <h3 class="widget-title">Tentang LovelySupplier</h3>

                                    <div class="widget-content">
                                        <p><?php foreach($get_about as $about):?><?=$about->all_value_settings?><?php endforeach;?></p>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                    <div class="col-md-4">

                        <div class="widget">
                            <h3 class="widget-title">Follow Us</h3>

                            <ul class="list-socials">
                                <li><a href="#" title=""><i class="icon icon-twitter"></i></a>
                                </li>
                                <li><a href="#" title=""><i class="icon icon-facebook"></i></a>
                                </li>
                                <li><a href="#" title=""><i class="icon icon-google-plus"></i></a>
                                </li>
                                <li><a href="#" title=""><i class="icon icon-pinterest"></i></a>
                                </li>
                            </ul>
                        </div>




                        <!-- /.widget -->

                    </div>
                    <div class="col-md-4 col-sm-6">

                        <div class="widget">
                            <h3 class="widget-title">CONTACT US</h3>

                            <div class="widget-content">
                                <p><?php foreach($get_contact as $contact):?><?=$contact->all_value_settings?><?php endforeach;?></p>
                            </div>
                        </div>
                        <!-- /.widget -->
                        <!-- /.widget -->

                    </div>


                </div>
            </div>


        </div>
        <!-- /.footer-widgets -->

        <div class="footer-copyright">
            <div class="container">
                <div class="copyright">
                    <p>Copyright &copy; 2015 Belujins - All Rights Reserved.</p>
                </div>

            </div>
        </div>
        <!-- /.footer-copyright -->
    </div>
    <!-- /.footer-wrapper -->

    <a href="#" class="back-top" title="">
                <span class="back-top-image">
                    <img src="<?php echo base_url('/assets/img/back-top.png');?>" alt="">
                </span>

        <small>Back top top</small>
    </a>
    <!-- /.back-top -->
</footer>