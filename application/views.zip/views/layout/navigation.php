<!-- Navigation Top_Menu -->

<header id="header" class="awe-menubar-header">
    <nav class="awemenu-nav headroom" data-responsive-width="1200">
        <div class="container">
            <div class="awemenu-container">

                <div class="navbar-header">
                    <ul class="navbar-icons">


                        <li>
                            <a href="#" title="" class="awemenu-icon">
                                <i class="icon icon-user-circle"></i>
                                <span class="awe-hidden-text">Account</span>
                            </a>





                            <ul class="submenu dropdown">

                                <?php if ($this->session->userdata('username')): ?>
                                    <li>
                                        <div class="container-fluid">
                                            <div class="header-account">

                                                <div class="header-account-username">
                                                    <h4><?php echo ('<a>'.'You Are : '.$this->session->userdata('userfullname').'</a>'); ?></h4>
                                                </div>

                                                <ul>

                                                    <li><?php echo anchor('logout','Logout');?>

                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                <?php else:?>

                                <li>
                                    <?php echo anchor('login','Login / Sign Up');?>
                                    <?php endif;?>
                                </li>

                            </ul>
                        </li>

                        <li>
                            <a href="<?=site_url('home/cart')?>" title="My Cart" class="awemenu-icon menu-shopping-cart">
                                <i class="icon icon-shopping-bag"></i>
                                <span class="awe-hidden-text">Cart</span>
                                <?php  if($this->session->userdata('group')	!=	'1'  and $this->session->userdata('group')	!=	'2' ): ?>
                                <?php
                                if ($this->cart->total_items() >= 0);
                                ?>
                                <span class="cart-number"><?=$this->cart->total_items()?></span>
                            </a>
                            <?php else:?>
                            <ul class="submenu megamenu">
                                <li>
                                    <div class="container-fluid">
                                        <span class="text-muted">Cart is empty</span>
                                    </div>
                                </li>
                                <?php endif;?>
                            </ul>
                        </li>


                    </ul>

                    <ul class="navbar-search">
                        <li>
                            <a href="#" title="" class="awemenu-icon awe-menubar-search" id="open-search-form">
                                <span class="sr-only">Search</span>
                                <span class="icon icon-search"></span>
                            </a>

                            <div class="menubar-search-form" id="menubar-search-form">
                                <form action="<?=base_url('product/search')?>" method="get" data-toggle="validator" role="form" id="myForm">
                                    <input type="text" name="keyword" class="form-control" placeholder="Search your entry here..." required>
                                    <input type="hidden" name="sort" value="1">
                                    <div class="menubar-search-buttons">
                                        <button type="submit" class="btn btn-sm btn-white">Search</button>
                                        <button type="button" class="btn btn-sm btn-white" id="close-search-form">
                                            <span class="icon icon-remove"></span>
                                        </button>
                                    </div>

                                </form>
                            </div>
                            <!-- /.menubar-search-form -->
                        </li>
                    </ul>

                </div>

                <div class="awe-logo">
                    <a href="<?=base_url('home')?>" title="">
                        <img src="<?php echo base_url('/assets/img/logo2.png');?>" alt="" width="200">
                    </a>
                </div>
                <!-- /.awe-logo -->


                <ul class="awemenu awemenu-left">
                   <!-- <li class="awemenu-item">
                        <a href="#" title="">
                            <span>Belanja</span>
                        </a>

                        <ul class="awemenu-submenu awemenu-megamenu" data-width="100%" data-animation="fadeup">
                            <li class="awemenu-megamenu-item">
                                <div class="container-fluid">
                                    <div class="awemenu-megamenu-wrapper">

                                        <div class="row">
                                            <div class="col-lg-3">
                                                <h2 class="upper">Jeans</h2>
                                                <ul class="super">
                                                    <li><a href="<?=site_url('product/category/1')?>" title="Regular Fit">Regular Fit</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/2')?>" title="Skinny Fit">Skinny Fit</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/3')?>" title="Slim Fit">Slim Fit</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/4')?>" title="Others">Others</a>
                                                    </li>

                                                </ul>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="awe-media inline">
                                                    <div class="awe-media-image">
                                                        <a href="#" title="">
                                                            <img src="<?php echo base_url('/assets/uploads/2.jpg');?>" alt="">
                                                        </a>
                                                    </div>

                                                    <h4 class="awe-media-title medium upper center">
                                                        <a href="<?=site_url('product/all')?>" title="All Jeans">All jeans</a>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="awe-media inline">
                                                    <div class="awe-media-image">
                                                        <a href="#" title="">
                                                            <img src="<?php echo base_url('/assets/uploads/2.jpg');?>" alt="">
                                                        </a>
                                                    </div>

                                                    <h4 class="awe-media-title medium upper center">
                                                        <a href="<?=site_url('product/all')?>" title="New Arrival">New Arrival</a>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="awe-media inline">
                                                    <div class="awe-media-image">
                                                        <a href="#" title="">
                                                            <img src="<?php echo base_url('/assets/uploads/3.jpg');?>" alt="">
                                                        </a>
                                                    </div>

                                                    <h4 class="awe-media-title medium upper center">
                                                        <a href="<?=site_url('product/all')?>" title="Best Seller">Best Seller</a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="awemenu-item">
                        <a href="#" title="">
                            <span>Pakaian</span>
                        </a>

                        <ul class="awemenu-submenu awemenu-megamenu" data-width="100%" data-animation="fadeup">
                            <li class="awemenu-megamenu-item">
                                <div class="container-fluid">
                                    <div class="awemenu-megamenu-wrapper">

                                        <div class="row">
                                            <div class="col-lg-3">
                                                <h2 class="upper">Pakaian</h2>
                                                <ul class="super">
                                                    <li><a href="<?=site_url('product/category/8')?>" title="Batwing Tees">Batwing Tees</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/9')?>" title="Two Horse Tees">Two Horse Tees</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/10')?>" title="City Tees">City Tees</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/11')?>" title="Knit-Polos">Knit-Polos</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/13')?>" title="LS-Wovens">LS-Wovens</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/15')?>" title="Pack Tees">Pack Tees</a>
                                                    </li>
                                                    <li><a href="<?=site_url('product/category/14')?>" title="">Jacket/Sweater</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="awe-media inline">
                                                    <div class="awe-media-image">
                                                        <a href="#" title="">
                                                            <img src="<?php echo base_url('/assets/uploads/ls1.jpg');?>" alt="">
                                                        </a>
                                                    </div>
                                                    <h4 class="awe-media-title medium upper center">
                                                        <a href="#" title="">All New Clothes</a>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="awe-media inline">
                                                    <div class="awe-media-image">
                                                        <a href="#" title="">
                                                            <img src="<?php echo base_url('/assets/uploads/ls2.jpg');?>" alt="">
                                                        </a>
                                                    </div>
                                                    <h4 class="awe-media-title medium upper center">
                                                        <a href="#" title="">New Arrival</a>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="awe-media inline">
                                                    <div class="awe-media-image">
                                                        <a href="#" title="">
                                                            <img src="<?php echo base_url('/assets/uploads/tees1.jpg');?>" alt="">
                                                        </a>
                                                    </div>
                                                    <h4 class="awe-media-title medium upper center">
                                                        <a href="#" title="">Best Seller</a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>-->
                     <li class="awemenu-item">
                        <a href="<?=base_url('home')?>" title="Home">
                            <span>Beranda</span>
                        </a>
                    </li>
                    <li class="awemenu-item">
                        <a href="<?=site_url('product/all')?>" title="All Product">
                            <span>Semua Koleksi</span>
                        </a>
                    </li>
                    <li class="awemenu-item">
                        <a href="<?=site_url('berita/view')?>" title="All Product">
                            <span>Berita</span>
                        </a>
                    </li>
                    <li class="awemenu-item">
                        <a href="#" title="">
                            <span>Cara Belanja</span>
                        </a>
                    </li>
                     <li class="awemenu-item">
                        <a href="<?=base_url('home')?>" title="Home">
                            <span>Kontak Kami</span>
                        </a>
                    </li>
                    <?php if ($this->session->userdata('group')=='3'): ?>
                        <li class="awemenu-item">
                            <a href="<?=base_url('customer/shopping_history')?>" title="">
                                <span>Pesanan Saya</span>

                            </a>

                        </li>
                    <?php endif;?>
                </ul>
                <!-- /.awemenu -->
            </div>
        </div>
        <!-- /.container -->

    </nav>
    <!-- /.awe-menubar -->
</header>
