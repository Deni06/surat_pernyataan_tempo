<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Belujins || News Article</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
    </script>





</head>

<body>


<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>

    <div id="main">

        <div class="main-header background background-image-heading-blog">
            <div class="container">
                <h1>News Article</h1>
            </div>
        </div>


        <div id="breadcrumb">
            <div class="container">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a>
                    </li>
                    <li class="active"><span>News Article</span>
                    </li>
                </ol>

            </div>
        </div>


        <div class="blog-wrapper blog-nobar">
            <div class="container">
                <div class="row">

                    <div class="col-md-9 col-centered">
                        <?php foreach($articles as $article):?>
                        <article class="post">
                            <div class="entry-media">
                               <!-- <div class="entry-slide">
                                    <div class="entry-carousel owl-carousel">
                                        <div>
                                            <img src="<?=base_url('assets/img/samples/posts/sidebar/1.jpg')?>" alt="">
                                        </div>
                                        <div>
                                            <img src="<?=base_url('assets/img/samples/posts/sidebar/1.jpg')?>" alt="">
                                        </div>
                                        <div>
                                            <img src="<?=base_url('assets/img/samples/posts/sidebar/1.jpg')?>" alt="">
                                        </div>
                                    </div>
                                </div>-->
                                <!-- /.entry-slider -->
                                 <div class="entry-thumbnail">
                                    <?php
                                    if($article->content_type==1):?>
                                    <img src="<?=base_url('assets/article/'.$article->article_media)?>">
                                    <?php elseif($article->content_type==2):?>
                                    <div style='padding-top:5%'></div>
                                    <?php endif;?>
                                </div>


                            </div>
                            <!-- /.entry-media -->

                            <div class="entry-summary">
                                <div class="entry-datetime">
                                    <a href="#" title="">
                                       
                                       
                                    </a>
                                </div>
                                <!-- /.entry-datetime -->

                                <div class="entry-title">
                                    <h2><a href="<?=site_url('berita/detail/'.$article->article_id)?>" title=""><?=$article->article_title?></a></h2>
                                </div>
                                <!-- /.entry-title -->

                                <div class="entry-excerpt">
                                    <p><?=substr(htmlspecialchars_decode($article->article_content),0,500)?> <a href="<?=site_url('berita/detail/'.$article->article_id)?>"style="font-weight:bold">Read more..</a></p>
                                </div>
                                <!-- /.entry-excerpt -->

                                <div class="entry-meta">
                                    <span>Posted by</span>
                                    <strong class="entry-author"><?=$article->created_by?></strong>
                                     <span class="entry-month"> on <?php $date=date_create($article->created_on); echo date_format($date,'d-M-Y : H:m:s')?></span>
                                    <!--<span>-</span>
                                    <span class="entry-category"><a href="#" title="">Clothing</a>  </span>
                                    <span>-</span>
                                    <span class="entry-comment-count"><a href="#" title="">3 Comments</a></span>-->
                                </div>
                                <!-- /.entry-meta -->
                            </div>
                            <!-- /.entry-summary -->
                        </article>
                        <!-- /.post -->



                       <!-- <div class="center">

                            <ul class="pagination">
                                <li class="pagination-prev"><a href="#"><i class="icon icon-arrow-prev"></i></a>
                                </li>
                                <li><a href="#">1</a>
                                </li>
                                <li><a href="#">2</a>
                                </li>
                                <li><a href="#">3</a>
                                </li>
                                <li><a href="#">4</a>
                                </li>
                                <li><a href="#">5</a>
                                </li>
                                <li><span>...</span>
                                </li>
                                <li><a href="#">15</a>
                                </li>
                                <li class="pagination-next"><a href="#"><i class="icon icon-arrow-next"></i></a>
                                </li>
                            </ul>
                            <!-- ./pagination -->
                            
                            <?php endforeach;?>
                            <?php echo $pagination; ?>
                        </div>
                    </div>
                
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.blog-wrapper -->

    </div>




    <?php $this->load->view('layout/footer');?>
    <!-- /footer -->

</div>
<!-- /#wrapper -->



<!-- /.login-popup -->

<script>
    $(function() {
        $('a[href="#login-popup"]').magnificPopup({
            type:'inline',
            midClick: false,
            closeOnBgClick: false
        });
    });
</script>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>
