<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Order Success | Lovelysupplier</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=1024">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
    </script>





</head>

<body>
<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>

    <div id="main">
        <div class="main-header">
            <div class="container">
                <h1>Thank You</h1>
            </div>
        </div>
        <section>
            <div class="container">

                <div class="padding-vertical-50 border-bottom">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">

                            <div class="awe-box center">
                                <div class="awe-box-content">
                                     <?php foreach($invoices as $invoice):?>
                                    <h1>Transaksi Berhasil</h1>    
                                    <h4>No Order anda adalah <b><?php
                                     $date=date_create($invoice->date);
                                     echo date_format($date,"Ymd").$invoice->id
                                    ?> </b>Sedang di Proses</h4>
                                    <p><b>Order Anda akan Expired Pada : Tanggal <?php
                                    $date=date_create($invoice->due_date);
                                     echo date_format($date,"d-m-Y H:i:s");
                                    ?></b></p>
                                    <p>Status order anda menunggu verifikasi pemesanan anda dan biaya pengiriman</p>
                                    <p>Silahkan Transfer sesuai biaya nilai order, Harap di cantumkan No. Order sebagai keterangan transfer.</p>
                                    <p>Prioritas kirim jika :</p>
                                    <p><b>* Transfer Nilai sesuai Order termasuk ongkos kirim</b></p>
                                    <p><b>* Cantumkan No. Order pada keterangan transfer</b></p>
                                    
                                    <br>
                                    <a href="<?=site_url('customer/shopping_history')?>" title="" class="btn btn-lg btn-primary btn-block">Lihat Order</a>
                                    <?php
                                       endforeach; 
                                    ?>
                                </div>
                                <!-- /.awe-box-content -->
                            </div>
                            <!-- /.awe-box -->

                        </div>
                    </div>
                </div>
                <!-- /.padding-vertical-50 -->
                <h2 class="text-center">Rekening Pembayaran</h2>
                <div class="padding-vertical-50 border-bottom">
                    <div class="row">
                        <div class="col-md-4 col-sm-4">

                            <div class="awe-box center box-hover margin-bottom-25">
                                <div class="awe-box-media">
                                    <div class="awe-box-icon icon-large">
                                        <img src="<?php echo base_url('assets/img/bca.png')?>" width="150px">
                                    </div>
                                </div>
                                <!-- /.awe-box-media -->

                                <div class="awe-box-content">
                                    <h3>BCA</h3>
                                    <p>123123123 A/N John Doe</p>
                                </div>
                                <!-- /.awe-box-content -->
                            </div>
                            <!-- /.awe-box -->

                        </div>

                        <div class="col-md-4 col-sm-4">

                            <div class="awe-box center box-hover margin-bottom-25">
                                <div class="awe-box-media">
                                    <div class="awe-box-icon icon-large">
                                        <img src="<?php echo base_url('assets/img/mandiri.png')?>" width="150px">

                                    </div>
                                </div>
                                <!-- /.awe-box-media -->

                                <div class="awe-box-content">
                                    <h3>Mandiri</h3>
                                    <p>123123123 A/N John Doe</p>
                                </div>
                                <!-- /.awe-box-content -->
                            </div>
                            <!-- /.awe-box -->

                        </div>

                        <div class="col-md-4 col-sm-4">

                            <div class="awe-box center box-hover margin-bottom-25">
                                <div class="awe-box-media">
                                    <div class="awe-box-icon icon-large">
                                        <img src="<?php echo base_url('assets/img/cimb.png')?>" width="150px">
                                    </div>
                                </div>
                                <!-- /.awe-box-media -->

                                <div class="awe-box-content">
                                    <h3>CIMB Niaga</h3>
                                    <p>123123123 A/N John Doe</p>
                                </div>
                                <!-- /.awe-box-content -->
                            </div>
                            <!-- /.awe-box -->

                        </div>
                    </div>
                    <!-- /.row -->
                </div>


            </div>
            <!-- /.container -->
        </section>
    </div>
    <?php $this->load->view('layout/footer');?>





</div>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>