<?php
echo "hello world";	
?>
<a href="<?=site_url('welcome')?>">direct</a>