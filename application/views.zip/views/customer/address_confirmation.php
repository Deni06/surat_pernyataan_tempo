<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Review Order | Lovelysupplier</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>
    <script src="<?php echo base_url('/assets/js/script.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
        function getTotalHarga()
        {
            var barang = parseFloat($('#barang').html());
            var vbarang = "Rp. " + barang.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
            $('#vbarang').html(vbarang);
            var ongkir = parseFloat($('#ongkir').html());
            var total = barang+ongkir;
            var vtotal = "Rp. " + total.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
            document.getElementById('total').value = total;

            return $('#vtotal').html(vtotal);

        }

        function loadBiayaKirim()
        {
            $('#result').html('loading...');
            var jasa = 'jne';
            var asal = '456';
            var tujuan  = $('#usr_citycode').val();
            var weight =$('#berat').html();
            var berat = parseInt(weight);
            document.getElementById('input_berat').value = weight;

            $.ajax({
                url:'<?=base_url()?>/process.php?act=alvincost',
                data:{origin:asal,destination:tujuan,weight:berat,courier:jasa},
                type:'GET',
                success:function(response){
                    $('#result').html(response);
                    getTotalHarga();
                },
                error:function(){
                    alert('something wrong');
                }
            });
        }
        function hitungBiayaKirim()
        {
            $('#jenis_paket').removeClass('hidden');
            $('#result').html('loading...');
            var jasa = 'jne';
            var asal = '456';
            var city = $('#descity').val().split(';');
            var tujuan  =city[0];
            document.getElementById('input_city').value=city[1];
            document.getElementById('shipping_citycode').value=city[0];
            console.log(city[1]);
            var weight =$('#berat').html();
            var berat = parseInt(weight);
            console.log(weight);
            $.ajax({
                url:'<?=base_url()?>/process.php?act=alvincost',
                data:{origin:asal,destination:tujuan,weight:berat,courier:jasa},
                type:'GET',
                success:function(response){
                    $('#result').html(response);
                    getTotalHarga();
                },
                error:function(){
                    alert('something wrong');
                }
            });
        }
        function totalOngkir()
        {
            var ongkir = $('input[name="pilihpaket"]:checked').val().split(';');
            // alert(ongkir);
            $('#ongkir').html(ongkir[0]);
            getTotalHarga();
            document.getElementById('input_ongkir').value = ongkir[0];
            document.getElementById('input_paket').value = 'JNE '+ongkir[1];
             var weight =$('#berat').html();
            var berat = parseInt(weight);
            document.getElementById('input_berat').value = weight;
        }
        $(document).ready(function(){

            getTotalHarga();
            //hitungBiayaKirim();
            if($('#type_address1').is(':checked'))
            {
                $('#differ_shipping').hide();
                loadBiayaKirim();
                //alert("1");
            }
            $('input[name="type_address"]:radio').change(function () {
                if($('#type_address1').is(':checked'))
                {
                    $('#jenis_paket').removeClass('hidden');
                    $('#differ_shipping').hide();
                    loadBiayaKirim();
                    //alert("1");
                }
                else  if($('#type_address2').is(':checked'))
                {
                    $('#jenis_paket').addClass('hidden');
                    $('#differ_shipping').show();
                }

            });

            $('#descity').change(function(){
                hitungBiayaKirim()
            });
        });
    </script>
</head>

<body>
<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>
     <?php foreach($invoices as $invoice):?>
    <div id="main">


            <div class="container text-center">
                 <h1>Detail Transaksi : <?php
                    $date=date_create($invoice->date);
                    echo date_format($date,"Ymd").$invoice->id?></h1>
                    <h3>Status Transaksi</h3>
                    <span class="btn btn-primary btn-xs"><strong><?php
                                            if($invoice->status==0)
                                            {
                                                echo "Menunggu Alamat";
                                            }
                                            else if($invoice->status==1)
                                            {
                                                echo "Menunggu Pembayaran";
                                            }
                                            if($invoice->status==2)
                                            {
                                                echo "Pembayaran Di Terima";
                                            }
                                            if($invoice->status==3)
                                            {
                                                echo "Barang Telah Dikirim";
                                            }
                                            if($invoice->status==4)
                                            {
                                                echo "Transaksi Sukses";
                                            }
                                            if($invoice->status==5)
                                            {
                                                echo "Transaksi Dibatalkan";
                                            }
                                            ?></strong></span>
            </div>
            <div class="col-md-3"><?= validation_errors() ?>
                                                      <?= $this->session->flashdata('error') ?>
                                </div>
            </div>



        <?= form_open('customer/process/'.$invoice->id); ?>
            <div class="checkout-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <h2>Alamat Supplier (Dropship)</h2>

                           
                                
                                <div class="form-group">
                                    <label for="supplier_name">Nama Supplier
                                    </label>
                                    <input type="text" class="form-control dark" id="Nama Lengkap" placeholder="Nama Lengkap" name="reseller_name"  readonly="true" value="<?=$invoice->supplier_name?>">
                                    
                                </div>
                                <div class="form-group">
                                    <label for="hp_supplier">Hp. Supplier 
                                    </label>
                                    <input type="text" class="form-control dark" id="Hp Supplier" placeholder="Hp Supplier" name="reseller_phone" readonly="true"  value="<?=$invoice->supplier_phone?>">
                                   
                                </div>
                                 <div class="form-group">
                                    <label for="alamat_supplier">Alamat Supplier 
                                    </label>

                                    <input type="text" class="form-control dark" rows="3" name="reseller_address" readonly="true"
                                        value = "<?=$invoice->supplier_address?>">
                                  
                                   
                                </div>
                                <h2>Alamat Pengiriman</h2>
                                <div id="differ_shipping">
                                <div class="form-group">
                                    <label for="first_name">Nama Lengkap <sup>*</sup>
                                    </label>
                                    <input type="text" class="form-control dark" id="Nama Lengkap" placeholder="Nama Lengkap" name="shipping_name" value="<?=$invoice->customer_name?>" />
                                    <?php echo form_error('shipping_name'); ?>
                                </div>
                            <div class="form-group">

                                <label for="address">Alamat *</label>
                                <input type="text" class="form-control dark" id="address" placeholder="Alamat" name="shipping_address1" value="<?=$invoice->address_shipping?>">

                                <?php echo form_error('shipping_address1'); ?>
                            </div>
                            <!-- /.form-group -->
                           
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="street-address">Provinsi <sup>*</sup>
                                        </label>
                                       <!-- <select id="kota" name="shipping_city" class="form-control dark">
                                            <option>Pilih Kota</option>
                                            <option value="151">Jakarta</option>
                                            <option value="22">Bandung</option>
                                        </select>-->

                                        <select id="desprovince" class="form-control dark">
                                            <option>Provinsi</option>
                                        </select>
                                        <label for="street-address" id="citylabel">Kota <sup>*</sup>
                                        </label>
                                        <select name="descity" id="descity" class="form-control dark" name="shipping_city">
                                            <option>Kota</option>
                                        </select>
                                        <?php echo form_error('input_city'); ?>
                                        <input type="hidden" name="input_city" id="input_city">
                                        <input type="hidden" name="shipping_citycode" id="shipping_citycode">

                                    </div>
                                    <!-- /.form-group -->
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="town_country">Kode Pos <sup>*</sup>
                                        </label>
                                        <input type="text" class="form-control dark" id="town_country" placeholder="Kode Pos" value=" " name="shipping_zip" value="<?=$this->input->get('shipping_zip')?>">
                                        <?php echo form_error('shipping_zip'); ?>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>
 <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="phone">Handphone/Telepon <sup>*</sup>
                                        </label>
                                        <input type="number" class="form-control dark" id="shipping_phone" placeholder="Phone" name="shipping_phone" value="<?=$invoice->customer_phone?>" >
                                        <?php echo form_error('shipping_phone'); ?>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>
                            

                            <div class="form-group">
                                <label for="order-notes">Keterangan</label>
                                <textarea name="shipping_notes" id="order-notes" class="form-control dark" rows="3" placeholder="contoh: di kirim jam 3"><?=$invoice->order_notes?></textarea>
                            </div>
                                    </div>
                            <!-- /.form-group -->
                             <input type="hidden" name="berat" id="input_berat">
                                            <input type="hidden" name="courier" id="input_paket">
                                            <input type="hidden" name="ongkir" id="input_ongkir">
                             <?= form_close(); ?>
                            <?php endforeach;?>
                            <!-- /.checkbox -->
                         

                        </div>
                        <div class="col-md-7">
                             <div class="payment-right">
                                <h2>Penambahan Barang</h2>
                                <form action="<?=$_SERVER['REQUEST_URI']?>" method = "get">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                        <label for="kode_barang">Kode Barang</sup>
                                        </label>
                                        <input type="text" class="form-control dark" id="kode barang" name="kode_barang" placeholder="minimum 4 karakter" value="<?=$this->input->get('kode_barang')?>">
                                        
                                    </div>
                                </div>
                                     <div class="col-md-4">
                                        <br>
                                    <button class="btn btn-lg btn-primary">Cari Produk</button>
                                   </div>
                                     </form>

                                     <form action="<?=$_SERVER['REQUEST_URI']?>" method = "get">
                                        <div class="col-md-8">
                                    <div class="form-group">
                                       <label for="kode_barang">Pilih Produk</sup>
                                        </label>
                                       <select id="kota" name="add_item" class="form-control dark">
                                            <option>Pilih Produk Tambahan</option>
                            
                                             <?php foreach($items as $item):?>
                                            <option value="<?=$item->pro_id?>-<?=$item->pro_price?>"><?=$item->pro_sku?>-<?=$item->pro_color?> <?=$item->pro_title?> ( <?=$item->pro_size?> ) - <?=$item->pro_price?></option>
                                            <?php
                                        endforeach;
                                   
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <br>
                                        <input type="number" class="form-control dark" id="kode barang" min="0" max="3" placeholder="Qty"name="qty" value="<?=$this->input->get('qty')?>" required>

                                    </div>
                                     
                                </div> <div class="form-group text-center">
                                    <button class="btn btn-lg btn-primary">Tambah Produk ke Order</button>
                                </div>
                                    
                                     </form>
                                    
                            </div>
  
                            
                            
                            <div class="payment-right">
                                <h2>Detail Pembelian</h2>

                                <div class="payment-detail-wrapper">
                                    <ul class="cart-list">
                                        <?php
                                        $i=0;
                                        $cartweight=0;
                                        $cartqty=0;
                                        $cartsubtotal = 0;
                                        foreach ($orders as $items):
                                        $i++;

                                            $cartweight += $items->weight * $items->qty;

                                        ?>
                                        <li>
                                            <div class="cart-item">
                                                <div class="product-image">
                                                    <a href="#" title="">
                                                        <img src="<?php echo base_url('/assets/uploads/'.$items->pro_image)?>" class="img-thumbnail" style="width: 100px">
                                                    </a>
                                                </div>

                                                <div class="product-body">
                                                    <div class="product-name">
                                                        <h3>
                                                            <?= $items->product_name ?>   
                                                        </h3>
                                                    </div>
                                                    Qty: <?= $items->qty ?>x , Weight : <?=$items->weight?> gram , Price : Rp.<?php echo $this->cart->format_number( $items->price );?>
                                                    <div class="product-price">
                                                         <span>Rp.<?php echo $this->cart->format_number( $items->price * $items->qty );?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.cart-item -->

                                            
                                        </li>
                                        <?php 
                                        $cartsubtotal += $items->price * $items->qty;
                                        $cartweight += $items->weight;
                                        $cartqty += $items->qty;
                                        ?>
                                        <?php endforeach;?>
                                    </ul>
                                    <!-- /.cart-list -->
                                </div>
                                <!-- /.payment-detail-wrapper -->

                                <div class="cart-total">
                                    <table>
                                        <tbody>
                                        <tr class="order-total">
                                            <th>Sub Total</th>
                                            <span id="barang" class="hidden"><?=$cartsubtotal?></span>
                                            <td><strong><span class="amount" id="vbarang"></span></strong>
                                            <input type="hidden" value="<?=$cartsubtotal?>" name="total">
                                            </td>
                                        </tr>
                                        <tr class="order-total hidden">
                                            <th>Berat:</th>
                                            <?php
                                            $totalweight=$cartweight;
                                            ?>
                                            <td><strong> <span id="berat"><?=$totalweight?></span></strong></td>
                                        </tr>
                                        <?php echo form_error('ongkir'); ?>
                                        <tr class="order-total" id="jenis_paket">
                                            <th>Pilih Paket</th>
                                            <td><span id="result"></span> </td>
                                            <span id="ongkir" class="hidden">0</span>
                                           
                                        </tr>
                                        <tr class="order-total">

                                            <th>Grand Total</th>
                                            <td><strong><span id="vtotal"></span></strong>
                                            <input type="hidden" name="total" id="total" value="0">
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="wc-proceed-to-checkout">
                                    <button class="btn btn-lg btn-primary">Simpan Pesanan</button>
                                </div>
                                <!-- /.wc-proceed-to-checkout -->

                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container -->
            </div>
            <!-- /.checkout-wrapper -->
       

    </div>
    <?php $this->load->view('layout/footer');?>





</div>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>