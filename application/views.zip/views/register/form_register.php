<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Register|Belujins</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>
    <script src="<?php echo base_url('/assets/js/script.js');?>"></script>
<script>
    $(document).ready(function(){
        $('#descity').change(function(){
            var city = $('#descity').val().split(';');
            var tujuan  =city[0];
            document.getElementById('input_city').value=city[1];
            document.getElementById('shipping_citycode').value=city[0];
            console.log(city[1]);
        });

    });
</script>



</head>

<body>
<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>

    <div id="main"  class="white-popup login-popup">
        <div class="section-header center">
            <h2>Register</h2>
        </div>
        <section>
            <b><?= validation_errors() ?></b>
            <?= $this->session->flashdata('error') ?>
            <?= form_open('register') ?>
            <div class="form-group">
                <label for="register-email">Nama Lengkap <sup>*</sup>
                </label>
                <input type="text" class="form-control" id="full-name" name="rname" value="<?= set_value('rname') ?>">
            </div>
            <div class="form-group">
                <label for="register-email">Alamat <sup>*</sup>
                </label>
                <input type="text" class="form-control" id="register-address" name="raddress1" value="<?= set_value('raddress1') ?>">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="register-address" name="raddress2" value="<?= set_value('raddress2') ?>" placeholder="Kecamatan,Kelurahan">
            </div>

            <div class="form-group">
                <label for="street-address">Provinsi <sup>*</sup>
                </label>
                <select id="desprovince" class="form-control dark">
                    <option>Provinsi</option>
                </select>

            </div>
            <div class="form-group">
                <label for="street-address" id="citylabel">Kota <sup>*</sup>
                </label>
                <select name="descity" id="descity" class="form-control dark" name="shipping_city">
                    <option>Kota</option>
                </select>
                <input type="hidden" name="input_city" id="input_city">
                <input type="hidden" name="shipping_citycode" id="shipping_citycode">
            </div>
            <div class="form-group">
                <label for="register-email">Kode Pos<sup>*</sup>
                </label>
                <input type="text" class="form-control" id="register-phone" name="rzipcode" value="<?= set_value('rzipcode') ?>">
            </div>
            <div class="form-group">
                <label for="register-email">Telp/HP<sup>*</sup>
                </label>
                <input type="text" class="form-control" id="register-phone" name="rphone" value="<?= set_value('rphone') ?>">
            </div>
            <div class="form-group">
                <label for="register-email">Email <sup>*</sup>
                </label>
                <input type="text" class="form-control" id="register-email" name="rusername" value="<?= set_value('rusername') ?>">
            </div>
                            <!-- /.form-group -->

                            <div class="form-group">
                                <label for="register-password">Password <sup>*</sup>
                                </label>
                                <input type="password" class="form-control" id="register-password" name="rpassword" value="<?= set_value('rpassword') ?>">
                            </div>
                            <!-- /.form-group -->

                            <div class="form-group">
                                <label for="register-confirm-password">Confirm Password <sup>*</sup>
                                </label>
                                <input type="password" class="form-control" id="register-confirm-password" name="repassword" value="<?= set_value('repassword') ?>">
                            </div>
                            <!-- /.form-group -->

                            <div class="form-button">
                                <button type="submit" class="btn btn-lg btn-warning btn-block">Register</button>
                            </div>
            <div class="form-group">
            <label>Already Have Account?</label>
                    <?=  anchor('login','Login',['class'=>'btn btn-lg btn-default btn-block'])?>
            </div>
            <?= form_close() ?>

        </section>
    </div>
    <?php $this->load->view('layout/footer');?>

</div>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>
