<!DOCTYPE html>
<html class="no-js" lang="">
<head>

	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Shopping Cart | LovelySupplier</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

	<link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

	<link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

	<link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

	<script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

	<script>
		window.SHOW_LOADING = false;
	</script>

</head>

<body>
<div id="wrapper" class="main-wrapper ">
	<?php $this->load->view('layout/navigation');?>
	<div id="main">
		<div class="container text-center">
			<h1>Your Shopping Cart</h1>
		</div>
		<div style="padding-left: 15%;padding-right: 15%">

			<div class="payment-detail-wrapper" >
			<ul class="cart-list">
				<li>
					<div class="container-fluid">
						<?php if  ($this->cart->total_items()!=0):?>

						<ul class="whishlist">
							<?php
							$i=0;
							foreach ($this->cart->contents() as $items):
							$i++;
							?>
							<li>

								<div class="whishlist-item">
									<div class="col-sm-3">
										<a href="#" title="">
											<img src="<?php echo base_url('/assets/uploads/'.$items['img'])?>" alt="">
										</a>
									</div>

									<div class="col-sm-6 pull-left">
										<div class="whishlist-name">
											<h3><?= $items['name'] ?> - <?= $items['title'] ?></h3>
										</div>

										<div class="whishlist-price">
											<span>Price:</span>
											<strong>Rp.<?php echo $this->cart->format_number( $items['price'] );?></strong>
										</div>
										
										<div class="whishlist-price">
											<span>Weight:</span>
											<strong><?php echo $total=$this->cart->format_number( $items['weight']*$items['qty'] );?> gram</strong>
										</div>

										<div class="whishlist-quantity">
											<span>Quantity:</span>
											<?= form_open('home/update_qty'); ?>
											<input type="hidden" value="<?= $items['rowid'] ?>" style="width: 30px" name="rowid">
											<input type="number" value="<?= $items['qty'] ?>" style="width: 30px" name="qty" min="1" max = "3">
												<input type="submit" name="submit" value="Update" class="btn-info" />
											<?= form_close(); ?>

										</div>
									</div>
									<div class="col-sm-3 pull-right ">
										<span class="price"><b>Rp.<?php echo $this->cart->format_number( $items['subtotal'] );?></b></span>
									</div>
								</div>

								<a href="remove_cart/<?=$items['rowid']?>/del" title="" class="remove">
									<i class="icon icon-remove"></i>
								</a>
							</li>
							<?php endforeach;?>
						</ul>

						<div class="menu-cart-total">
							<span>Total</span>
							<span class="price">Rp.<?php echo $this->cart->format_number( $this->cart->total() ); ?></span>
						</div>

						<div class="cart-action">
							<a href="clear_cart" title="Clear Cart" class="btn btn-lg btn-dark btn-outline btn-block">Hapus Keranjang</a>
							<a href="<?=site_url('home')?>" title="" class="btn btn-lg btn-dark btn-outline btn-block">Lanjutkan Belanja</a>
							<a href="<?=site_url('order/checkout')?>" title="" class="btn btn-lg btn-primary btn-block">Selesaikan Order</a>
						</div>
						<?php else:?>

						<span class="text-center">You don't have any items right now</span>

						<div class="cart-action">
							<br>
							<a href="<?=site_url('home')?>" title="" class="btn btn-lg btn-dark btn-outline btn-block">Continue Shopping</a>
						</div>
						<?php endif;?>
					</div>
				</li>
			</ul>
</div>


		</div>





	</div>



	<?php $this->load->view('layout/footer');?>
</div>
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

	<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


	<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

	<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

	<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>
</body>

</html>
