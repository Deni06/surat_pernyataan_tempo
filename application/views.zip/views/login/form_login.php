<!DOCTYPE html>
<html class="no-js" lang="">
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Login|Belujins</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,700,400italic,700italic&amp;subset=latin,vietnamese">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/bootstrap.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/plugins.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('/assets/css/styles.css');?>">

    <script src="<?php echo base_url('/assets/js/vendor.js');?>"></script>

    <script>
        window.SHOW_LOADING = false;
    </script>





</head>

<body>
<div id="wrapper" class="main-wrapper ">


    <?php $this->load->view('layout/navigation');?>

    <div id="main"  class="white-popup login-popup">

        <section>
            <div class="section-header center">
                <h2>Login</h2>
            </div>
                        <?= validation_errors() ?>
                        <?= $this->session->flashdata('error') ?>

                        <?= form_open('login') ?>

                            <div class="form-group">
                                <label for="register-email">Email</label>
                                <input type="text" class="form-control" id="register-email" name="username">
                            </div>
                            <!-- /.form-group -->

                            <div class="form-group">
                                <label for="login-password">Password</label>
                                <input type="password" class="form-control" id="login-password" name="password">
                            </div>
                            <!-- /.form-group -->

                            <div class="forgot-passwd hidden">
                                <a href="#" title="">
                                    <i class="icon icon-key"></i>
                                    <span>Forgot your password?</span>
                                </a>
                            </div>
                            <!-- /.forgot-passwd -->

                            <div class="form-button">
                                <button type="submit" class="btn btn-lg btn-primary btn-block">Login</button>
                            </div>
            <div class="form-group">
                <label>Don't Have Any Account?</label>
                <?=  anchor('register','Register',['class'=>'btn btn-lg btn-default btn-block'])?>
            </div>
                            <!-- /.form-group -->
                        <?= form_close() ?>

   </section>
        </div>
    <?php $this->load->view('layout/footer');?>

</div>



<script src="http://maps.google.com/maps/api/js?sensor=true"></script>

<script src="<?php echo base_url('/assets/js/jquery-ui.min.js')?>"></script>


<script src="<?php echo base_url('/assets/js/plugins.js')?>"></script>

<script src="<?php echo base_url('/assets/js/main.js')?>"></script>

<script src="<?php echo base_url('/assets/js/docs.js')?>"></script>

</body>

</html>
