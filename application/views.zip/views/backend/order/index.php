<div class="pull-right">
	<a href="<?php echo site_url('order/add'); ?>" class="btn btn-success">Add</a> 
</div>

<table class="table table-striped table-bordered">
    <tr>
		<th>ID</th>
		<th>Invoice Id</th>
		<th>Product Id</th>
		<th>Product Type</th>
		<th>Product Title</th>
		<th>Qty</th>
		<th>Price</th>
		<th>Product Color</th>
		<th>Options</th>
		<th>Actions</th>
    </tr>
	<?php foreach($orders as $o){ ?>
    <tr>
		<td><?php echo $o['id']; ?></td>
		<td><?php echo $o['invoice_id']; ?></td>
		<td><?php echo $o['product_id']; ?></td>
		<td><?php echo $o['product_type']; ?></td>
		<td><?php echo $o['product_title']; ?></td>
		<td><?php echo $o['qty']; ?></td>
		<td><?php echo $o['price']; ?></td>
		<td><?php echo $o['product_color']; ?></td>
		<td><?php echo $o['options']; ?></td>
		<td>
            <a href="<?php echo site_url('order/edit/'.$o['id']); ?>" class="btn btn-info btn-xs">Edit</a> 
            <a href="<?php echo site_url('order/remove/'.$o['id']); ?>" class="btn btn-danger btn-xs">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>
