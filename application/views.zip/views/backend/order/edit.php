<?php echo form_open('order/edit/'.$order['id'],array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="invoice_id" class="col-md-4 control-label">Invoice Id</label>
		<div class="col-md-8">
			<input type="text" name="invoice_id" value="<?php echo ($this->input->post('invoice_id') ? $this->input->post('invoice_id') : $order['invoice_id']); ?>" class="form-control" id="invoice_id" />
		</div>
	</div>
	<div class="form-group">
		<label for="product_id" class="col-md-4 control-label">Product Id</label>
		<div class="col-md-8">
			<input type="text" name="product_id" value="<?php echo ($this->input->post('product_id') ? $this->input->post('product_id') : $order['product_id']); ?>" class="form-control" id="product_id" />
		</div>
	</div>
	<div class="form-group">
		<label for="product_type" class="col-md-4 control-label">Product Type</label>
		<div class="col-md-8">
			<input type="text" name="product_type" value="<?php echo ($this->input->post('product_type') ? $this->input->post('product_type') : $order['product_type']); ?>" class="form-control" id="product_type" />
		</div>
	</div>
	<div class="form-group">
		<label for="product_title" class="col-md-4 control-label">Product Title</label>
		<div class="col-md-8">
			<input type="text" name="product_title" value="<?php echo ($this->input->post('product_title') ? $this->input->post('product_title') : $order['product_title']); ?>" class="form-control" id="product_title" />
		</div>
	</div>
	<div class="form-group">
		<label for="qty" class="col-md-4 control-label">Qty</label>
		<div class="col-md-8">
			<input type="text" name="qty" value="<?php echo ($this->input->post('qty') ? $this->input->post('qty') : $order['qty']); ?>" class="form-control" id="qty" />
		</div>
	</div>
	<div class="form-group">
		<label for="price" class="col-md-4 control-label">Price</label>
		<div class="col-md-8">
			<input type="text" name="price" value="<?php echo ($this->input->post('price') ? $this->input->post('price') : $order['price']); ?>" class="form-control" id="price" />
		</div>
	</div>
	<div class="form-group">
		<label for="product_color" class="col-md-4 control-label">Product Color</label>
		<div class="col-md-8">
			<input type="text" name="product_color" value="<?php echo ($this->input->post('product_color') ? $this->input->post('product_color') : $order['product_color']); ?>" class="form-control" id="product_color" />
		</div>
	</div>
	<div class="form-group">
		<label for="options" class="col-md-4 control-label">Options</label>
		<div class="col-md-8">
			<textarea name="options" class="form-control" id="options"><?php echo ($this->input->post('options') ? $this->input->post('options') : $order['options']); ?></textarea>
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>
	
<?php echo form_close(); ?>