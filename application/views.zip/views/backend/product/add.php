<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lovely Supplier - Product</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin" rel="stylesheet">
    <link href= "<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href= "<?=base_url('assets/css/nifty.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/css/nifty-demo.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/pace/pace.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/sweetalert-master/dist/sweetalert.css')?>" rel="stylesheet">
    <script src="<?=base_url('assets/plugins/pace/pace.min.js')?>"></script>
    <script src="<?=base_url('assets/sweetalert-master/dist/sweetalert.min.js')?>"></script>
    <script src="<?=base_url('assets/js/jquery-2.1.1.min.js')?>"></script>
        <script src="<?=base_url('/assets/ckeditor/ckeditor.js');?>"></script>
</head>
<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/header');
    ?>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">

 			<div id="page-content">
                <div class="panel panel-primary"> 
                    <div class="panel-heading">
                        <h3 class="panel-title"><b>Add Products</b></h3>
                    </div>
                    <div class="panel-body">

<?php echo form_open_multipart('admin/productadmin/add',array("class"=>"form-horizontal")); ?>
	<div class="form-group">
		<label for="pro_sku" class="col-md-4 control-label"><span class="text-danger">*</span>Kode Product</label>
		<div class="col-md-6">
			<input type="text" name="pro_sku" value="<?php echo $this->input->post('pro_sku'); ?>" class="form-control" id="pro_sku" />
			<span class="text-danger"><?php echo form_error('pro_sku');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="pro_title" class="col-md-4 control-label"><span class="text-danger">*</span>Nama Produk</label>
		<div class="col-md-6">
			<input type="text" name="pro_title" value="<?php echo $this->input->post('pro_title'); ?>" class="form-control" id="pro_title" />
			<span class="text-danger"><?php echo form_error('pro_title');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="pro_size" class="col-md-4 control-label">Ukuran</label>
		<div class="col-md-3">
			<select name="pro_size" class="form-control">
				<option value="">select</option>
				<?php 
				$pro_size_values = array(
					'S'=>'S',
					'M'=>'M',
					'XL'=>'XL',
					'XXL'=>'XXL',
					'XXXL'=>'XXXL',
				);

				foreach($pro_size_values as $value => $display_text)
				{
					$selected = ($value == $this->input->post('pro_size')) ? ' selected="selected"' : "";

					echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
				} 
				?>
			</select>
		</div>

	</div>
	<div class="form-group">
		<label for="pro_color" class="col-md-4 control-label"><span class="text-danger">*</span>Warna</label>
		<div class="col-md-3">
			<input type="text" name="pro_color" value="<?php echo $this->input->post('pro_color'); ?>" class="form-control" id="pro_color" />
			<span class="text-danger"><?php echo form_error('pro_color');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="weight" class="col-md-4 control-label">Berat (Gram)</label>
		<div class="col-md-3">
			<input type="number" name="weight" value="<?php echo $this->input->post('weight'); ?>" class="form-control" id="weight" placeholder="0" />
			<span class="text-danger"><?php echo form_error('weight');?></span>
		</div>
	</div>
	
	<div class="form-group">
		<label for="pro_price" class="col-md-4 control-label">Harga Reseller (IDR)</label>
		<div class="col-md-6">
			<input type="number" name="pro_price" placeholder="0" value="<?php echo $this->input->post('pro_price'); ?>" class="form-control" id="pro_price" />
			<span class="text-danger"><?php echo form_error('pro_price');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="regular_price" class="col-md-4 control-label">Harga Regular</label>
		<div class="col-md-6">
			<input type="number" name="regular_price" placeholder="0" value="<?php echo $this->input->post('regular_price'); ?>" class="form-control" id="regular_price" />
			<span class="text-danger"><?php echo form_error('regular_price');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="pro_cat" class="col-md-4 control-label">Category</label>
		<div class="col-md-8">
			<select name="pro_cat" class="form-control" required>
                                        <?php foreach($category as $cat):?>
                                        <option value="<?=$cat->subcat_id?>"><?=$cat->subcat_name?></option>
                                        <?php endforeach;?>
                                    </select>
		</div>
	</div>
	
	
	<div class="form-group">
		<label for="pro_stock" class="col-md-4 control-label">Stock Barang</label>
		<div class="col-md-1">
			<input type="number" placeholder="0" name="pro_stock" value="<?php echo $this->input->post('pro_stock'); ?>" class="form-control" id="pro_stock" />
			<span class="text-danger"><?php echo form_error('pro_stock');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="pro_image" class="col-md-4 control-label"><span class="text-danger">*</span>Pro Image</label>
		<div class="col-md-8">
			 <input type="file" name="userfile">
			<span class="text-danger"><?php echo form_error('pro_image');?></span>
		</div>
	</div>
	
	
	<div class="form-group">
		<label for="pro_description" class="col-md-4 control-label">Pro Description</label>
		<div class="col-md-8">
			<textarea name="pro_description" class="form-control" id="pro_description"><?php echo $this->input->post('pro_description'); ?></textarea>
                           <script>
                                    CKEDITOR.replace( 'pro_description' );
                                </script>
		</div>
	</div>
	<div class="form-group">
		<label for="keyword" class="col-md-4 control-label"><span class="text-danger">*</span>Keyword</label>
		<div class="col-md-8">
			<input type="text" name="keyword" value="<?php echo $this->input->post('keyword'); ?>" class="form-control" id="keyword" placeholder="masukan keyword di akhiri dengan koma (,)" />
			<span class="text-danger"><?php echo form_error('keyword');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="is_featured" class="col-md-4 control-label">Is Featured</label>
		<div class="col-md-8">
			<input type="checkbox" name="is_featured" value="1" id="is_featured" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>
</div>
                
                </div>
                <!--===================================================-->
                <!--<!--End page content-->

            </div>
        </div>
       <?php
        $this->load->view('backend/layout/sidebar');
        ?>

    </div>
        <!-- FOOTER -->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/footer');
    ?>
    <!--===================================================-->
    <!-- END FOOTER -->


    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->



</div>
<!--===================================================-->
<!-- END OF CONTAINER -->
<!--JAVASCRIPT-->
<!--=================================================-->




<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/fast-click/fastclick.min.js')?>"></script>


<!--Nifty Admin [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/nifty.min.js')?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js')?>"></script>


<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js')?>"></script>


<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<!--DataTables [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/datatables/media/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/media/js/dataTables.bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')?>"></script>
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url('assets/js/demo/nifty-demo.min.js')?>"></script>
<!--DataTables Sample [ SAMPLE ]-->
<script src="<?=base_url('assets/js/demo/tables-datatables.js')?>"></script>
</body>
</html>