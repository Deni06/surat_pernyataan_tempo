<?php 
	$article_id = $articles->article_id;
if($this->input->post('is_submitted'))
{
	$article_id=$articles->article_id;
	$article_title=set_value('article_title');
	$content_type=set_value('content_type');
	$article_media=$articles->article_media;
	$article_content=set_value('article_content');
 	if($articles->content_type==1)
	$ket='Current Image:<i><b> '. $article_media. '</b></i></small><small><span style="color:red"><br> *upload new image to change</span></small>';
	
	if($content_type==2 && $articles->content_type==1){
		$ket='Current Image:<i><b> '. $article_media. '</b></i></small><small><span style="color:red"><br> *upload new image to change</span></small>';
		$article_media="";
	}
	elseif($content_type==1 && $articles->content_type==2){
		$ket='';
		$article_media="";
	}
	elseif($content_type==2 && $articles->content_type==2){
		$ket='';
		$article_media="";
	}
}else{
	$article_id=$articles->article_id;
	$article_title=$articles->article_title;
	$content_type=$articles->content_type;
	$article_media=$articles->article_media;
	$article_content=$articles->article_content;
	if($content_type=='1') 
	$ket='Current Image:<i><b> '. $article_media. '</b></i></small><small><span style="color:red"><br> *upload new image to change</span></small>';
	else
	$ket=null;
}
?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TES ADMIN - DASHBOARD</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin" rel="stylesheet">
    <link href= "<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href= "<?=base_url('assets/css/nifty.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/css/nifty-demo.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/pace/pace.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/sweetalert-master/dist/sweetalert.css')?>" rel="stylesheet">
    <script src="<?=base_url('assets/plugins/pace/pace.min.js')?>"></script>
    <script src="<?=base_url('assets/sweetalert-master/dist/sweetalert.min.js')?>"></script>
    <script src="<?=base_url('assets/js/jquery-2.1.1.min.js')?>"></script>
    <script src="<?=base_url('/assets/ckeditor/ckeditor.js');?>"></script>
</head>
<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/header');
    ?>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">

 			<div id="page-content">
                <div class="panel panel-primary"> 
                    <div class="panel-heading">
                        <h3 class="panel-title"><b>Edit Article</b></h3>
                    </div>
                    <div class="panel-body">
                        <?=form_open_multipart('admin/article/edit/'.$article_id) ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                        <label for="article_title" class=""><b>Title</b> <?=form_error('article_title','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <input type="text" id="article_title" class="form-control" name="article_title" value="<?=$article_title?>" placeholder="Article Title">
                                        </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                        <label for="content_type" class=""><b>Content Type</b> <?=form_error('content_type','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div class="radio">
											<label class="radio-inline">
											<input type="radio" value="1" name="content_type"  id="1"  onclick="doEnabled(this)" <?php echo set_radio('content_type', $radiovalue1); ?> <?php if($content_type=='1') echo 'checked';  ?> >Image 
											<?=form_error('userfile','<span style="color:#FF0000;font-style:italic"> *','</span>')?>										
											</label>
											<input type="file" name="userfile" disabled id="image" accept=".jpg,.png" > 
											<?=$ket?>
											<?=$error?>
										</div>
										<div class="radio">
											<label class="radio-inline">
											<input type="radio" value="2" name="content_type"  id="2" onclick="doEnabled(this)" <?php echo set_radio('content_type', $radiovalue2); ?> <?php if($content_type=='2') echo 'checked';?> >Video <?=form_error('video','<span style="color:#FF0000;font-style:italic"> *','</span>')?>
											</label>
											<input type="text" name="video"   class="form-control" placeholder="Input video url" disabled id="video" <?php if($content_type=='2') echo 'value='.$article_media; else echo 'disabled value=""';?>>
										</div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <br>
                            <div class="col-md-12">
                                <label for="article_content" class=""><b>Content</b> <?=form_error('article_content','<span style="color:#FF0000;font-style:italic"> *','</span>')?> </label>
                                <textarea rows="6" class="form-control" name="article_content" placeholder="Input Article Content" ><?=$article_content?></textarea>
                                <script>
                                    CKEDITOR.replace( 'article_content' );
                                </script>
                            </div>
                        </div>
                        
                        <div class="row">
                            <br>
                            <div class="col-lg-5 ">
                            </div>
                            <div class="col-sm-1 ">
                                <div class="Form-group">
                                	<input type="hidden" name="is_submitted" value="1">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <div class="Form-group">
                                    <?= anchor('admin/article','Cancel ',['class'=>'btn btn-danger']) ?>
                                </div>
                            </div>
                            <div class="col-lg-5 ">
                            </div>
                        </div>
                        <?=form_close()?>
                    </div>
                </div>
                <!--===================================================-->
                <!--<!--End page content-->

            </div>
        </div>
        <!--===================================================-->
        <!--END CONTENT CONTAINER-->

        <?php
        $this->load->view('backend/layout/sidebar');
        ?>

    </div>



    <!-- FOOTER -->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/footer');
    ?>
    <!--===================================================-->
    <!-- END FOOTER -->


    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->



</div>
<!--===================================================-->
<!-- END OF CONTAINER -->
<!--JAVASCRIPT-->
<!--=================================================-->




<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/fast-click/fastclick.min.js')?>"></script>


<!--Nifty Admin [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/nifty.min.js')?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js')?>"></script>


<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js')?>"></script>


<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<!--DataTables [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/datatables/media/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/media/js/dataTables.bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')?>"></script>
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url('assets/js/demo/nifty-demo.min.js')?>"></script>
<!--DataTables Sample [ SAMPLE ]-->
<script src="<?=base_url('assets/js/demo/tables-datatables.js')?>"></script>
<script>
function doEnabled(radio){
			switch(radio.value){
				case "1":
				 document.getElementById("image").disabled = false;
				 document.getElementById("image").value = null;
				 document.getElementById("video").disabled = true;
				 document.getElementById("video").value = null;
				 break;
				 case "2":
				 document.getElementById("image").disabled = true;
				 document.getElementById("image").value = null;
				 document.getElementById("video").disabled = false;
				 document.getElementById("video").value = null;
				 <?php if($content_type==2):?>
				 document.getElementById("video").value = "<?=$article_media?>";
				 <?php endif;?>
				 break;
			}
		}
if(document.getElementById("1").checked == true ){
	document.getElementById("image").disabled = false;
	document.getElementById("video").disabled = true;
	document.getElementById("video").value = null;
}

else if(document.getElementById("2").checked == true ){
	document.getElementById("image").disabled = true;
	document.getElementById("image").value = null;
	document.getElementById("video").disabled = false;

}
</script>
</body>
</html>