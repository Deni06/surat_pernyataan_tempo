<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lovely Supplier - Order Detail</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin" rel="stylesheet">
    <link href= "<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href= "<?=base_url('assets/css/nifty.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/css/nifty-demo.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/pace/pace.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/sweetalert-master/dist/sweetalert.css')?>" rel="stylesheet">
    <script src="<?=base_url('assets/plugins/pace/pace.min.js')?>"></script>
    <script src="<?=base_url('assets/sweetalert-master/dist/sweetalert.min.js')?>"></script>
    <script src="<?=base_url('assets/js/jquery-2.1.1.min.js')?>"></script>
        <script src="<?=base_url('/assets/ckeditor/ckeditor.js');?>"></script>
</head>
<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/header');
    ?>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">

 			<div id="page-content">
                <div class="panel panel-primary"> 
                    <div class="panel-heading">
                        <h3 class="panel-title"><b>Edit Products</b></h3>
                    </div>
                    <div class="panel-body">
<?php echo form_open('admin/invoice/edit/'.$invoice['id'],array("class"=>"form-horizontal")); ?>

<h2 class="text-center">Data Reseller</h2>
<hr>
<div class="form-group">
		<label for="date" class="col-md-4 control-label">No.Order</label>
		<div class="col-md-6">
			<input type="text" name="date" value="<?php 
			$date=date_create($invoice['date']);
			echo ($this->input->post('id') ? $this->input->post('id') : date_format($date,"Ymd").$invoice['id']); ?>" class="form-control" id="date" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="date" class="col-md-4 control-label">Order Date</label>
		<div class="col-md-6">
			<input type="text" name="date" value="<?php echo ($this->input->post('date') ? $this->input->post('date') : $invoice['date']); ?>" class="form-control" id="date" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="due_date" class="col-md-4 control-label">Due Date</label>
		<div class="col-md-6">
			<input type="text" name="due_date" value="<?php echo ($this->input->post('due_date') ? $this->input->post('due_date') : $invoice['due_date']); ?>" class="form-control" id="due_date" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="reseller_name" class="col-md-4 control-label">Reseller Name</label>
		<div class="col-md-6">
			<input type="text" name="reseller_name" value="<?php echo ($this->input->post('reseller_name') ? $this->input->post('reseller_name') : $invoice['reseller_name']); ?>" class="form-control" id="reseller_name" readonly/>
		</div>
	</div>
	<div class="form-group">
		<label for="reseller_phone" class="col-md-4 control-label">Reseller Phone</label>
		<div class="col-md-6">
			<input type="text" name="reseller_phone" value="<?php echo ($this->input->post('reseller_phone') ? $this->input->post('reseller_phone') : $invoice['reseller_phone']); ?>" class="form-control" id="reseller_phone" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="reseller_address" class="col-md-4 control-label">Reseller Address</label>
		<div class="col-md-6">
			<input type="text" name="reseller_address" value="<?php echo ($this->input->post('reseller_address') ? $this->input->post('reseller_address') : $invoice['reseller_address']); ?>" class="form-control" id="reseller_address" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="status" class="col-md-4 control-label">Status Order</label>
		<div class="col-md-3">
			<?php 
			if($invoice['is_due'] >= 0)
                                                    {


                                                     if($invoice['status']==0)
                                                     {
                                                         $status="Menunggu Alamat";
                                                     }
                                                    else if($invoice['status']==1)
                                                    {
                                                        $status="Menunggu Pembayaran";
                                                    }
                                                    else  if($invoice['status']==2)
                                                    {
                                                        $status="Pembayaran Di Terima";
                                                    }
                                                    else  if($invoice['status']==3)
                                                    {
                                                        $status="Barang Telah Dikirim";
                                                    }
                                                    else  if($invoice['status']==4)
                                                    {
                                                        $status="Transaksi Sukses";
                                                    }
                                                    else  if($invoice['status']==5)
                                                    {
                                                        $status="Transaksi Dibatalkan";
                                                    }
                                                  }
                                                  else{
                                                    $status="Expired";
                                                  }
                                                  if($status == "Expired" ):
                                                  
                                                  	?>
                                                 	<input type="text" name="status" value="<?php echo ($this->input->post('status') ? $this->input->post('status') : $status); ?>" class="form-control" id="status" readonly />
                                                  <?php 
                                                  elseif($invoice['status']==2||$invoice['status']==3): 
                                                  ?>
                               

			
			<select class="form-control" name="status">
				<option class="form-control" value="<?php echo ($this->input->post('status') ? $this->input->post('status') : $invoice['status']); ?>"><?=$status?></option>
				<option class="form-control" value="2">Pembayaran Di Terima</option>
				<option class="form-control" value="3">Barang Telah Dikirim</option>
				<option class="form-control" value="4">Transaksi Sukses</option>
			</select>

		<?php else:?>
			<input type="text" name="status" value="<?php echo ($this->input->post('status') ? $this->input->post('status') : $status); ?>" class="form-control" id="status" readonly />
		<?php endif;?>
		</div>
	</div>
	<div class="form-group">
		<label for="total_invoice" class="col-md-4 control-label">Total Tagihan</label>
		<div class="col-md-6">
			<input type="text" name="total_invoice" value="<?php echo ($this->input->post('total_invoice') ? $this->input->post('total_invoice') : $invoice['total_invoice']); ?>" class="form-control" id="total_invoice" readonly />
		</div>
	</div>
	<hr>
	<h2>Detail Order</h2>
	<table class="table table-striped table-bordered">
    <tr>
		
		
		<th>SKU</th>
		<th>Title</th>
		<th>Color</th>
			<th>Size</th>
		<th>Qty</th>
		<th>Price</th>
	
    </tr>
	<?php foreach($order as $o){ ?>
    <tr>
		
		<td><?php echo $o['product_type']; ?></td>
		<td><?php echo $o['product_title']; ?></td>
				<td><?php echo $o['product_color']; ?></td>
		<td><?php echo $o['pro_size']; ?></td>

		<td><?php echo $o['qty']; ?></td>
		<td><?php echo $o['price']; ?></td>
		
    </tr>
	<?php } ?>
</table>
	<hr>
	<h2 class="text-center">Detail Pengiriman</h2>
	<div class="form-group">
		<label for="customer_name" class="col-md-4 control-label">Customer Name</label>
		<div class="col-md-8">
			<input type="text" name="customer_name" value="<?php echo ($this->input->post('customer_name') ? $this->input->post('customer_name') : $invoice['customer_name']); ?>" class="form-control" id="customer_name" readonly />
		</div>
	</div>
	
	
	<div class="form-group">
		<label for="address_shipping" class="col-md-4 control-label">Address Shipping</label>
		<div class="col-md-8">
			<textarea name="address_shipping" class="form-control" id="address_shipping" readonly><?php echo ($this->input->post('address_shipping') ? $this->input->post('address_shipping') : $invoice['address_shipping']); ?></textarea>
		</div>
	</div>
	
	
	<div class="form-group">
		<label for="customer_phone" class="col-md-4 control-label">Customer Phone</label>
		<div class="col-md-8">
			<input type="text" name="customer_phone" value="<?php echo ($this->input->post('customer_phone') ? $this->input->post('customer_phone') : $invoice['customer_phone']); ?>" class="form-control" id="customer_phone" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="courier_service" class="col-md-4 control-label">Courier Service</label>
		<div class="col-md-8">
			<input type="text" name="courier_service" value="<?php echo ($this->input->post('courier_service') ? $this->input->post('courier_service') : $invoice['courier_service']); ?>" class="form-control" id="courier_service" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="shipping_fee" class="col-md-4 control-label">Shipping Fee</label>
		<div class="col-md-8">
			<input type="text" name="shipping_fee" value="<?php echo ($this->input->post('shipping_fee') ? $this->input->post('shipping_fee') : $invoice['shipping_fee']); ?>" class="form-control" id="shipping_fee" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="total_weight" class="col-md-4 control-label">Total Weight</label>
		<div class="col-md-8">
			<input type="text" name="total_weight" value="<?php echo ($this->input->post('total_weight') ? $this->input->post('total_weight') : $invoice['total_weight']); ?>" class="form-control" id="total_weight" readonly/>
		</div>
	</div>

	<div class="form-group">
		<label for="order_notes" class="col-md-4 control-label">Order Notes</label>
		<div class="col-md-8">
			<input type="text" name="order_notes" value="<?php echo ($this->input->post('order_notes') ? $this->input->post('order_notes') : $invoice['order_notes']); ?>" class="form-control" id="order_notes" readonly />
		</div>
	</div>
	<?php if($invoice['status']>=2):?>

	<h2 class="text-center">Detail Pembayaran</h2>

	<div class="form-group">
		<label for="total_invoice" class="col-md-4 control-label">Total Tagihan</label>
		<div class="col-md-8">
			<input type="text" name="total_invoice" value="<?php echo ($this->input->post('total_invoice') ? $this->input->post('total_invoice') : $invoice['total_invoice']); ?>" class="form-control" id="total_invoice" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="total_paid" class="col-md-4 control-label">Total Pembayaran</label>
		<div class="col-md-8">
			<input type="text" name="total_paid" value="<?php echo ($this->input->post('total_paid') ? $this->input->post('total_paid') : $invoice['total_paid']); ?>" class="form-control" id="total_paid" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="account_bank" class="col-md-4 control-label">Transfer Ke Bank</label>
		<div class="col-md-8">
			<input type="text" name="account_bank" value="<?php echo ($this->input->post('account_bank') ? $this->input->post('account_bank') : $invoice['account_bank']); ?>" class="form-control" id="account_bank" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="account_name" class="col-md-4 control-label">Nama Rekening Pengirim</label>
		<div class="col-md-8">
			<input type="text" name="account_name" value="<?php echo ($this->input->post('account_name') ? $this->input->post('account_name') : $invoice['account_name']); ?>" class="form-control" id="account_name" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="account_number" class="col-md-4 control-label">Catatan Pembayaran</label>
		<div class="col-md-8">
			<input type="text" name="account_number" value="<?php echo ($this->input->post('account_number') ? $this->input->post('account_number') : $invoice['account_number']); ?>" class="form-control" id="account_number" readonly />
		</div>
	</div>
	
	<div class="form-group">
		<label for="payment_date" class="col-md-4 control-label">Tanggal Pembayaran</label>
		<div class="col-md-8">
			<input type="text" name="payment_date" value="<?php echo ($this->input->post('payment_date') ? $this->input->post('payment_date') : $invoice['payment_date']); ?>" class="form-control" id="payment_date" readonly />
		</div>
	</div>
	
<h2 class="text-center">Update Resi</h2>
	<div class="form-group">
		<label for="resi_awb" class="col-md-4 control-label">Resi Awb</label>
		<div class="col-md-6">
			<input type="text" name="resi_awb" value="<?php echo ($this->input->post('resi_awb') ? $this->input->post('resi_awb') : $invoice['resi_awb']); ?>" class="form-control" id="resi_awb" />
		</div>
	</div>
	<div class="form-group">
		<label for="delivery_date" class="col-md-4 control-label">Delivery Date</label>
		<div class="col-md-4" id = "demo-dp-txtinput">
			<input type="Text" name="delivery_date" placeholder="Select Date" value="<?php echo ($this->input->post('delivery_date') ? $this->input->post('delivery_date') : $invoice['delivery_date']); ?>" class="form-control" id="delivery_date" />
		</div>


	</div>
	
	
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>
	
	<?php endif;?>

<?php echo form_close(); ?>
</div>
                
                </div>
                <!--===================================================-->
                <!--<!--End page content-->

            </div>
        </div>
       <?php
        $this->load->view('backend/layout/sidebar');
        ?>

    </div>
        <!-- FOOTER -->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/footer');
    ?>
    <!--===================================================-->
    <!-- END FOOTER -->


    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->



</div>
<!--===================================================-->
<!-- END OF CONTAINER -->
<!--JAVASCRIPT-->
<!--=================================================-->

<script>
    $(document).ready(function() {
        $('#demo-dp-txtinput input').datepicker({
            format: "yyyy-mm-dd"
        });


        // BOOTSTRAP DATEPICKER WITH AUTO CLOSE
        // =================================================================
        // Require Bootstrap Datepicker
        // http://eternicode.github.io/bootstrap-datepicker/
        // =================================================================
        $('#demo-dp-component .input-group.date').datepicker({autoclose: true});


        // BOOTSTRAP DATEPICKER WITH RANGE SELECTION
        // =================================================================
        // Require Bootstrap Datepicker
        // http://eternicode.github.io/bootstrap-datepicker/
        // =================================================================
        $('#demo-dp-range .input-daterange').datepicker({
            format: " dd/mm/yyyy",
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true
        });
    });
    </script>


<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/fast-click/fastclick.min.js')?>"></script>


<!--Nifty Admin [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/nifty.min.js')?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js')?>"></script>


<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js')?>"></script>


<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<!--DataTables [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/datatables/media/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/media/js/dataTables.bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')?>"></script>
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url('assets/js/demo/nifty-demo.min.js')?>"></script>
<!--DataTables Sample [ SAMPLE ]-->
<script src="<?=base_url('assets/js/demo/tables-datatables.js')?>"></script>
</body>
</html>