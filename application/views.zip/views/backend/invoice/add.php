<?php echo form_open('invoice/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="date" class="col-md-4 control-label">Date</label>
		<div class="col-md-8">
			<input type="text" name="date" value="<?php echo $this->input->post('date'); ?>" class="form-control" id="date" />
		</div>
	</div>
	<div class="form-group">
		<label for="due_date" class="col-md-4 control-label">Due Date</label>
		<div class="col-md-8">
			<input type="text" name="due_date" value="<?php echo $this->input->post('due_date'); ?>" class="form-control" id="due_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="user_id" class="col-md-4 control-label">User Id</label>
		<div class="col-md-8">
			<input type="text" name="user_id" value="<?php echo $this->input->post('user_id'); ?>" class="form-control" id="user_id" />
		</div>
	</div>
	<div class="form-group">
		<label for="status" class="col-md-4 control-label">Status</label>
		<div class="col-md-8">
			<input type="text" name="status" value="<?php echo $this->input->post('status'); ?>" class="form-control" id="status" />
		</div>
	</div>
	<div class="form-group">
		<label for="customer_phone" class="col-md-4 control-label">Customer Phone</label>
		<div class="col-md-8">
			<input type="text" name="customer_phone" value="<?php echo $this->input->post('customer_phone'); ?>" class="form-control" id="customer_phone" />
		</div>
	</div>
	<div class="form-group">
		<label for="order_notes" class="col-md-4 control-label">Order Notes</label>
		<div class="col-md-8">
			<input type="text" name="order_notes" value="<?php echo $this->input->post('order_notes'); ?>" class="form-control" id="order_notes" />
		</div>
	</div>
	<div class="form-group">
		<label for="shipping_fee" class="col-md-4 control-label">Shipping Fee</label>
		<div class="col-md-8">
			<input type="text" name="shipping_fee" value="<?php echo $this->input->post('shipping_fee'); ?>" class="form-control" id="shipping_fee" />
		</div>
	</div>
	<div class="form-group">
		<label for="total_invoice" class="col-md-4 control-label">Total Invoice</label>
		<div class="col-md-8">
			<input type="text" name="total_invoice" value="<?php echo $this->input->post('total_invoice'); ?>" class="form-control" id="total_invoice" />
		</div>
	</div>
	<div class="form-group">
		<label for="total_paid" class="col-md-4 control-label">Total Paid</label>
		<div class="col-md-8">
			<input type="text" name="total_paid" value="<?php echo $this->input->post('total_paid'); ?>" class="form-control" id="total_paid" />
		</div>
	</div>
	<div class="form-group">
		<label for="account_bank" class="col-md-4 control-label">Account Bank</label>
		<div class="col-md-8">
			<input type="text" name="account_bank" value="<?php echo $this->input->post('account_bank'); ?>" class="form-control" id="account_bank" />
		</div>
	</div>
	<div class="form-group">
		<label for="account_name" class="col-md-4 control-label">Account Name</label>
		<div class="col-md-8">
			<input type="text" name="account_name" value="<?php echo $this->input->post('account_name'); ?>" class="form-control" id="account_name" />
		</div>
	</div>
	<div class="form-group">
		<label for="account_number" class="col-md-4 control-label">Account Number</label>
		<div class="col-md-8">
			<input type="text" name="account_number" value="<?php echo $this->input->post('account_number'); ?>" class="form-control" id="account_number" />
		</div>
	</div>
	<div class="form-group">
		<label for="customer_name" class="col-md-4 control-label">Customer Name</label>
		<div class="col-md-8">
			<input type="text" name="customer_name" value="<?php echo $this->input->post('customer_name'); ?>" class="form-control" id="customer_name" />
		</div>
	</div>
	<div class="form-group">
		<label for="customer_mail" class="col-md-4 control-label">Customer Mail</label>
		<div class="col-md-8">
			<input type="text" name="customer_mail" value="<?php echo $this->input->post('customer_mail'); ?>" class="form-control" id="customer_mail" />
		</div>
	</div>
	<div class="form-group">
		<label for="total_weight" class="col-md-4 control-label">Total Weight</label>
		<div class="col-md-8">
			<input type="text" name="total_weight" value="<?php echo $this->input->post('total_weight'); ?>" class="form-control" id="total_weight" />
		</div>
	</div>
	<div class="form-group">
		<label for="courier_service" class="col-md-4 control-label">Courier Service</label>
		<div class="col-md-8">
			<input type="text" name="courier_service" value="<?php echo $this->input->post('courier_service'); ?>" class="form-control" id="courier_service" />
		</div>
	</div>
	<div class="form-group">
		<label for="payment_method" class="col-md-4 control-label">Payment Method</label>
		<div class="col-md-8">
			<input type="text" name="payment_method" value="<?php echo $this->input->post('payment_method'); ?>" class="form-control" id="payment_method" />
		</div>
	</div>
	<div class="form-group">
		<label for="resi_awb" class="col-md-4 control-label">Resi Awb</label>
		<div class="col-md-8">
			<input type="text" name="resi_awb" value="<?php echo $this->input->post('resi_awb'); ?>" class="form-control" id="resi_awb" />
		</div>
	</div>
	<div class="form-group">
		<label for="city_code" class="col-md-4 control-label">City Code</label>
		<div class="col-md-8">
			<input type="text" name="city_code" value="<?php echo $this->input->post('city_code'); ?>" class="form-control" id="city_code" />
		</div>
	</div>
	<div class="form-group">
		<label for="payment_date" class="col-md-4 control-label">Payment Date</label>
		<div class="col-md-8">
			<input type="text" name="payment_date" value="<?php echo $this->input->post('payment_date'); ?>" class="form-control" id="payment_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="delivery_date" class="col-md-4 control-label">Delivery Date</label>
		<div class="col-md-8">
			<input type="text" name="delivery_date" value="<?php echo $this->input->post('delivery_date'); ?>" class="form-control" id="delivery_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="source_phone" class="col-md-4 control-label">Source Phone</label>
		<div class="col-md-8">
			<input type="text" name="source_phone" value="<?php echo $this->input->post('source_phone'); ?>" class="form-control" id="source_phone" />
		</div>
	</div>
	<div class="form-group">
		<label for="reseller_name" class="col-md-4 control-label">Reseller Name</label>
		<div class="col-md-8">
			<input type="text" name="reseller_name" value="<?php echo $this->input->post('reseller_name'); ?>" class="form-control" id="reseller_name" />
		</div>
	</div>
	<div class="form-group">
		<label for="reseller_phone" class="col-md-4 control-label">Reseller Phone</label>
		<div class="col-md-8">
			<input type="text" name="reseller_phone" value="<?php echo $this->input->post('reseller_phone'); ?>" class="form-control" id="reseller_phone" />
		</div>
	</div>
	<div class="form-group">
		<label for="reseller_address" class="col-md-4 control-label">Reseller Address</label>
		<div class="col-md-8">
			<input type="text" name="reseller_address" value="<?php echo $this->input->post('reseller_address'); ?>" class="form-control" id="reseller_address" />
		</div>
	</div>
	<div class="form-group">
		<label for="address_shipping" class="col-md-4 control-label">Address Shipping</label>
		<div class="col-md-8">
			<textarea name="address_shipping" class="form-control" id="address_shipping"><?php echo $this->input->post('address_shipping'); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="source_address" class="col-md-4 control-label">Source Address</label>
		<div class="col-md-8">
			<textarea name="source_address" class="form-control" id="source_address"><?php echo $this->input->post('source_address'); ?></textarea>
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>