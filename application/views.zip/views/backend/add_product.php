<?php 
if($this->input->post('is_submitted')){   
        $pro_cat            = set_value('subcategory');     
        $cat_parent         = set_value('category');
}else{
        $pro_cat            = null;     
        $cat_parent         = null;
}
    
?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD PRODUCT</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin" rel="stylesheet">
    <link href= "<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href= "<?=base_url('assets/css/nifty.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/css/nifty-demo.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/pace/pace.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/sweetalert-master/dist/sweetalert.css')?>" rel="stylesheet">
    <script src="<?=base_url('assets/plugins/pace/pace.min.js')?>"></script>
    <script src="<?=base_url('assets/sweetalert-master/dist/sweetalert.min.js')?>"></script>
    <script src="<?=base_url('assets/js/jquery-2.1.1.min.js')?>"></script>
    <script src="<?=base_url('/assets/ckeditor/ckeditor.js');?>"></script>

     <script>
        $(document).ready(function() {
        var parent;
        var sub_cat;
 $.ajax({
                type:'POST',
                url:'<?php echo site_url("admin/product/get_category")?>',
                dataType:"JSON",
                success:function(cat){
                    $('[name="category"]').empty(); 
                    $('[name="category"]').append("<option value='' selected hidden>--Select Category--</option>");
                    $.each(cat,function(cat_id,cat_name){
                        var opt = $('<option />'); 
                        opt.val(cat_id);
                        opt.text(cat_name);
                        $('[name="category"]').append(opt); 
                    });
                    $('[name="category"]').val(parent); 
                }
            });

            $('[name="category"]').change(function(){
                var cat_id = $('[name="category"]').val();
                if(cat_id != ""){
                    $.ajax({
                        type:'POST',
                        url:'<?php echo site_url("admin/product/get_subcategory/")?>/'+cat_id,
                        dataType:"JSON",
                        success:function(cat){
                            $('[name="subcategory"]').empty(); 
                            $('[name="subcategory"]').append("<option value='' selected hidden>--Select Sub-Category--</option>");
                            $.each(cat,function(cat_id,cat_name){
                                var opt = $('<option />'); 
                                opt.val(cat_id);
                                opt.text(cat_name);
                                $('[name="subcategory"]').append(opt); 
                            });
                        }
                    }); 
                }else{
                    $('[name="subcategory"]').empty();
                    var opt=$('<option value="">--Select Manufacture first--</option>');
                    $('[name="subcategory"]').append(opt);
                }
            });
        });
    </script>



</head>
<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/header');
    ?>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">

 			<div id="page-content">
                <div class="panel panel-primary"> 
                    <div class="panel-heading">
                        <h3 class="panel-title"><b>Add New Product</b></h3>
                    </div>
                    <div class="panel-body">
                        <?=form_open_multipart('admin/products/create') ?>
                        <div class="row">
                <!-- body items -->

                <div class="col-md-12">
                    <div class="panel panel-default">
                       
                        <div class="panel-body">
                            <div><?= validation_errors()?></div>
                            <div class="row">
                                 <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Kode Produk</label>
                                    <input type="text" class="form-control" name="pro_sku" placeholder="Masukan kode barang" value="<?= set_value('pro_sku') ?>" required>
                                </div>
                                    </div>
                                </div>
                                  <div class="row">
                                     <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Nama Produk</label>
                                    <input type="text" class="form-control" name="pro_title" placeholder="Masukan nama barang" value="<?= set_value('pro_title') ?>" required>
                                </div>
                                    </div>
                                </div>
                                  <div class="row">
                                    <div class="col-md-3">
                           <div class="form-group">
                                        <label for="itemname" class="">Ukuran</label>
                                       
                                            <select name="size" class="form-control" required>
                                                <option class="form-control" value="-">Pilih Ukuran</option>  
                                                <option class="form-control" value="S">S</option>
                                                <option class="form-control" value="M">M</option>
                                                <option class="form-control" value="L">L</option>
                                                <option class="form-control" value="XL">XL</option>
                                                <option class="form-control" value="XXL">XXL</option>
                                                <option class="form-control" value="XXXL">XXXL</option>
                                                                                                
                                            </select>
                                        
                                </div>
                                    </div>

                                <div class="col-md-3">
                            <div class="form-group">
                                    <label for="name">Kategori Produk</label>
                                    <select name="pro_cat" class="form-control" required>
                                        <?php foreach($category as $cat):?>
                                        <option value="<?=$cat->subcat_id?>"><?=$cat->subcat_name?></option>
                                        <?php endforeach;?>
                                    </select>
                            </div>
                                </div>
                               
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="name">Warna Produk</label>
                                        <input type="text" class="form-control" name="pro_color" placeholder="masukan warna produk" value="<?= set_value('pro_color') ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="name">Berat</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="weight" placeholder="masukan berat barang dalam" value="<?= set_value('pro_weight') ?>" required>
                                            <div class="input-group-addon">gram</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">

                                        <label for="name">Harga Regular</label>
                                        <div class="input-group">
                                            <div class="input-group-addon">Rp.</div>
                                            <input type="text" class="form-control" name="regular_price" placeholder="masukan harga barang" value="<?= set_value('regular_price') ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">

                                        <label for="name">Harga Reseller</label>
                                        <div class="input-group">
                                            <div class="input-group-addon">Rp.</div>
                                            <input type="text" class="form-control" name="pro_price" placeholder="masukan harga barang" value="<?= set_value('pro_price') ?>" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="name">Diskon</label>
                                        <div class="input-group">
                                            <input type="number" class="form-control" name="diskon" placeholder="" value="<?= set_value('pro_diskon') ?>" required>
                                            <div class="input-group-addon">%</div>
                                        </div>
                                    </div>
                                </div>
                           

                                <div class="col-md-3">
                                   <div class="form-group">
                                        <label>Masukan dalam feature?</label>
                                        <br>
                                        <input type="checkbox" name="feature" value="1"> Ya
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label for="Description" class=""><b>Short Desc</b> <?=form_error('pro_description','<span style="color:#FF0000;font-style:italic"> *','</span>')?> </label>
                                <textarea rows="5" required class="form-control" name="pro_description"  ><?= set_value('pro_description')?></textarea>
                                <script>
                                    CKEDITOR.replace( 'pro_description' );
                                </script>
                            </div>
                            <div class="col-sm-12"><hr></div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Keyword Produk</label>

                                    <input type="text" class="form-control" name="keyword" placeholder="masukan keyword di akhiri dengan koma (,)" value="<?= set_value('keyword') ?>">

                                </div>
                            </div>


                            <div class="col-sm-3">
                                <div class="input-group">
                                    <label>Upload Produk</label>
                                    <input type="file" name="userfile">
                                </div>
                            </div>

                            <div class="col-sm-1">
                                <div class="input-group">

                                    <button type="submit" class="btn btn-primary">Create</button>
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <div class="input-group">

                                    <?=  anchor('admin/products','Cancel',['class'=>'btn btn-danger']) ?>
                                </div>
                            </div>


                           
                        </div><!-- /..panel-body -->
                    </div><!-- /..panel panel-default -->
                </div>

            </div>
                        <?=form_close()?>
                    </div>
                </div>
                <!--===================================================-->
                <!--<!--End page content-->

            </div>
        </div>
        <!--===================================================-->
        <!--END CONTENT CONTAINER-->

        <?php
        $this->load->view('backend/layout/sidebar');
        ?>

    </div>



    <!-- FOOTER -->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/footer');
    ?>
    <!--===================================================-->
    <!-- END FOOTER -->


    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->



</div>
<!--===================================================-->
<!-- END OF CONTAINER -->
<!--JAVASCRIPT-->
<!--=================================================-->




<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/fast-click/fastclick.min.js')?>"></script>


<!--Nifty Admin [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/nifty.min.js')?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js')?>"></script>


<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js')?>"></script>


<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<!--DataTables [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/datatables/media/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/media/js/dataTables.bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')?>"></script>
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url('assets/js/demo/nifty-demo.min.js')?>"></script>
<!--DataTables Sample [ SAMPLE ]-->
<script src="<?=base_url('assets/js/demo/tables-datatables.js')?>"></script>



</body>
</html>