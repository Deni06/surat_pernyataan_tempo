<?php echo form_open('user/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="usr_group" class="col-md-4 control-label">Usr Group</label>
		<div class="col-md-8">
			<input type="checkbox" name="usr_group" value="1" id="usr_group" />
		</div>
	</div>
	<div class="form-group">
		<label for="stuts" class="col-md-4 control-label">Stuts</label>
		<div class="col-md-8">
			<input type="checkbox" name="stuts" value="1" id="stuts" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_password" class="col-md-4 control-label">Usr Password</label>
		<div class="col-md-8">
			<input type="password" name="usr_password" value="<?php echo $this->input->post('usr_password'); ?>" class="form-control" id="usr_password" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_name" class="col-md-4 control-label">Usr Name</label>
		<div class="col-md-8">
			<input type="text" name="usr_name" value="<?php echo $this->input->post('usr_name'); ?>" class="form-control" id="usr_name" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_address" class="col-md-4 control-label">Usr Address</label>
		<div class="col-md-8">
			<input type="text" name="usr_address" value="<?php echo $this->input->post('usr_address'); ?>" class="form-control" id="usr_address" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_address2" class="col-md-4 control-label">Usr Address2</label>
		<div class="col-md-8">
			<input type="text" name="usr_address2" value="<?php echo $this->input->post('usr_address2'); ?>" class="form-control" id="usr_address2" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_phone" class="col-md-4 control-label">Usr Phone</label>
		<div class="col-md-8">
			<input type="text" name="usr_phone" value="<?php echo $this->input->post('usr_phone'); ?>" class="form-control" id="usr_phone" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_city" class="col-md-4 control-label">Usr City</label>
		<div class="col-md-8">
			<input type="text" name="usr_city" value="<?php echo $this->input->post('usr_city'); ?>" class="form-control" id="usr_city" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_zip" class="col-md-4 control-label">Usr Zip</label>
		<div class="col-md-8">
			<input type="text" name="usr_zip" value="<?php echo $this->input->post('usr_zip'); ?>" class="form-control" id="usr_zip" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_fullname" class="col-md-4 control-label">Usr Fullname</label>
		<div class="col-md-8">
			<input type="text" name="usr_fullname" value="<?php echo $this->input->post('usr_fullname'); ?>" class="form-control" id="usr_fullname" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_citycode" class="col-md-4 control-label">Usr Citycode</label>
		<div class="col-md-8">
			<input type="text" name="usr_citycode" value="<?php echo $this->input->post('usr_citycode'); ?>" class="form-control" id="usr_citycode" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>