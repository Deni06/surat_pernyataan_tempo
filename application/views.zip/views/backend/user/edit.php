<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lovely Supplier - Order Detail</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin" rel="stylesheet">
    <link href= "<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href= "<?=base_url('assets/css/nifty.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/css/nifty-demo.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/pace/pace.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/sweetalert-master/dist/sweetalert.css')?>" rel="stylesheet">
    <script src="<?=base_url('assets/plugins/pace/pace.min.js')?>"></script>
    <script src="<?=base_url('assets/sweetalert-master/dist/sweetalert.min.js')?>"></script>
    <script src="<?=base_url('assets/js/jquery-2.1.1.min.js')?>"></script>
        <script src="<?=base_url('/assets/ckeditor/ckeditor.js');?>"></script>
</head>
<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/header');
    ?>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">

 			<div id="page-content">
                <div class="panel panel-primary"> 
                    <div class="panel-heading">
                        <h3 class="panel-title"><b>View Member</b></h3>
                    </div>
                    <div class="panel-body">
<?php echo form_open('admin/user/edit/'.$user['usr_id'],array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="usr_fullname" class="col-md-4 control-label">Nama Lengkap</label>
		<div class="col-md-8">
			<input type="text" name="usr_fullname" value="<?php echo ($this->input->post('usr_fullname') ? $this->input->post('usr_fullname') : $user['usr_fullname']); ?>" class="form-control" id="usr_fullname" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_address" class="col-md-4 control-label">Alamat 1</label>
		<div class="col-md-8">
			<input type="text" name="usr_address" value="<?php echo ($this->input->post('usr_address') ? $this->input->post('usr_address') : $user['usr_address']); ?>" class="form-control" id="usr_address" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_address2" class="col-md-4 control-label">Alamat 2</label>
		<div class="col-md-8">
			<input type="text" name="usr_address2" value="<?php echo ($this->input->post('usr_address2') ? $this->input->post('usr_address2') : $user['usr_address2']); ?>" class="form-control" id="usr_address2" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_phone" class="col-md-4 control-label">Handphone</label>
		<div class="col-md-8">
			<input type="text" name="usr_phone" value="<?php echo ($this->input->post('usr_phone') ? $this->input->post('usr_phone') : $user['usr_phone']); ?>" class="form-control" id="usr_phone" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_city" class="col-md-4 control-label">Kota</label>
		<div class="col-md-8">
			<input type="text" name="usr_city" value="<?php echo ($this->input->post('usr_city') ? $this->input->post('usr_city') : $user['usr_city']); ?>" class="form-control" id="usr_city" readonly />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_zip" class="col-md-4 control-label">Kode Pos</label>
		<div class="col-md-8">
			<input type="text" name="usr_zip" value="<?php echo ($this->input->post('usr_zip') ? $this->input->post('usr_zip') : $user['usr_zip']); ?>" class="form-control" id="usr_zip" />
		</div>
	</div>
	<div class="form-group">
		<label for="usr_name" class="col-md-4 control-label">Username/Email</label>
		<div class="col-md-8">
			<input type="text" name="usr_name" value="<?php echo ($this->input->post('usr_name') ? $this->input->post('usr_name') : $user['usr_name']); ?>" class="form-control" id="usr_name" />
		</div>
	</div>
	<div class="form-group">
		<label for="user_type" class="col-md-4 control-label">Member Type</label>
		<div class="col-md-8">
				<select class="form-control">
				<option value="<?php echo ($this->input->post('user_type') ? $this->input->post('user_type') : $user['user_type']); ?>">
					<?php
		if($user['user_type']==1)
		{
			echo "Reseller";
		}else{
			echo "Regular";
		}
					?>
				</option>
				<option value="1">Reseller</option>
				<option value="0">Regular</option>
			</select>
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>
	
<?php echo form_close(); ?>
</div>
                
                </div>
                <!--===================================================-->
                <!--<!--End page content-->

            </div>
        </div>
       <?php
        $this->load->view('backend/layout/sidebar');
        ?>

    </div>
        <!-- FOOTER -->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/footer');
    ?>
    <!--===================================================-->
    <!-- END FOOTER -->


    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->



</div>
<!--===================================================-->
<!-- END OF CONTAINER -->
<!--JAVASCRIPT-->
<!--=================================================-->

<script>
    $(document).ready(function() {
        $('#demo-dp-txtinput input').datepicker({
            format: "yyyy-mm-dd"
        });


        // BOOTSTRAP DATEPICKER WITH AUTO CLOSE
        // =================================================================
        // Require Bootstrap Datepicker
        // http://eternicode.github.io/bootstrap-datepicker/
        // =================================================================
        $('#demo-dp-component .input-group.date').datepicker({autoclose: true});


        // BOOTSTRAP DATEPICKER WITH RANGE SELECTION
        // =================================================================
        // Require Bootstrap Datepicker
        // http://eternicode.github.io/bootstrap-datepicker/
        // =================================================================
        $('#demo-dp-range .input-daterange').datepicker({
            format: " dd/mm/yyyy",
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true
        });
    });
    </script>


<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/fast-click/fastclick.min.js')?>"></script>


<!--Nifty Admin [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/nifty.min.js')?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js')?>"></script>


<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js')?>"></script>


<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<!--DataTables [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/datatables/media/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/media/js/dataTables.bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')?>"></script>
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url('assets/js/demo/nifty-demo.min.js')?>"></script>
<!--DataTables Sample [ SAMPLE ]-->
<script src="<?=base_url('assets/js/demo/tables-datatables.js')?>"></script>
</body>
</html>