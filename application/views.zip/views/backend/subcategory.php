<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TES ADMIN - DASHBOARD</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin" rel="stylesheet">
    <link href= "<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href= "<?=base_url('assets/css/nifty.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/css/nifty-demo.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/pace/pace.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/sweetalert-master/dist/sweetalert.css')?>" rel="stylesheet">
    <script src="<?=base_url('assets/plugins/pace/pace.min.js')?>"></script>
    <script src="<?=base_url('assets/sweetalert-master/dist/sweetalert.min.js')?>"></script>
    <script src="<?=base_url('assets/js/jquery-2.1.1.min.js')?>"></script>
    <script>
        $(document).ready(function() {
            

            $('[name="manufacture"]').change(function(){
                var man_id = $('[name="manufacture"]').val();
                if(man_id != ""){
                    $.ajax({
                        type:'POST',
                        url:'<?php echo site_url("admin/master_subcategory/get_category/")?>/'+man_id,
                        dataType:"JSON",
                        success:function(cat){
                            $('[name="cat"]').empty(); 
                            $('[name="cat"]').append("<option value='' selected hidden>--Select Category--</option>");
                            $.each(cat,function(cat_id,cat_name){
                                var opt = $('<option />'); 
                                opt.val(cat_id);
                                opt.text(cat_name);
                                $('[name="cat"]').append(opt); 
                            });
                        }
                    }); 
                }else{
                    $('[name="cat"]').empty();
                    var opt=$('<option value="">--Select Manufacture first--</option>');
                    $('[name="cat"]').append(opt);
                }
            });
    });
</script>
</head>
<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/header');
    ?>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">

 			<div id="page-content">
                <div class="panel panel-primary"> 
                    <div class="panel-heading">
                        <h3 class="panel-title"><b>Master SubCategory</b></h3>
                    </div>
                    <div id="demo-custom-toolbar2" class="table-toolbar-left">
                         <button class="btn btn-primary btn-labeled fa fa-plus" onclick="add_data()">Add New SubCategory</button>
                    </div>
                    <div class="panel-body">
                        <table id="demo-dt-addrow" class="table table-condensed table-responsive table-hover" cellspacing="0" width="100%">
                            <thead style="font-size:1em">
                            <tr style="text-align:center">
                                <th class="col-sm-1">#</th>
                                <th class="col-sm-2">SubCategory Name</th>
                                <th class="col-sm-1">Category</th>
                                <th class="col-sm-1">Manufacture</th>
                                <th class="col-sm-2">Control</th>
                            </tr>
                            </thead>
                          
                             <tbody>
                                <?php 
                                    $i=0;
                                    
                                    foreach($subcategory as $s): 
                                    $i++;
                                ?>
                                <tr style="font-size:1.1em">
                                    <td class="col-sm-1"><?=$i?>
                                        <input type="hidden" value="<?=$s->cat_id?>" name="id">
                                    </td>
                                    <td class="col-sm-2"><?=$s->cat_name?></td>
                                    <td class="col-sm-1"><?=$s->cat_name2?></td>
                                    <td class="col-sm-1"><?=$s->manufacture_name?></td>
                                    <td class="col-sm-2">
                                        <button class="btn btn-xs btn-labeled btn-primary fa fa-pencil " data-toggle="tooltip"  href="javascript:void()" title="Edit" data-container="body" onclick="edit_data('<?=$s->cat_id?>','<?=$s->cat_name?>','<?=$s->cat_id2?>','<?=$s->manufacture_id?>')">View
                                        </button>
                                        <button class="btn btn-xs btn-labeled btn-danger fa fa-trash " data-toggle="tooltip"  href="javascript:void()" title="Delete" data-container="body" onclick="delete_data('<?=$s->cat_id?>')">Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach;?>
                            </tbody>
                    </table>
                    </div>
                
                </div>
                <!--===================================================-->
                <!--<!--End page content-->

            </div>
        </div>
        <!--===================================================-->
        <!--END CONTENT CONTAINER-->

        <?php
        $this->load->view('backend/layout/sidebar');
        ?>

    </div>



    <!-- FOOTER -->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/footer');
    ?>
    <!--===================================================-->
    <!-- END FOOTER -->


    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->



</div>
<!--===================================================-->
<!-- END OF CONTAINER -->
<!--JAVASCRIPT-->
<!--=================================================-->




<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/fast-click/fastclick.min.js')?>"></script>


<!--Nifty Admin [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/nifty.min.js')?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js')?>"></script>


<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js')?>"></script>


<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<!--DataTables [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/datatables/media/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/media/js/dataTables.bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')?>"></script>
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url('assets/js/demo/nifty-demo.min.js')?>"></script>
<!--DataTables Sample [ SAMPLE ]-->
<script src="<?=base_url('assets/js/demo/tables-datatables.js')?>"></script>

<script>

var save_method;

    function add_data()
    {
        save_method = 'add';
        $('#form')[0].reset(); // reset form on modals
        $('.form-group').removeClass('has-error'); // clear error class
        $('.help-block').empty(); // clear error string
        $('#subcategory_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Add New Subcategory'); // Set Title to Bootstrap modal title
        $('[name="cat"]').empty(); 
        $('[name="cat"]').append("<option value='' selected hidden >--Select Manufacture First--</option>");
        
    }
    function edit_data(id,cat_name,catparent_id,manufacture_id)
    {
        save_method = 'update';
        $('#form')[0].reset(); // reset form on modals
        $('.form-group').removeClass('has-error'); // clear error class
        $('.help-block').empty(); // clear error string
                $('[name="id"]').val(id);
                $('[name="id"]').hide();
                $('[name="subcat"]').val(cat_name);
                var man_id = manufacture_id;
            $.ajax({
                type:'POST',
                url:'<?php echo site_url("admin/master_subcategory/get_category")?>/'+man_id,
                dataType:"JSON",
                success:function(cat){
                    $('[name="cat"]').empty(); 
                    $('[name="cat"]').append("<option value='' selected hidden >--Select Category--</option>");
                    $.each(cat,function(cat_id,cat_name){
                        var opt = $('<option />'); 
                        opt.val(cat_id);
                        opt.text(cat_name);
                        $('[name="cat"]').append(opt); 
                    });
                    $('[name="cat"]').val(catparent_id); 
                }
            });
               
                $('[name="manufacture"]').val(manufacture_id);
                $('#subcategory_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Edit Manufacture'); // Set title to Bootstrap modal title
    }

    function save()
    {
        $('#btnSave').text('saving...'); //change button text
        $('#btnSave').attr('disabled',true); //set button disable
        var url;

        if(save_method == 'add') {
            url = "<?php echo site_url('admin/master_subcategory/ajax_add')?>";
        } else {
            url = "<?php echo site_url('admin/master_subcategory/ajax_update')?>";
        }


        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {

                if(data.status) //if success close modal and reload ajax table
                {
                    $('#subcategory_form').modal('hide');
                    location.reload();

                }
                else
                {
                    for (var i = 0; i < data.inputerror.length; i++)
                    {
                        $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                        $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                    }
                }
                $('#btnSave').text('save'); //change button text
                $('#btnSave').attr('disabled',false); //set button enable

            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
                $('#btnSave').text('save'); //change button text
                $('#btnSave').attr('disabled',false); //set button enable

            }
        });
    }


    function delete_data(id)
    {
        if(confirm('Are you sure?'))
        {
            // ajax delete data to database
            $.ajax({
                url : "<?php echo site_url('admin/master_subcategory/ajax_delete/')?>/"+id,
                type: "POST",
                dataType: "JSON",
                success: function(data)
                {
                    //if success reload ajax table
                  
                    location.reload();
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    alert('Error deleting data');
                }
            });

        }
    }
</script>

<div class="modal fade" id="subcategory_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Subcategory Form</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" method="post" class="form-horizontal"  />
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">SubCategory</label>
                            <div class="col-md-9">
                                <input name="subcat" placeholder="SubCategory Name" class="form-control" type="text" >
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Manufacture</label>
                            <div class="col-md-9">
                                
                                <select name="manufacture" class="form-control">
                                    <option value="" hidden>--Select Manufacture--</option>
                                    <?php foreach($manufacture as $m):?>
                                    <option value="<?=$m->manufacture_id?>"><?=$m->manufacture_name?></option>
                                    <?php endforeach;?>
                                </select>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Category</label>
                            <div class="col-md-9">
                                
                                <select name="cat" class="form-control">
                                    <option value="">--Select Manufacture First--</option>
                                </select>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <input type="hidden" readonly name='id'> 
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
</body>
</html>