<!--MAIN NAVIGATION-->
<!--===================================================-->
<nav id="mainnav-container">
    <div id="mainnav">

        <!--Shortcut buttons-->
        <!--================================-->
        
        <!--================================-->
        <!--End shortcut buttons-->


        <!--Menu-->
        <!--================================-->
        <div id="mainnav-menu-wrap">
            <div class="nano">
                <div class="nano-content">
                    <ul id="mainnav-menu" class="list-group">
                        <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li <?php if($this->uri->segment(2)=='dashboard') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/dashboard')?>">
                            <i class="fa fa-dashboard"></i>
                            <span class="menu-title">
                                <strong>Dashboard</strong>
                            </span>
                            </a>
                        </li>
                        <li <?php if($this->uri->segment(2)=='invoice') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/invoice')?>">
                            <i class="fa fa-tasks"></i>
                            <span class="menu-title">
                                <strong>Order</strong>
                            </span>
                            </a>
                        </li>
                        <li <?php if($this->uri->segment(2)=='product') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/productadmin')?>">
                            <i class="fa fa-briefcase"></i>
                            <span class="menu-title">
                                <strong>Product</strong>
                            </span>
                            </a>
                        </li>

                        <!--<li <?php if($this->uri->segment(2)=='master_manufacture') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/master_manufacture')?>">
                            <i class="fa fa-database"></i>
                            <span class="menu-title">
                                <strong>Master Manufacture</strong>
                            </span>
                            </a>
                        </li>-->
                         <li <?php if($this->uri->segment(2)=='user') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/user')?>">
                            <i class="fa fa-user"></i>
                            <span class="menu-title">
                                <strong>Member</strong>
                            </span>
                            </a>
                        </li>
                        <!--<li <?php if($this->uri->segment(2)=='master_category') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/master_category')?>">
                            <i class="fa fa-database"></i>
                            <span class="menu-title">
                                <strong>Master Category</strong>
                            </span>
                            </a>
                        </li>

                        <li <?php if($this->uri->segment(2)=='master_subcategory') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/master_subcategory')?>">
                            <i class="fa fa-database"></i>
                            <span class="menu-title">
                                <strong>Master SubCategory</strong>
                            </span>
                            </a>
                        </li>-->
                        <li <?php if($this->uri->segment(2)=='article') echo 'class="active-link";'?>>
                            <a href="<?=base_url('admin/article')?>">
                            <i class="fa fa-file-text-o"></i>
                            <span class="menu-title">
                                <strong>Article</strong>
                            </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--================================-->
        <!--End menu-->

    </div>
</nav>
<!--===================================================-->
<!--END MAIN NAVIGATION-->
        