<?php 
if($this->input->post('is_submitted')){
        $pro_id             = $product->pro_id;
        $pro_cat            = set_value('subcategory');
        $pro_title          = set_value('itemname');
        $pro_description    = set_value('description');
        $pro_feature        = set_value('feature');
        $pro_image          = $product->pro_image;
        $keyword            = set_value('keyword');
        $is_featured        = set_value('is_featured');
        $manufacture_id     = set_value('manufacture');
        $file_download      = $product->file_download;   
        $cat_parent         = set_value('category');
        $short_desc         = set_value('shortdesc');
}
else{
        $pro_id = $product->pro_id;
        $pro_cat            = $product->pro_cat;
                $pro_color            = $product->pro_color;
                        $pro_sku            = $product->pro_sku;
                        $pro_size            = $product->pro_size;
                        
        $pro_title          = $product->pro_title;
        $pro_description    = $product->pro_description;
        $pro_image          = $product->pro_image;
        $keyword            = $product->keyword;
        $is_featured        = $product->is_featured;
        $manufacture_id     = $product->manufacture_id;
        $cat_parent         = $product->parent_id;
        $short_desc         = $product->pro_description;
}
    
?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lovelysupplier - Product</title>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin" rel="stylesheet">
    <link href= "<?=base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href= "<?=base_url('assets/css/nifty.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/switchery/switchery.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/css/nifty-demo.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/pace/pace.min.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/media/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')?>" rel="stylesheet">
    <link href="<?=base_url('assets/sweetalert-master/dist/sweetalert.css')?>" rel="stylesheet">
    <script src="<?=base_url('assets/plugins/pace/pace.min.js')?>"></script>
    <script src="<?=base_url('assets/sweetalert-master/dist/sweetalert.min.js')?>"></script>
    <script src="<?=base_url('assets/js/jquery-2.1.1.min.js')?>"></script>
    <script src="<?=base_url('/assets/ckeditor/ckeditor.js');?>"></script>

     <script>
        $(document).ready(function() {
        var man_id = <?=$manufacture_id?>;
        var parent= <?=$cat_parent?>;
        var sub_cat=<?=$pro_cat?>;
        $.ajax({
                type:'POST',
                url:'<?php echo site_url("admin/product/get_category")?>/'+man_id,
                dataType:"JSON",
                success:function(cat){
                    $('[name="category"]').empty(); 
                    $('[name="category"]').append("<option value='' selected hidden>--Select Category--</option>");
                    $.each(cat,function(cat_id,cat_name){
                        var opt = $('<option />'); 
                        opt.val(cat_id);
                        opt.text(cat_name);
                        $('[name="category"]').append(opt); 
                    });
                    $('[name="category"]').val(parent); 
                }
            });
        
        $('[name="manufacture"]').change(function(){
            var man_id = $('[name="manufacture"]').val();
                if(man_id != ""){
                    $.ajax({
                        type:'POST',
                        url:'<?php echo site_url("admin/product/get_category/")?>/'+man_id,
                        dataType:"JSON",
                        success:function(cat){
                            $('[name="category"]').empty(); 
                            $('[name="category"]').append("<option value='' selected hidden>--Select Category--</option>");
                            $('[name="subcategory"]').empty(); 
                            $('[name="subcategory"]').append("<option value='' selected hidden>--Select Category first--</option>");
                            $.each(cat,function(cat_id,cat_name){
                                var opt = $('<option />'); 
                                opt.val(cat_id);
                                opt.text(cat_name);
                                $('[name="category"]').append(opt); 
                            });
                        }
                    }); 
                }else{
                    $('[name="category"]').empty();
                    var opt=$('<option value="">--Select Manufacture first--</option>');
                    $('[name="category"]').append(opt);
                }
            });

                $.ajax({
                        type:'POST',
                        url:'<?php echo site_url("admin/product/get_category/")?>/'+man_id,
                        dataType:"JSON",
                        success:function(cat){
                            $('[name="category"]').empty(); 
                            $('[name="category"]').append("<option value='' selected hidden>--Select Category--</option>");
                            $('[name="subcategory"]').empty(); 
                            $('[name="subcategory"]').append("<option value='' selected hidden>--Select Category first--</option>");
                            $.each(cat,function(cat_id,cat_name){
                                var opt = $('<option />'); 
                                opt.val(cat_id);
                                opt.text(cat_name);
                                $('[name="category"]').append(opt); 
                            });
                        }
                    }); 
               

            $.ajax({
                type:'POST',
                url:'<?php echo site_url("admin/product/get_subcategory/")?>/'+parent,
                dataType:"JSON",
                success:function(cat){
                    $('[name="subcategory"]').empty(); 
                    $('[name="subcategory"]').append("<option value='' selected hidden>--Select Sub-Category--</option>");
                    $.each(cat,function(cat_id,cat_name){
                        var opt = $('<option />'); 
                        opt.val(cat_id);
                        opt.text(cat_name);
                        $('[name="subcategory"]').append(opt); 
                        });
                        $('[name="subcategory"]').val(sub_cat);
                    }
            }); 

            $('[name="category"]').change(function(){
                var cat_id = $('[name="category"]').val();
                if(cat_id != ""){
                    $.ajax({
                        type:'POST',
                        url:'<?php echo site_url("admin/product/get_subcategory/")?>/'+cat_id,
                        dataType:"JSON",
                        success:function(cat){
                            $('[name="subcategory"]').empty(); 
                            $('[name="subcategory"]').append("<option value='' selected hidden>--Select Sub-Category--</option>");
                            $.each(cat,function(cat_id,cat_name){
                                var opt = $('<option />'); 
                                opt.val(cat_id);
                                opt.text(cat_name);
                                $('[name="subcategory"]').append(opt); 
                            });
                        }
                    }); 
                }else{
                    $('[name="subcategory"]').empty();
                    var opt=$('<option value="">--Select Manufacture first--</option>');
                    $('[name="subcategory"]').append(opt);
                }
            });
        });
    </script>



</head>
<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/header');
    ?>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">

 			<div id="page-content">
                <div class="panel panel-primary"> 
                    <div class="panel-heading">
                        <h3 class="panel-title"><b>Edit Product</b></h3>
                    </div>
                    <div class="panel-body">
                        <?=form_open_multipart('admin/product/view_product/'.$pro_id) ?>
                        
                        <div class="row">
                             <img src="<?php echo base_url('assets/uploads/'.$pro_image)?>" width ="250px"/>
                            <div class="col-sm-12">
                                <div class="Form-group">

                                    <label><b>Upload Image</b><small><span style="color:red"> *upload new image to change</span></small><br>
                                    Current Image:<br><i><b> <?=$pro_image?></b></i></small><br><?=$error?></label>
                                    <input type="file" name="userfile1" accept=".jpg,.png,.gif" >
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                        <label for="itemname" class=""><b>Nama Produk</b> <?=form_error('itemname','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <input type="text" id="itemname" required class="form-control" name="itemname" value="<?=$pro_title?>" placeholder="Nama Produk">
                                        </div>
                                </div>
                            </div>
                             <div class="col-md-4">
                                <div class="form-group">
                                        <label for="itemname" class=""><b>SKU</b> <?=form_error('sku','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <input type="text" id="itemname" required class="form-control" name="itemname" value="<?=$pro_sku?>" placeholder="Kode Barang">
                                        </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                        <label for="itemname" class=""><b>Warna</b> <?=form_error('color','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <input type="text" id="itemname" required class="form-control" name="color" value="<?=$pro_color?>" placeholder="Warna">
                                        </div>
                                </div>
                            </div>
                             <div class="col-md-4">
                                <div class="form-group">
                                        <label for="itemname" class=""><b>Ukuran</b> <?=form_error('color','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <select name="size" class="form-control">
                                                <option class="form-control" value="<?=$pro_size?>"><?=$pro_size?></option>
                                                <option class="form-control" value="S">S</option>
                                                <option class="form-control" value="M">M</option>
                                                <option class="form-control" value="L">L</option>
                                                <option class="form-control" value="XL">XL</option>
                                                <option class="form-control" value="XXL">XXL</option>
                                                <option class="form-control" value="XXXL">XXXL</option>
                                                                                                
                                            </select>
                                        </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                        <label for="Category" class=""><b>Category</b><?=form_error('category','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <select name="category" required id="category" class="form-control">
                                                <option value="">--Select Manufacture First--</option>
                                            </select>
                                        </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                        <label for="Sub-Category" class=""><b>Sub-Category</b><?=form_error('subcategory','<span style="color:#FF0000;font-style:italic"> *','</span>')?></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <select name="subcategory" reqiured id="subcategory" class="form-control">
                                                <option value="">--Select Category First--</option>
                                            </select>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <br>
                            <div class="col-md-12">
                                <label for="Description" class=""><b>Description</b> <?=form_error('description','<span style="color:#FF0000;font-style:italic"> *','</span>')?> </label>
                                <textarea rows="5" required class="form-control" name="description" ><?=$pro_description?></textarea>
                                <script>
                                    CKEDITOR.replace( 'description' );
                                </script>
                            </div>
                        </div>
                        <div class="row">
                            <br>
                            <div class="col-md-3">
                                <div class="form-group">
                                        <label for="Keyword" class=""><b>Keyword</b></label>
                                        <div id="demo-dp-txtinput" class="">
                                            <input type="text" id="keyword" class="form-control" name="keyword"  value="<?=$keyword?>" placeholder="masukan keyword akhiri dengan koma (,)">
                                        </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="Spesification" class=""><b>Is Featured?</b></label>
                                <?php if($is_featured==1){?>
                                <label class="form-checkbox form-icon form-text" ><input type="checkbox" value="1"  checked <?php echo set_checkbox('isfeatured', $isfeatured); ?> name="isfeatured"> <b>Yes</b></label>
                                <?php }else{?>
                                <label class="form-checkbox form-icon form-text" ><input type="checkbox" value="1" <?php echo set_checkbox('isfeatured', $isfeatured); ?> name="isfeatured"> <b>Yes</b></label>
                                <?php };?>
                            </div>
                            
                           
                        </div>
                        <div class="row">
                            <br>
                            <div class="col-lg-5 ">
                            </div>
                            <div class="col-sm-1 ">
                                <div class="Form-group">
                                    <input type="hidden" name="is_submitted" value="1">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <div class="Form-group">
                                    <?= anchor('admin/product','Cancel ',['class'=>'btn btn-danger']) ?>
                                </div>
                            </div>
                            <div class="col-lg-5 ">
                            </div>
                        </div>
                        <?=form_close()?>
                    </div>
                </div>
                <!--===================================================-->
                <!--<!--End page content-->

            </div>
        </div>
        <!--===================================================-->
        <!--END CONTENT CONTAINER-->

        <?php
        $this->load->view('backend/layout/sidebar');
        ?>

    </div>



    <!-- FOOTER -->
    <!--===================================================-->
    <?php
    $this->load->view('backend/layout/footer');
    ?>
    <!--===================================================-->
    <!-- END FOOTER -->


    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->



</div>
<!--===================================================-->
<!-- END OF CONTAINER -->
<!--JAVASCRIPT-->
<!--=================================================-->




<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/fast-click/fastclick.min.js')?>"></script>


<!--Nifty Admin [ RECOMMENDED ]-->
<script src="<?=base_url('assets/js/nifty.min.js')?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/switchery/switchery.min.js')?>"></script>


<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-select/bootstrap-select.min.js')?>"></script>
<!--Bootstrap Timepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js')?>"></script>


<!--Bootstrap Datepicker [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<!--DataTables [ OPTIONAL ]-->
<script src="<?=base_url('assets/plugins/datatables/media/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/media/js/dataTables.bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')?>"></script>
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url('assets/js/demo/nifty-demo.min.js')?>"></script>
<!--DataTables Sample [ SAMPLE ]-->
<script src="<?=base_url('assets/js/demo/tables-datatables.js')?>"></script>



</body>
</html>